const { chromium } = require('playwright');
const path = process.argv[2], out = process.argv[3];
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('FAIL:', m); } };
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 430, height: 860 }, acceptDownloads: true });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  p.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|fonts/.test(m.text())) errs.push(m.text()); });
  await p.goto('file://' + path);
  await p.waitForTimeout(400);

  /* ---- engine ---- */
  const E = await p.evaluate(() => {
    const L = window.__lifeos, o = L.occursOn, r = {};
    r.daily3 = [o({date:'2026-11-08',rule:{freq:'daily',every:3}},'2026-11-08'), o({date:'2026-11-08',rule:{freq:'daily',every:3}},'2026-11-11'), o({date:'2026-11-08',rule:{freq:'daily',every:3}},'2026-11-09')];
    r.beforeStart = o({date:'2026-11-08',rule:{freq:'daily',every:1}},'2026-11-07');
    const mw = {date:'2026-11-08',rule:{freq:'weekly',every:1,days:[1,3]}};
    r.weekMW = [o(mw,'2026-11-09'), o(mw,'2026-11-11'), o(mw,'2026-11-10'), o(mw,'2026-11-16')];
    const bi = {date:'2026-11-07',rule:{freq:'weekly',every:2,days:[]}};
    r.biweekly = [o(bi,'2026-11-07'), o(bi,'2026-11-14'), o(bi,'2026-11-21'), o(bi,'2026-12-05')];
    const m31 = {date:'2026-01-31',rule:{freq:'monthly',every:1}};
    r.m31 = [o(m31,'2026-02-28'), o(m31,'2026-03-31'), o(m31,'2026-04-30'), o(m31,'2026-02-27')];
    const ly = {date:'2024-02-29',rule:{freq:'yearly',every:1}};
    r.yearly = [o(ly,'2025-02-28'), o(ly,'2028-02-29'), o(ly,'2025-03-01')];
    r.until = [o({date:'2026-11-08',until:'2026-11-10',rule:{freq:'daily',every:1}},'2026-11-10'), o({date:'2026-11-08',until:'2026-11-10',rule:{freq:'daily',every:1}},'2026-11-11')];
    r.skip = o({date:'2026-11-08',skip:['2026-11-09'],rule:{freq:'daily',every:1}},'2026-11-09');
    r.single = [o({date:'2026-11-08',rule:{freq:'none'}},'2026-11-08'), o({date:'2026-11-08'},'2026-11-09')];
    r.next = L.nextDue({due:'2026-11-07',anchor:'2026-11-07',rule:{freq:'weekly',every:1,days:[6]}},'2026-11-08');
    r.nextMonth = L.nextDue({due:'2026-01-31',anchor:'2026-01-31',rule:{freq:'monthly',every:1}},'2026-01-31');
    r.after = L.nextDue({due:'2026-11-01',rule:{freq:'after',every:2,unit:'week'}},'2026-11-08') === L.addDays(L.today(),14);
    r.none = L.nextDue({due:'2026-11-01',rule:{freq:'none'}},'2026-11-08');
    r.addMonths = [L.addMonths('2026-01-31',1), L.addMonths('2026-11-30',3), L.addMonths('2026-12-15',2)];
    r.text = [L.ruleText({rule:{freq:'weekly',every:2,days:[1,3]}}), L.ruleText({rule:{freq:'none'}}), L.ruleText({rule:{freq:'after',every:3,unit:'day'}})];
    return r;
  });
  ok(E.daily3.join() === 'true,true,false', 'daily every 3 ' + E.daily3);
  ok(E.beforeStart === false, 'not before start');
  ok(E.weekMW.join() === 'true,true,false,true', 'weekly Mon/Wed ' + E.weekMW);
  ok(E.biweekly.join() === 'true,false,true,true', 'biweekly ' + E.biweekly);
  ok(E.m31.join() === 'true,true,true,false', 'monthly 31st clamps ' + E.m31);
  ok(E.yearly.join() === 'true,true,false', 'yearly leap day ' + E.yearly);
  ok(E.until.join() === 'true,false', 'until ' + E.until);
  ok(E.skip === false, 'skip date');
  ok(E.single.join() === 'true,false', 'non-repeating ' + E.single);
  ok(E.next === '2026-11-14', 'next weekly after completing ' + E.next);
  ok(E.nextMonth === '2026-02-28', 'next monthly clamps ' + E.nextMonth);
  ok(E.after === true, 'completion-triggered');
  ok(E.none === null, 'no next for non-repeating');
  ok(E.addMonths.join() === '2026-02-28,2027-02-28,2027-02-15', 'addMonths ' + E.addMonths);
  ok(E.text[0] === 'Every 2 weeks on Mon, Wed' && E.text[1] === 'Does not repeat' && E.text[2] === '3 days after I finish it', 'ruleText ' + E.text);

  /* ---- seeded UI ---- */
  await p.screenshot({ path: out + '-home.png' });
  const nTasks = await p.evaluate(() => __lifeos.all('task').length);
  ok(nTasks === 6, 'seeded tasks ' + nTasks);

  /* complete a recurring task and verify it advances; then undo */
  const water = await p.evaluate(() => { const t = __lifeos.all('task').find(x => x.title === 'Water the plants'); return { id: t.id, due: t.due }; });
  await p.evaluate(id => __lifeos.toggleTask(id), water.id);
  const after = await p.evaluate(id => ({ due: __lifeos.DB.rec[id].due, status: __lifeos.DB.rec[id].status, xp: __lifeos.DB.set.xp }), water.id);
  ok(after.due === (await p.evaluate(d => __lifeos.addDays(d, 3), water.due)) && after.status === 'open' && after.xp === 10, 'recurring task advanced by 3 days: ' + JSON.stringify(after));
  await p.click('[data-act="undo"]');
  const undone = await p.evaluate(id => ({ due: __lifeos.DB.rec[id].due, xp: __lifeos.DB.set.xp }), water.id);
  ok(undone.due === water.due && undone.xp === 0, 'undo restores task and XP ' + JSON.stringify(undone));

  /* ---- create task through the editor UI ---- */
  await p.click('nav [data-go="tasks"]');
  await p.click('[data-act="new"][data-kind="task"]');
  await p.fill('[data-f="title"]', 'Pay the water bill');
  await p.selectOption('[data-f="rule.freq"]', 'monthly');
  await p.selectOption('[data-f="remind"]', '1440');
  await p.screenshot({ path: out + '-editor.png' });
  await p.click('[data-act="ed-save"]');
  const nt = await p.evaluate(() => __lifeos.all('task').find(t => t.title === 'Pay the water bill'));
  ok(nt && nt.rule.freq === 'monthly' && nt.remind === '1440' && nt.anchor === nt.due, 'task created via UI ' + JSON.stringify(nt && nt.rule));

  /* subtasks in the editor */
  await p.click('[data-act="edit"][data-kind="task"]:has-text("Organise the desk")').catch(async () => { await p.click('[data-act="tf"][data-f="all"]'); await p.click('[data-act="edit"][data-kind="task"]:has-text("Organise the desk")'); });
  await p.fill('#newsub', 'Wipe the shelves');
  await p.press('#newsub', 'Enter');
  await p.click('[data-act="ed-save"]');
  const sub = await p.evaluate(() => __lifeos.all('task').find(t => t.title === 'Organise the desk').subs.map(s => s.t));
  ok(sub.length === 3 && sub[2] === 'Wipe the shelves', 'subtask added with Enter ' + sub);

  /* delete -> recycle bin -> restore */
  await p.click('[data-act="tf"][data-f="all"]');
  await p.click('[data-act="edit"][data-kind="task"]:has-text("Reply to one email")');
  await p.click('[data-act="ed-del"]');
  ok(await p.evaluate(() => !__lifeos.all('task').some(t => t.title === 'Reply to one email')), 'deleted task hidden');
  await p.click('[data-act="undo"]');
  ok(await p.evaluate(() => __lifeos.all('task').some(t => t.title === 'Reply to one email')), 'undo delete restores');

  /* ---- calendar ---- */
  await p.click('nav [data-go="calendar"]');
  await p.click('[data-act="new"][data-kind="event"]');
  await p.fill('[data-f="title"]', 'Book club');
  await p.selectOption('[data-f="rule.freq"]', 'weekly');
  await p.click('[data-act="ed-wd"][data-i="2"]');
  await p.click('[data-act="ed-save"]');
  const ev = await p.evaluate(() => __lifeos.all('event').find(e => e.title === 'Book club'));
  ok(ev && ev.rule.freq === 'weekly' && ev.rule.days.join() === '2', 'weekly event created ' + JSON.stringify(ev && ev.rule));
  const tues = await p.evaluate(() => { let d = __lifeos.today(); while (__lifeos.dow(d) !== 2) d = __lifeos.addDays(d, 1); return d; });
  await p.click(`[data-act="day"][data-d="${tues}"]`);
  ok((await p.textContent('#view')).includes('Book club'), 'event shows on a Tuesday');
  await p.screenshot({ path: out + '-calendar.png' });
  await p.click('[data-act="mnext"]'); await p.click('[data-act="mtoday"]');

  /* ---- routines persist across reload ---- */
  await p.evaluate(() => { const r = __lifeos.all('routine')[0]; __lifeos.DB.set._t = r.id; });
  await p.click('nav [data-go="more"]'); await p.click('[data-go="routines"]');
  await p.click('[data-act="rs"] >> nth=0');
  await p.evaluate(() => __lifeos.flush());
  await p.reload(); await p.waitForTimeout(300);
  const stepDone = await p.evaluate(() => { const r = __lifeos.all('routine')[0], td = __lifeos.today(); return r.steps.filter(s => __lifeos.isDone(s.id, td)).length; });
  ok(stepDone === 1, 'routine step persisted after reload ' + stepDone);
  ok(await p.evaluate(() => __lifeos.all('task').some(t => t.title === 'Pay the water bill')), 'tasks persisted after reload');

  /* ---- reminders ---- */
  const rem = await p.evaluate(() => {
    const L = __lifeos; L.DB.set.qOn = false;
    const now = new Date(), t = new Date(now.getTime() - 60000), hh = String(t.getHours()).padStart(2, '0'), mm = String(t.getMinutes()).padStart(2, '0');
    L.add('task', { title: 'Reminder test', cat: 'Personal', pri: 'med', e: 'low', est: 0, due: L.today(), time: `${hh}:${mm}`, rule: { freq: 'none', every: 1, days: [], unit: 'day' }, remind: '0', subs: [], status: 'open' });
    L.tick(); L.tick();
    return { n: L.all('notif').length, titles: L.all('notif').map(n => n.title) };
  });
  ok(rem.n === 1 && rem.titles[0] === 'Task: Reminder test', 'reminder fired exactly once ' + JSON.stringify(rem));
  await p.evaluate(() => __lifeos.render());
  ok((await p.textContent('#hdr')).includes('1'), 'bell badge shows count');
  await p.click('[data-act="bell"]');
  await p.screenshot({ path: out + '-bell.png' });
  await p.click('[data-act="snooze"]');
  ok(await p.evaluate(() => __lifeos.DB.snz.length === 1 && __lifeos.all('notif').length === 0), 'snooze queues and clears');
  await p.evaluate(() => { __lifeos.DB.set.qOn = true; __lifeos.DB.set.qStart = '00:00'; __lifeos.DB.set.qEnd = '23:59'; });
  const quiet = await p.evaluate(() => { __lifeos.DB.snz[0].at = 0; __lifeos.tick(); return __lifeos.all('notif').length; });
  ok(quiet === 0, 'quiet hours hold reminders back');
  await p.evaluate(() => { __lifeos.DB.set.qOn = false; __lifeos.tick(); });
  ok(await p.evaluate(() => __lifeos.all('notif').length === 1), 'snoozed reminder fires after quiet hours');
  await p.keyboard.press('Escape');

  /* ---- search ---- */
  await p.click('[data-act="search"]'); await p.fill('#sq', 'water');
  ok((await p.textContent('#sres')).includes('Pay the water bill'), 'search finds task');
  await p.screenshot({ path: out + '-search.png' });
  await p.keyboard.press('Escape');

  /* ---- settings, themes, export/import ---- */
  await p.click('nav [data-go="more"]'); await p.click('[data-go="settings"]');
  await p.click('[data-act="setv"][data-k="weekStart"][data-v="1"]');
  ok(await p.evaluate(() => __lifeos.DB.set.weekStart === 1), 'week start saved');
  await p.screenshot({ path: out + '-settings.png', fullPage: false });
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-act="export"]')]);
  const file = out + '-backup.json'; await dl.saveAs(file);
  const j = JSON.parse(require('fs').readFileSync(file, 'utf8'));
  ok(j.rec && j.set && Object.keys(j.rec).length > 20, 'export has records ' + Object.keys(j.rec || {}).length);
  await p.evaluate(() => { __lifeos.all('task').forEach(t => __lifeos.DB.rec[t.id].deleted = 1); __lifeos.flush(); });
  await p.setInputFiles('#importFile', file);
  await p.click('[data-act="confirm-yes"]'); await p.waitForTimeout(500);
  ok(await p.evaluate(() => __lifeos.all('task').length > 5), 'import restored tasks');

  /* ---- modes + dark theme screenshots ---- */
  await p.click('nav [data-go="home"]');
  await p.click('[data-act="mode"][data-m="overwhelmed"]');
  await p.screenshot({ path: out + '-overwhelmed.png' });
  await p.click('[data-act="mode"][data-m="normal"]');
  await p.evaluate(() => { __lifeos.DB.set.theme = 'midnight'; __lifeos.render(); });
  await p.screenshot({ path: out + '-dark.png' });
  await p.evaluate(() => { __lifeos.DB.set.theme = 'blush'; __lifeos.render(); });
  await p.click('nav [data-go="tasks"]'); await p.screenshot({ path: out + '-tasks.png' });

  ok(errs.length === 0, 'no console/page errors: ' + errs.join(' | '));
  console.log(`PASS ${pass}  FAIL ${fail}`);
  await b.close();
})().catch(e => { console.log('CRASH', e.message); process.exit(1); });
