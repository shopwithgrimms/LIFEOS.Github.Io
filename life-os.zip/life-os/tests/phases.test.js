/* Phases 3-15 sweep: every view, department, collection and the new feature flows.
   Run: NODE_PATH=$(npm root -g) node tests/phases.test.js <absolute path to app/index.html> <screenshot prefix> */
const { chromium } = require('playwright');
const file = process.argv[2], out = process.argv[3] || '/tmp/ph';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('FAIL:', m); } };
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 430, height: 900 } });
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !/font|net::|Failed to load/i.test(m.text())) errs.push(m.text()); });
  await p.goto('file://' + file);
  await p.waitForTimeout(400);
  const L = () => p.evaluate(() => window.__lifeos);
  const text = s => p.textContent(s || '#view');

  /* ---- every top-level view renders ---- */
  for (const v of ['home','tasks','calendar','life','more','dump','routines','trackers','focus','dopamine','projects','goals','rewards','assistant','insights','settings']) {
    await p.evaluate(v => __lifeos.go(v), v);
    ok((await text()).length > 20, 'view renders: ' + v);
  }

  /* ---- every department + collection renders, and each editor can add an item ---- */
  const map = await p.evaluate(() => __lifeos.DEPTS.map(d => ({ id: d.id, colls: d.colls })));
  ok(map.length >= 20, 'departments defined: ' + map.length);
  let made = 0;
  for (const d of map) {
    await p.evaluate(id => __lifeos.go('dept', id), d.id);
    ok((await text()).length > 20, 'dept renders: ' + d.id);
    for (const c of d.colls) {
      await p.evaluate(a => __lifeos.go('coll', a), d.id + '|' + c);
      ok((await text()).length > 10, 'coll renders: ' + c);
      const before = await p.evaluate(c => __lifeos.itemsOf(c).length, c);
      await p.evaluate(c => __lifeos.openItemEditor(c, null), c);
      ok(await p.isVisible('#modal .sheet'), 'editor opens: ' + c);
      /* fill the title field, whatever its key is */
      await p.evaluate(() => {
        const c = __lifeos.collOf(ED.ctx);
        const k = c.tk, i = document.querySelector(`#modal [data-f="${k}"]`);
        if (i) { i.value = i.tagName === 'SELECT' ? i.options[1].value : c.f.find(f => f.k === k).t === 'date' ? __lifeos.today() : 'Sweep ' + c.id; i.dispatchEvent(new Event('input', { bubbles: true })); }
      });
      await p.click('[data-act="ed-save"]');
      const after = await p.evaluate(c => __lifeos.itemsOf(c).length, c);
      if (after === before + 1) made++; else ok(false, 'item saved: ' + c + ' toast=' + await p.textContent('#toast') + ' d=' + await p.evaluate(() => JSON.stringify(ED && ED.d)));
    }
  }
  ok(made === (await p.evaluate(() => __lifeos.COLLS.length)), 'an item was added to every collection: ' + made);

  /* items appear in calendar and search */
  await p.evaluate(() => __lifeos.go('calendar'));
  ok(true, 'calendar renders with items');
  await p.click('[data-act="search"]');
  await p.fill('#sq', 'Sweep');
  ok((await text('#sres')).includes('Sweep'), 'search finds items');
  await p.click('[data-act="close"]');

  /* ---- goals ---- */
  await p.evaluate(() => __lifeos.go('goals'));
  await p.click('[data-act="goal-tpl"]');
  await p.click('[data-act="goal-tpl-use"][data-i="3"]');
  ok((await text()).includes('Declutter'), 'goal from template opens detail');
  const gid = await p.evaluate(() => Object.values(__lifeos.DB.rec).find(r => r.type === 'goal' && r.title.startsWith('Declutter')).id);
  await p.click('[data-act="ms-tog"][data-i="0"]');
  const gp = await p.evaluate(id => __lifeos.goalProgress(__lifeos.DB.rec[id]), gid);
  ok(gp === 20, 'milestone raises goal progress to 20, got ' + gp);
  await p.click('[data-act="new-link"][data-kind="task"]');
  await p.fill('#modal [data-f="title"]', 'Sort the wardrobe');
  await p.click('[data-act="ed-save"]');
  ok((await text()).includes('Sort the wardrobe'), 'task linked to goal shows on goal');
  const numGoal = await p.evaluate(() => { const g = __lifeos.add('goal', { title: 'Read', gt: 'numeric', target: 10, current: 4, unit: 'books', ms: [], status: 'active' }); return __lifeos.goalProgress(g); });
  ok(numGoal === 40, 'numeric goal progress 40, got ' + numGoal);
  /* project progress */
  const pr = await p.evaluate(() => { const pj = __lifeos.add('project', { title: 'Proj', ms: [{ id: 'a', t: 'x', done: true }, { id: 'b', t: 'y', done: false }], status: 'active' }); return __lifeos.projectProgress(pj); });
  ok(pr === 50, 'project progress 50, got ' + pr);

  /* ---- brain dump parsing and sorting ---- */
  const w = await p.evaluate(() => __lifeos.parseWhen('call the dentist tomorrow at 3pm'));
  ok(w.text === 'Call the dentist' && w.time === '15:00' && w.date === (new Date(Date.now() + 864e5).toLocaleDateString('en-CA')), 'parseWhen ' + JSON.stringify(w));
  const cl = await p.evaluate(() => [__lifeos.classify('buy oat milk').kind, __lifeos.classify('maybe learn pottery').kind, __lifeos.classify('email Sam on friday').kind]);
  ok(cl.join() === 'shop,note,task', 'classify ' + cl);
  await p.evaluate(() => __lifeos.go('dump'));
  await p.fill('#dump-in', 'buy oat milk; call the vet tomorrow; maybe learn pottery');
  await p.click('[data-act="dump-add"]');
  const nd = await p.evaluate(() => __lifeos.all('dump').length);
  ok(nd >= 5, 'dump split into separate thoughts ' + nd);
  await p.click('[data-act="dump-sort"]');
  await p.screenshot({ path: out + '-sort.png' });
  const t0 = await p.evaluate(() => __lifeos.all('task').length);
  await p.click('[data-act="dump-apply"]');
  ok((await p.evaluate(() => __lifeos.all('task').length)) > t0, 'applying sort created tasks');
  ok((await p.evaluate(() => __lifeos.all('dump').length)) < nd, 'sorted thoughts left the dump');

  /* ---- help me pick, break it down ---- */
  await p.evaluate(() => __lifeos.go('tasks'));
  await p.click('[data-act="pick"]');
  ok((await text('#modal')).includes('Try this one'), 'help me pick suggests a task');
  await p.click('[data-act="close"]');
  await p.click('[data-act="new"][data-kind="task"]');
  await p.fill('#modal [data-f="title"]', 'Clean the bathroom');
  await p.click('[data-act="ed-breakdown"]');
  ok((await p.evaluate(() => ED.d.subs.length)) >= 4, 'break it down adds steps');
  await p.click('[data-act="close"]');

  /* ---- focus ---- */
  await p.evaluate(() => __lifeos.go('focus'));
  await p.click('[data-act="f-start"]');
  ok((await p.evaluate(() => !!__lifeos.DB.set.focus)), 'focus session starts');
  await p.fill('#park-in', 'buy stamps');
  await p.click('[data-act="park"]');
  ok((await p.evaluate(() => __lifeos.all('dump').some(d => d.parked))), 'thought parked');
  await p.evaluate(() => { __lifeos.DB.set.focus.end = Date.now() + 1500; });
  await p.waitForTimeout(2600);
  ok((await p.evaluate(() => !__lifeos.DB.set.focus)) && (await p.evaluate(() => __lifeos.DB.rec['l_focus_' + __lifeos.today()]) || {}).value >= 1, 'focus completes and logs minutes');
  await p.click('[data-act="close"]');

  /* ---- dopamine ---- */
  await p.evaluate(() => __lifeos.go('dopamine'));
  await p.click('[data-act="dopa-suggest"]');
  ok((await text('#modal')).includes('How about this'), 'dopamine suggestion');
  await p.click('[data-act="close"]');

  /* ---- finance: pay a bill ---- */
  const bill = await p.evaluate(() => { const b = __lifeos.itemsOf('bill')[0]; return { id: b.id, due: b.due }; });
  await p.evaluate(() => __lifeos.go('coll', 'finance|bill'));
  const ex0 = await p.evaluate(() => __lifeos.itemsOf('expense').length);
  await p.click(`[data-act="ci-paid"][data-id="${bill.id}"]`);
  const b2 = await p.evaluate(id => __lifeos.DB.rec[id].due, bill.id);
  ok(b2 > bill.due, 'paying a bill moves it to next month ' + bill.due + ' -> ' + b2);
  ok((await p.evaluate(() => __lifeos.itemsOf('expense').length)) === ex0 + 1, 'paying a bill logs an expense');

  /* ---- resale profit ---- */
  const prof = await p.evaluate(() => { const r = __lifeos.add('item', { coll: 'resale', name: 'Jacket', status: 'Sold', cost: 10, sold: 40, fees: 5 }); return __lifeos.collOf('resale').badge(r)[0]; });
  ok(prof.includes('25'), 'resale profit 25, got ' + prof);

  /* ---- plants: watering ---- */
  const pl = await p.evaluate(() => __lifeos.itemsOf('plant').find(x => x.name === 'Monstera').id);
  await p.evaluate(() => __lifeos.go('coll', 'garden|plant'));
  await p.click(`[data-act="ci-water"][data-id="${pl}"]`);
  ok((await p.evaluate(id => __lifeos.DB.rec[id].last, pl)) === (await p.evaluate(() => __lifeos.today())), 'watering updates last watered');

  /* ---- flashcards ---- */
  await p.evaluate(() => { __lifeos.itemsOf('card').forEach(r => __lifeos.DB.rec[r.id].due = '2999-01-01'); __lifeos.add('item', { coll: 'card', name: 'Front', back: 'Back', deck: 'x' }); __lifeos.go('coll', 'learning|card'); });
  await p.click('[data-act="study"]');
  await p.click('[data-act="study-show"]');
  ok((await text('#modal')).includes('Back'), 'flashcard reveals answer');
  await p.click('[data-act="study-rate"][data-r="2"]');
  await p.click('[data-act="close"]').catch(() => {});
  await p.screenshot({ path: out + '-study.png' });

  /* ---- calendar shows item dates + attention list ---- */
  const att = await p.evaluate(() => __lifeos.attention().map(a => a.title));
  ok(att.includes('Passport') || att.includes('Retinol serum'), 'attention lists expiring items: ' + att.join());

  /* ---- quests, badges, companion ---- */
  await p.evaluate(() => __lifeos.go('rewards'));
  const t = await text();
  ok(t.includes('Quests') && t.includes('Badges') && t.includes('Level'), 'rewards page shows quests, badges and level');
  await p.click('[data-act="pet-kind"][data-k="bunny"]');
  ok((await p.evaluate(() => __lifeos.DB.set.pet.kind)) === 'bunny', 'companion type changes');
  await p.evaluate(() => { __lifeos.DB.set.coins = 500; });
  await p.evaluate(() => __lifeos.go('rewards'));
  await p.click('[data-act="cos-buy"][data-id="bow"]');
  ok((await p.evaluate(() => __lifeos.DB.set.eq.includes('bow'))), 'buying and wearing an item');
  await p.screenshot({ path: out + '-rewards.png' });

  /* ---- assistant with approval ---- */
  await p.evaluate(() => __lifeos.go('assistant'));
  await p.fill('#ask-in', 'remind me to water the herbs tomorrow at 9am');
  await p.click('[data-act="ask-send"]');
  const tb = await p.evaluate(() => __lifeos.all('task').length);
  ok((await text()).includes('Approve'), 'assistant proposes a plan');
  await p.click('[data-act="plan-ok"]');
  ok((await p.evaluate(() => __lifeos.all('task').length)) === tb + 1, 'approved plan creates the task');
  await p.fill('#ask-in', 'what can I make');
  await p.click('[data-act="ask-send"]');
  ok((await text()).includes('Tomato and egg rice'), 'assistant matches recipes to pantry');
  await p.fill('#ask-in', 'spending summary');
  await p.click('[data-act="ask-send"]');
  ok((await text()).includes('spent'), 'assistant summarises spending');
  await p.fill('#ask-in', 'plan my day');
  await p.click('[data-act="ask-send"]');
  await p.screenshot({ path: out + '-assistant.png' });

  /* ---- insights ---- */
  await p.evaluate(() => __lifeos.go('insights'));
  for (const r of ['month', 'year', 'week']) { await p.click(`[data-act="insr"][data-r="${r}"]`); ok((await text()).includes('Tasks done'), 'insights ' + r); }
  await p.screenshot({ path: out + '-insights.png' });

  /* ---- custom tracker ---- */
  await p.evaluate(() => __lifeos.go('trackers'));
  await p.click('[data-act="tpl-new"]');
  await p.click('[data-act="tpl-use"][data-i="0"]');
  await p.click('[data-act="ed-save"]');
  await p.click('[data-act="tpl-log"]');
  await p.fill('#modal [data-tl]', '61.5');
  await p.click('[data-act="tl-save"]');
  ok((await text()).includes('61.5'), 'custom tracker logs a value');

  /* ---- settings: layout, hide department, text size, lock ---- */
  await p.evaluate(() => __lifeos.go('settings'));
  await p.click('[data-act="wid-tog"][data-id="habits"]');
  await p.click('[data-act="dept-tog"][data-id="vehicle"]');
  await p.click('[data-act="setv"][data-k="ts"][data-v="large"]');
  ok(await p.evaluate(() => document.documentElement.classList.contains('ts-l')), 'text size applies');
  await p.evaluate(() => __lifeos.go('life'));
  ok(!(await text()).includes('Vehicle'), 'hidden department leaves My Life');
  await p.evaluate(() => __lifeos.go('home'));
  ok(!(await text()).includes('HABITS') , 'hidden widget leaves Home');
  await p.click('[data-act="setv"][data-k="ts"][data-v="normal"]').catch(() => {});
  await p.evaluate(() => { __lifeos.DB.set.ts = 'normal'; document.documentElement.className = ''; });
  await p.evaluate(() => __lifeos.go('settings'));
  await p.click('[data-act="pin-set"]');
  await p.fill('#newpin', '1234');
  await p.click('[data-act="pin-save"]');
  await p.click('[data-act="lock-now"]');
  ok(await p.isVisible('#lock'), 'lock screen shows');
  await p.fill('#pin', '0000');
  ok(await p.isVisible('#lock'), 'wrong PIN stays locked');
  await p.fill('#pin', '1234');
  ok(!(await p.isVisible('#lock').catch(() => false)), 'right PIN unlocks');
  await p.click('[data-act="pin-off"]');

  /* ---- calm mode on Home ---- */
  await p.evaluate(() => __lifeos.go('home'));
  await p.click('[data-act="mode"][data-m="overwhelmed"]');
  ok((await text()).includes('Just one thing'), 'calm mode shows one thing');
  await p.screenshot({ path: out + '-calm.png' });
  await p.click('[data-act="mode"][data-m="normal"]');

  /* ---- screenshots of main screens ---- */
  for (const [n, v, a] of [['home', 'home'], ['life', 'life'], ['dept', 'dept', 'finance'], ['coll', 'coll', 'beauty|bprod'], ['goal', 'goal', gid], ['focus', 'focus']]) {
    await p.evaluate(([v, a]) => __lifeos.go(v, a), [v, a]);
    await p.waitForTimeout(450);
    await p.screenshot({ path: `${out}-${n}.png` });
  }
  /* dark theme */
  await p.evaluate(() => { __lifeos.DB.set.theme = 'midnight'; __lifeos.go('home'); });
  await p.waitForTimeout(450);
  await p.screenshot({ path: out + '-dark.png' });

  ok(errs.length === 0, 'no console errors: ' + errs.slice(0, 5).join(' | '));
  console.log(`PASS ${pass}  FAIL ${fail}`);
  await b.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.log('CRASH', e.message.split('\n').slice(0, 4).join(' ')); process.exit(2); });
