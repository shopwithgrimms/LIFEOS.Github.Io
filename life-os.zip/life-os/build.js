// Concatenates src/ into one self-contained app/index.html (no dependencies).
const fs = require('fs'), path = require('path');
const root = __dirname, src = path.join(root, 'src');
const css = fs.readFileSync(path.join(src, 'style.css'), 'utf8');
const js = fs.readdirSync(path.join(src, 'js')).filter(f => f.endsWith('.js')).sort()
  .map(f => fs.readFileSync(path.join(src, 'js', f), 'utf8')).join('\n');
let html = fs.readFileSync(path.join(src, 'index.template.html'), 'utf8');
html = html.replace('/*CSS*/\n', () => css).replace('/*JS*/\n', () => js);
fs.writeFileSync(path.join(root, 'app', 'index.html'), html);
console.log('built app/index.html', (html.length / 1024).toFixed(0) + ' KB');
