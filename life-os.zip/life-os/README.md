<div align="center">

# Life OS

**A personal operating system for the life you actually have.**

One app. Every department of life. Built ADHD-first.

![Status](https://img.shields.io/badge/status-phase%201--2%20working-3B312A)
![Platform](https://img.shields.io/badge/platform-mobile--first-3B312A)
![Design](https://img.shields.io/badge/design-ADHD--friendly-8A8278)
![License](https://img.shields.io/badge/license-MIT-8A8278)

[Vision](#vision) · [Principles](#design-principles) · [Features](#feature-map) · [Architecture](#architecture) · [Roadmap](#roadmap) · [Prototype](#try-the-prototype)

</div>

---

## Vision

Most productivity apps show you how much you haven't done. **Life OS helps you manage the life you have.**

It brings tasks, routines, health, home, money, hobbies, work, goals and memories into a single connected system, where everything is created once and linked everywhere it matters. If you disappear for two weeks because life happens, you open the app and pick up exactly where you left off: no guilt, no broken streaks, no wall of overdue red.

> **Inspired by** Finch (self-care and gamification) · Todoist (tasks) · Notion (databases and customization) · Habitica (habits and quests) · Lose It! / MyFitnessPal (nutrition) · Google Calendar (scheduling)
>
> **The difference:** everything connects, everything is customizable, everything has a place.

---

## Design Principles

| # | Principle | What it means |
|---|-----------|---------------|
| 1 | **No duplicate data** | Create an item once, reference it everywhere. |
| 2 | **Everything is customizable** | Names, frequencies, categories, fields, colors, layouts. |
| 3 | **No forced routines** | You choose what to track. |
| 4 | **No punishment for inactivity** | Missed days never destroy progress. Streaks are optional. |
| 5 | **Every department has history** | Look back at anything you've done. |
| 6 | **Recurrence everywhere** | Never recreate the same task every week. |
| 7 | **Goals have structure** | Goal → Milestones → Projects → Tasks → Habits. |
| 8 | **Mobile-first** | Designed for the phone, not squeezed onto it. |
| 9 | **You own your data** | Export, back up, restore, delete. |
| 10 | **Modular** | Enable, disable, hide and rearrange whole departments. |
| 11 | **Privacy first** | Health, finance and personal data are protected by default. |
| 12 | **One unified experience** | Every department looks and behaves the same way. |

---

## Feature Map

### Primary navigation

`Home` · `My Day` · `Brain Dump` · `Tasks` · `Calendar` · `Routines` · `Trackers` · `My Life` · `Projects` · `Goals` · `Rewards` · `AI Assistant` · `Insights` · `Settings`

Navigation is collapsible, searchable and mobile-friendly.

### ADHD Command Center

The defining feature set.

| Mode / Tool | Behavior |
|---|---|
| **Overwhelmed Mode** | Hides nonessential widgets, shows only what's urgent, suggests one small starting action. |
| **Low-Energy Mode** | Filters to minimal-effort, five-minute and seated tasks. |
| **Hyperfocus Mode** | Focus timer, parked distractions, optional breaks, gentle end-of-session transition. |
| **Time-Blindness Support** | Visual timers, estimates, appointment countdowns, transition warnings. |
| **Restart Mode** | Returning after a break: no overdue punishment, review what matters, reschedule recurring items, rebuild gradually. |
| **Dopamine Menu** | Personal activity list (quick / relaxing / active / productive) suggested by time and energy. |
| **Task tools** | Break-down assistant, start-task button, Pomodoro, body doubling, decision help. |

### Life Departments

| Area | Departments |
|---|---|
| **Mind** | Brain Dump & Knowledge Library · Memories & Journaling · Learning & Education |
| **Body** | Health & Medical · Food, Nutrition & Meal Planning · Fitness · Sleep & Recovery |
| **Self-care** | Skincare · Haircare · Body care · Makeup · Nails · Oral care |
| **Home** | Cleaning & Laundry · Rooms · Home Maintenance & Appliances · Household Inventory · Gardening & Plants |
| **Money** | Income · Expenses · Budgets · Bills · Savings · Debt · Subscriptions · Shopping & Wishlists |
| **Work** | General Work · Optional business workspace (inventory, listings, orders, finances, operations) |
| **Play** | Hobbies · Gaming · Movies · TV · Books · Music · Travel & Experiences · Bucket List |
| **People & Things** | Social & Relationships · Gifts · Pets · Vehicles · Wardrobe & Personal Inventory |
| **Admin** | Life Admin (documents, renewals, warranties, taxes) · Digital Life |

### Goals System

Turn any ambition into a structured, achievable plan.

- **7 goal types:** numeric · completion · consistency · maintenance · learning · financial · experience
- **Breakdown:** `Goal → Milestones → Projects → Tasks → Habits`, progress calculated automatically
- **Timeframes:** today → lifetime, or no deadline
- **Tools:** templates, planner, breakdown generator, obstacle tracking, weekly / monthly / yearly reviews
- **Vision Board** linked to real goals · **Bucket List** for experiences

### Gamification

A customizable companion that grows with you. XP, coins, levels, badges, quests (daily / weekly / seasonal), a decorated personal space, and a **custom real-life reward shop**. Missing a day never costs progress.

### AI Life Assistant

Cross-app understanding (permission-based) for daily planning, organizing projects, routine building, "what can I make with what I have?", spending summaries, goal breakdowns and "what am I forgetting?" **All changes require user approval.**

### Insights

Descriptive, never judgmental. Daily, weekly, monthly and yearly reports on tasks, habits, mood, energy, sleep, nutrition, spending, hobbies and accomplishments.

---

## Architecture

Life OS is built on **universal engines** that every department shares, which is how "no duplicate data" becomes real.

```mermaid
flowchart TB
    subgraph DEPT["Life Departments"]
        D1[Skincare] --- D2[Cleaning] --- D3[Finance] --- D4[Hobbies] --- D5[...]
    end
    subgraph ENG["Universal Engines"]
        T[Tasks] --- S[Scheduling & Recurrence] --- I[Inventory] --- N[Notifications]
        R[Routines & Habits] --- G[Goals & Projects] --- A[Analytics] --- X[Templates]
    end
    subgraph EXP["Experience Layers"]
        ADHD[ADHD Systems] --- GAME[Gamification] --- AI[AI Assistant] --- DASH[Dashboards]
    end
    DEPT --> DB[(Universal Database)]
    ENG --> DB
    EXP --> DB
```

### Core engines

| Engine | Responsibility |
|---|---|
| Database | Shared records and relationships |
| Task | Universal tasks |
| Calendar | Events and views |
| Recurrence | Every repeating pattern |
| Reminder | Notifications, quiet hours, snooze |
| Inventory | Quantity, expiry, reorder thresholds |
| Routine | Routines and habits |
| Goal / Project | Goals, milestones, projects |
| Tracking | Activity history |
| Analytics | Statistics |
| Template | User-built custom trackers |
| Gamification | XP and rewards |
| AI | Assistant and suggestions |
| Search | Global search |
| Backup | Export, restore, recovery |
| Attachment | Photos and documents |

### Universal records

`Product` · `Task` · `Event` · `Routine` · `Habit` · `Goal` · `Project` · `Person` · `Location` · `Document` · `Purchase` · `Inventory item` · `Note` · `Attachment`

Example: one moisturizer record links to skincare inventory, morning and evening routines, the wishlist, spending history and the expiration tracker.

### Proposed repository layout

```
life-os/
├── core/                 # auth, database, settings, navigation, search, notifications
├── engines/              # tasks, calendar, recurrence, inventory, reminders, goals, analytics
├── departments/          # skincare, health, cleaning, finance, hobbies, ...
├── adhd/                 # overwhelmed, focus, low-energy, restart, dopamine menu
├── gamification/         # companion, xp, rewards, quests
├── assistant/            # planning, organization, recommendations
├── dashboards/           # home, work, business, custom
├── backups/              # export, restore, recovery
├── app/                  # the working app (Phases 1-2)
├── prototype/            # original design preview
├── tests/
└── docs/
```

### Suggested stack (open for discussion)

| Layer | Option |
|---|---|
| App | React Native / Expo, or a PWA (React + TypeScript) |
| Local-first storage | SQLite / IndexedDB with sync |
| Backend (optional) | Supabase or Postgres + API |
| Auth | Passkeys / OAuth, app lock |
| Security | Encryption at rest for sensitive departments |

---

## Roadmap

The app should be **usable after every phase**.

- [x] **Phase 1:** Core, database, settings, navigation *(Critical)*
- [x] **Phase 2:** Tasks, routines, calendar, reminders *(Critical)*
- [x] **Phase 3:** Goals, projects, habits *(Critical)*
- [x] **Phase 4:** Brain dump and ADHD tools *(Critical)*
- [x] **Phase 5:** Skincare, beauty, personal care
- [x] **Phase 6:** Cleaning and household
- [x] **Phase 7:** Health, nutrition, fitness
- [x] **Phase 8:** Finance and shopping
- [x] **Phase 9:** Hobbies and entertainment
- [x] **Phase 10:** Work and business
- [x] **Phase 11:** Pets, vehicle, travel, life admin
- [x] **Phase 12:** Memories and learning
- [x] **Phase 13:** Gamification and companion
- [x] **Phase 14:** AI assistant and automation
- [x] **Phase 15:** Advanced analytics and customization

---

## Privacy & Safety

- Health, finance and document departments support app lock and encryption.
- Medical tracking is informational and not a substitute for professional care.
- Passwords are **never** stored in notes; use a dedicated password manager.
- Full export, backup and deletion controls.

---

## Run the App

The working app lives in [`app/index.html`](app/index.html): one file, no build step, no dependencies. Your data is stored on your device (`localStorage`) and never leaves it.

```bash
open app/index.html          # or serve it: npx serve app
```

On a phone, host the folder anywhere static (GitHub Pages works) and use *Add to Home Screen*.

**Built (all 15 phases)**

| Area | What works |
|---|---|
| Data layer | Universal records, soft delete with recycle bin, undo, JSON export and import, global search across everything |
| Tasks and calendar | Notes, category, priority, energy, estimate, subtasks, project, goal and area links, recurrence (daily, weekly, monthly, yearly, every N, after I finish it, skip one) |
| Goals and projects | Seven goal types, milestones, linked tasks, projects and habits, automatic progress, reviews, templates |
| ADHD tools | Calm and Low-energy modes, Restart prompt, Focus timer with parking lot and body doubling, Dopamine menu, Help me pick, Break it down, Brain Dump sorter with approval, transition warnings |
| Departments | 22 departments and about 55 lists: beauty, health, food and pantry, fitness, sleep, home, plants, finance (bills, budgets, subscriptions, savings, debt), shopping, work and resale profit, hobbies, media, travel, people and gifts, pets, vehicle, wardrobe, life admin, digital, learning with flashcards, journal |
| Connected data | Item dates reach the calendar and reminders, low stock and expiry alerts, a "needs a look" list, paying a bill logs an expense |
| Companion and rewards | Companion with items, daily, weekly and monthly quests, badges, your own real-life reward shop. Progress never goes down |
| Assistant | Plan my day, what am I forgetting, what can I make from my pantry, spending summary, break things down, add tasks. Every change is shown first and needs your approval |
| Insights | Week, month and year: completions, focus time, mood, spending, productive hour, unused departments |
| Customization | Custom tracker builder, 12 themes, text size, reduced motion, high contrast, home widget order and presets, hide departments, currency, PIN lock |

**Honest limits**

- Reminders fire while the app is open. Background push needs a backend.
- The assistant is rule-based and runs on your device. It is not a language model and will say so when it does not understand.
- The PIN lock hides the screen. It does not encrypt your data.
- Data lives in this browser only. Use Export for backups. There is no sync yet.
- Photos and file attachments, formulas in the tracker builder and a decorated companion room are not built.

### Source layout

`app/index.html` is generated. Edit the modules in `src/` and rebuild:

```bash
node build.js
```

| File | Responsibility |
|---|---|
| `src/js/00-14` | Core: icons, themes, dates, data, recurrence, reminders, editors, views, events |
| `src/js/20-21` | Collection engine and department schemas. Add a department by adding a `C({...})` entry |
| `src/js/22` | Home widgets, My Life, department views, settings, lock |
| `src/js/30-35` | Goals, ADHD tools, companion and quests, assistant, insights, tracker builder |

### Tests

`tests/app.test.js` covers the recurrence engine and the core UI. `tests/phases.test.js` opens every department and list, adds an item to each, and exercises goals, focus, brain dump, assistant approval, quests, insights, trackers, settings and the lock.

```bash
npm i playwright
node tests/app.test.js "$PWD/app/index.html" /tmp/lifeos
node tests/phases.test.js "$PWD/app/index.html" /tmp/lifeos-ph
```

### Design preview

[`prototype/index.html`](prototype/index.html) is the original static design shell, kept for reference.

---

## Contributing

Ideas, issues and PRs are welcome. When proposing a feature, please note which **engine** it extends and how it honors the [design principles](#design-principles), especially *no punishment for inactivity*.

## License

MIT: see `LICENSE`.

---

<div align="center">

*Open it again after two weeks away. Pick up where you left off.*

</div>
