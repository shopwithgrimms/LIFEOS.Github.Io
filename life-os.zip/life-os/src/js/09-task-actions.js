/* ---------- TASK ACTIONS ---------- */
function toggleTask(id){
  const t=DB.rec[id];if(!t)return;
  const snap=JSON.stringify(t),xp0=DB.set.xp,c0=DB.set.coins,td=today(),ck=cid(id,td),had=DB.rec[ck]?JSON.stringify(DB.rec[ck]):null;
  if(t.status==='done'){upd(id,{status:'open'});setDone(id,td,false);gain(-10,-5);toast('Marked as not done');return}
  setDone(id,td,true,'task');
  if(isRepeating(t)){const n=nextDue(t,t.due>td?t.due:td);if(n)upd(id,{due:n,subs:(t.subs||[]).map(s=>Object.assign({},s,{done:false}))});else upd(id,{status:'done'})}
  else upd(id,{status:'done'});
  gain(10,5);
  toast(isRepeating(t)&&DB.rec[id].status!=='done'?`Done. Next: ${dayLabel(DB.rec[id].due)}`:'Done. +10 XP',()=>{DB.rec[id]=JSON.parse(snap);if(had)DB.rec[ck]=JSON.parse(had);else delete DB.rec[ck];DB.set.xp=xp0;DB.set.coins=c0;persist();render(true)});
}
function toggleStep(rid,sid){const td=today(),on=!isDone(sid,td);setDone(sid,td,on,'step');if(on)gain(5,2);else gain(-5,-2)}
function toggleHabit(id){const td=today(),on=!isDone(id,td);setDone(id,td,on,'habit');if(on){gain(8,3);toast('Habit done. +8 XP')}else gain(-8,-3)}

