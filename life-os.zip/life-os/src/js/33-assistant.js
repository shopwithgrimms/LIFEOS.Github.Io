/* ---------- ASSISTANT ----------
   Rule-based, runs entirely on this device. It reads your data to answer, and
   anything that would change your data is shown as a plan you approve first. */
const PLANS={};
let planN=0;
const mkPlan=(lines,apply)=>{const id='p'+(++planN);PLANS[id]={lines,apply};return id};
const lc=s=>String(s||'').toLowerCase();
const listText=a=>a.length<=1?(a[0]||''):a.slice(0,-1).join(', ')+' and '+a[a.length-1];
const stripQty=s=>lc(s).replace(/^[\d\s\/.,-]+(g|kg|ml|l|tsp|tbsp|cups?|oz|lb|pinch|cloves?|tins?|cans?)?\b\s*(of\s+)?/,'').replace(/[^a-z\s]/g,'').trim();

function planDay(){
  const td=today(),nm=nowMins(),busy=[];
  all('event',e=>occursOn(e,td)&&e.start).forEach(e=>busy.push([mins(e.start),e.end?mins(e.end):mins(e.start)+60]));
  all('task',t=>t.status!=='done'&&t.due===td&&t.time).forEach(t=>busy.push([mins(t.time),mins(t.time)+(t.est||30)]));
  busy.sort((a,b)=>a[0]-b[0]);
  let l=dueBy(td).filter(t=>!t.time).sort(byDue);
  const sc=t=>({high:0,med:1,low:2}[t.pri]);
  l=l.sort((a,b)=>(a.due<td)-(b.due<td)||sc(a)-sc(b)).slice(0,6);
  if(DB.set.mode==='low')l=l.filter(t=>t.e==='low');
  if(!l.length)return{t:'Nothing is waiting for a time slot today. Your day is clear.'};
  let cur=Math.max(Math.ceil(nm/15)*15,9*60);const out=[];
  for(const t of l){
    const dur=t.est||20;
    for(let i=0;i<busy.length;i++){if(cur<busy[i][1]&&cur+dur>busy[i][0])cur=Math.ceil(busy[i][1]/15)*15}
    if(cur+dur>21*60)break;
    out.push({t,at:`${pad(Math.floor(cur/60))}:${pad(cur%60)}`,dur});cur+=dur+10;
  }
  if(!out.length)return{t:'There is not much of the day left. Pick one small thing and call it a win.'};
  const lines=out.map(o=>`${fmtTime(o.at)}  ${o.t.title} (${o.dur} min)`);
  const ex=busy.length?` I worked around ${busy.length} fixed item${busy.length>1?'s':''}.`:'';
  return{t:`Here is a gentle plan with breaks between tasks.${ex}`,plan:mkPlan(lines,()=>{const prev=out.map(o=>[o.t.id,o.t.time||'']);out.forEach(o=>upd(o.t.id,{time:o.at}));return()=>prev.forEach(p=>upd(p[0],{time:p[1]}))}),pt:'Put these on today as time blocks?'};
}
function forgetting(){
  const td=today(),over=openTasks().filter(t=>t.due&&t.due<td),att=attention(8),dn=all('dump').length,out=[];
  if(over.length)out.push(`${over.length} task${over.length>1?'s are':' is'} past their date: ${listText(over.slice(0,3).map(t=>t.title))}${over.length>3?', and more':''}. You can move them all to today from the Home screen.`);
  att.forEach(a=>out.push(`${a.title}: ${a.text.toLowerCase()}.`));
  if(dn)out.push(`${dn} thought${dn>1?'s':''} sitting in your brain dump.`);
  const low=all('task',t=>t.status!=='done'&&!t.due).length;if(low)out.push(`${low} task${low>1?'s have':' has'} no date.`);
  return{t:out.length?`Here is what might need a look:\n\n${out.map(x=>'- '+x).join('\n')}`:'Nothing is slipping that I can see. You are on top of it.'};
}
function whatCanIMake(){
  const pantry=itemsOf('pantry').filter(p=>p.qty===''||p.qty==null||+p.qty>0).map(p=>stripQty(p.name)),rec=itemsOf('recipe');
  if(!rec.length)return{t:'Add a few recipes under Food and nutrition and I can match them to your pantry.'};
  if(!pantry.length)return{t:'Your pantry is empty. Add what you have under Food and nutrition and I can suggest recipes.'};
  const have=ing=>pantry.some(p=>p&&ing&&(p.includes(ing)||ing.includes(p)));
  const ranked=rec.map(r=>{const ings=(r.ing||'').split('\n').map(stripQty).filter(Boolean),miss=ings.filter(i=>!have(i));return{r,n:ings.length,miss}}).filter(x=>x.n).sort((a,b)=>(a.miss.length/a.n)-(b.miss.length/b.n)).slice(0,3);
  if(!ranked.length)return{t:'Your recipes have no ingredient lists yet. Add one ingredient per line.'};
  const top=ranked[0];
  const txt=ranked.map(x=>`- ${x.r.name}: ${x.miss.length?`missing ${listText(x.miss)}`:'you have everything'}`).join('\n');
  const res={t:`Best matches for what is in your pantry:\n\n${txt}`};
  if(top.miss.length)res.plan=mkPlan(top.miss.map(m=>`Add "${m}" to the shopping list`),()=>{const ids=top.miss.map(m=>add('item',{coll:'shop',name:m}).id);return()=>ids.forEach(purge)}),res.pt=`Add what is missing for ${top.r.name} to your shopping list?`;
  return res;
}
function spendSummary(){
  const ex=itemsOf('expense').filter(r=>inMonth(r)),by={};
  ex.forEach(r=>by[r.cat||'Other']=(by[r.cat||'Other']||0)+(+r.amount||0));
  const inc=sumBy(itemsOf('income').filter(r=>inMonth(r)),'amount'),tot=sumBy(ex,'amount'),top=Object.entries(by).sort((a,b)=>b[1]-a[1]).slice(0,4);
  if(!ex.length&&!inc)return{t:'No spending or income logged this month yet. Add expenses under Finance and I will summarise them.'};
  const over=itemsOf('budget').filter(b=>b.limit&&(by[b.name]||0)>+b.limit).map(b=>b.name),subs=itemsOf('sub').reduce((a,r)=>a+(r.cycle==='Yearly'?(+r.cost||0)/12:(+r.cost||0)),0);
  return{t:`This month you have spent ${money(tot)}${inc?` and earned ${money(inc)}`:''}.\n\n${top.map(x=>`- ${x[0]}: ${money(x[1])}`).join('\n')}${over.length?`\n\nOver budget in ${listText(over)}.`:''}${subs?`\n\nSubscriptions come to about ${money(subs)} a month.`:''}`};
}
function breakdownFor(q){
  const m=q.match(/(?:break(?:ing)?\s*(?:down)?|steps for|split up|split)\s+(.+)/i),sub=(m?m[1]:q).replace(/^(my|the|a)\s+/i,'').replace(/[?.!]+$/,'').trim();
  if(!sub)return{t:'What would you like to break down? Try "break down clean the kitchen".'};
  const steps=breakSteps(sub),s=lc(sub),task=openTasks().find(t=>lc(t.title).includes(s)||s.includes(lc(t.title))),goal=all('goal').find(g=>lc(g.title).includes(s)||s.includes(lc(g.title)));
  if(task){const have=new Set((task.subs||[]).map(x=>x.t)),add_=steps.filter(x=>!have.has(x));return{t:`Here are steps for "${task.title}".`,plan:mkPlan(add_.map(x=>`Subtask: ${x}`),()=>{const prev=task.subs||[];upd(task.id,{subs:[...prev,...add_.map(t=>({id:uid(),t,done:false}))]});return()=>upd(task.id,{subs:prev})}),pt:'Add these as subtasks?'}}
  const title=goal?goal.title:sub[0].toUpperCase()+sub.slice(1);
  return{t:`Here is one way to start "${title}".`,plan:mkPlan(steps.map(x=>`Task: ${x}`),()=>{const ids=steps.map(x=>add('task',Object.assign(EDITORS.task.blank(),{title:x,due:'',goal:goal?goal.id:'',cat:guessCat(sub)})).id);return()=>ids.forEach(purge)}),pt:`Create these as tasks${goal?' linked to the goal':''}?`};
}
function createTaskFor(q){
  const body=q.replace(/^(remind me to|remind me|add (a )?task( to)?|todo:?|i need to|remember to)\s*/i,''),w=parseWhen(body);
  if(!w.text)return{t:'What should I add? Try "remind me to call the dentist tomorrow at 3pm".'};
  const when=[w.date&&dayLabel(w.date),w.time&&fmtTime(w.time)].filter(Boolean).join(' at ');
  return{t:'Got it.',plan:mkPlan([`Task: ${w.text}${when?` (${when})`:''}`],()=>{const r=add('task',Object.assign(EDITORS.task.blank(),{title:w.text,due:w.date||'',time:w.time,anchor:w.date||'',cat:guessCat(w.text),remind:w.time?'10':'none'}));return()=>purge(r.id)}),pt:'Add this task?'};
}
function weekSummary(){
  const n=compsSince(7),d=actDays(7),foc=sumBy(all('log',l=>l.kind==='focus'&&l.date>=addDays(today(),-6)).map(l=>({v:l.value})),'v');
  return{t:`In the last 7 days you completed ${n} thing${n===1?'':'s'} across ${d} day${d===1?'':'s'}${foc?` and focused for ${foc} minutes`:''}. ${n?'That is real progress.':'A quiet week is fine. Start with one small thing when you are ready.'}`};
}
const HELP='I can help with:\n\n- Plan my day\n- What am I forgetting?\n- What can I make?\n- Spending summary\n- Break down [a task or goal]\n- Remind me to [thing] tomorrow at 3pm\n- Add [item] to my shopping list\n- How was my week?';
function answer(q){
  const l=lc(q);let m;
  if(/(plan|organi[sz]e|schedule).*(day|today)|what should i do|time block/.test(l))return planDay();
  if(/forget|overlook|slipping|what.*(need|should).*(know|check)|needs? attention/.test(l))return forgetting();
  if((m=l.match(/add (.+?) to (?:my |the )?(?:shopping|grocery)(?: list)?/))){const it=m[1].replace(/^(some|a|an)\s+/,'');return{t:'Sure.',plan:mkPlan([`Shopping list: ${it}`],()=>{const r=add('item',{coll:'shop',name:it[0].toUpperCase()+it.slice(1)});return()=>purge(r.id)}),pt:'Add it to your shopping list?'}}
  if(/what can i (make|cook)|recipe|with what i have|dinner idea|what.*(eat|cook)/.test(l))return whatCanIMake();
  if(/spen[dt]|expenses?|budget|how much money/.test(l))return spendSummary();
  if(/break.*down|steps for|split (this|up)/.test(l))return breakdownFor(q);
  if(/^(remind me|add (a )?task|todo|i need to|remember to)/.test(l))return createTaskFor(q);
  if(/brain ?dump|sort.*(thoughts|dump)/.test(l))return{t:`You have ${all('dump').length} thought${all('dump').length===1?'':'s'} in your brain dump. I can suggest where each one goes, and you approve before anything moves.`,go:['dump','Open Brain Dump']};
  if(/week|summary|how am i doing|progress/.test(l))return weekSummary();
  return{t:`I am not sure how to help with that yet. I work from simple rules, so I do best with the things below.\n\n${HELP}`};
}
function ask(q){
  q=q.trim();if(!q)return;
  chatLog.push({r:'me',t:q});chatLog.push(Object.assign({r:'ai'},answer(q)));
  render(true);const s=$('#scroll');s.scrollTop=s.scrollHeight;
}
V.assistant=function(){
  const chips=['Plan my day','What am I forgetting?','What can I make?','Spending summary','How was my week?'];
  return `<div class="stack"><p class="xs sub">Runs on this device using simple rules. It reads your data to answer and never changes anything without your approval.</p>
  <div class="chips">${chips.map(c=>`<button class="chip" data-act="ask-chip" data-q="${c}">${c}</button>`).join('')}</div>
  <div class="chat">${chatLog.length?chatLog.map((m,i)=>`<div class="msg ${m.r}" style="white-space:pre-wrap">${esc(m.t)}${m.plan&&PLANS[m.plan]?`<div class="card" style="margin-top:10px;padding:12px;background:var(--card);color:var(--text)"><div class="b" style="font-size:12px;margin-bottom:6px">${esc(m.pt||'Proposed changes')}</div>${PLANS[m.plan].lines.map(x=>`<div class="xs" style="padding:2px 0">${esc(x)}</div>`).join('')}${m.st?`<div class="xs sub" style="margin-top:8px">${m.st==='ok'?'Done':'Dismissed'}</div>`:`<div class="grid2" style="margin-top:10px"><button class="btn btn-line btn-sm" data-act="plan-no" data-i="${i}">Dismiss</button><button class="btn btn-primary btn-sm" data-act="plan-ok" data-i="${i}">Approve</button></div>`}</div>`:''}${m.go?`<div style="margin-top:8px"><button class="btn btn-soft btn-sm" data-go="${m.go[0]}">${m.go[1]}</button></div>`:''}</div>`).join(''):`<div class="msg ai" style="white-space:pre-wrap">Hi. What would you like help with?\n\n${HELP}</div>`}</div>
  <div class="row" style="position:sticky;bottom:8px;gap:8px"><div class="grow"><input class="input" id="ask-in" placeholder="Ask or tell me something" data-enter="ask-send" autocomplete="off"></div><button class="icon-btn p" data-act="ask-send" aria-label="Send">${ic('send')}</button></div></div>`;
};
ACT['ask-send']=()=>{const el=$('#ask-in');ask(el.value);return false};
ACT['ask-chip']=d=>{ask(d.q);return false};
ACT['plan-ok']=d=>{const m=chatLog[+d.i],p=PLANS[m.plan];if(!p||m.st)return false;const undo=p.apply();m.st='ok';toast('Done',()=>{undo();m.st=null;render(true)})};
ACT['plan-no']=d=>{chatLog[+d.i].st='no'};
