/* ---------- HELPERS ---------- */
const $=s=>document.querySelector(s);
const esc=t=>String(t==null?'':t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const pct=(a,b)=>b?Math.round(a/b*100):0;
const fmtTime=t=>{if(!t)return'';const[h,m]=t.split(':').map(Number);if(!DB.set.clock12)return t;return `${h%12||12}:${pad(m)} ${h<12?'AM':'PM'}`};
const dayLabel=s=>{const t=today();if(s===t)return'Today';if(s===addDays(t,1))return'Tomorrow';if(s===addDays(t,-1))return'Yesterday';return parse(s).toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'})};
const longDay=s=>parse(s).toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'});
const CATS=['Personal','Household','Health','Beauty','Fitness','Shopping','Financial','Work','Hobbies','Learning','Social','Pets','Vehicle','Plants','Travel','Admin','Digital'];
const PRI={low:'Low',med:'Medium',high:'High'};
const EN={low:['Low energy','ok'],med:['Medium','warn'],high:['High','brand']};
const MODE={normal:'Standard',overwhelmed:'Overwhelmed',low:'Low energy'};
const REMIND=[['none','No reminder'],['0','At the time'],['5','5 minutes before'],['10','10 minutes before'],['30','30 minutes before'],['60','1 hour before'],['1440','1 day before']];
let tt,undoFn=null;
function toast(m,undo){const t=$('#toast');undoFn=undo||null;t.innerHTML=esc(m)+(undo?`<button data-act="undo">Undo</button>`:'');t.classList.toggle('act',!!undo);t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),undo?5000:1800)}
function applyTheme(){
  const t=THEMES[DB.set.theme]||THEMES.blush,r=document.documentElement.style;
  r.setProperty('--p',t.p);r.setProperty('--p-soft',t.soft);r.setProperty('--p-dark',t.d?t.p:t.dark);
  r.setProperty('--bg',t.bg);r.setProperty('--card',t.card);r.setProperty('--text',t.text);r.setProperty('--sub',t.sub);r.setProperty('--line',t.line);
  r.setProperty('--on-p',lum(t.p)>.45?'#1a1a1a':'#ffffff');
  document.querySelector('meta[name=theme-color]').content=t.bg;
}
function ring(v,size,sw=7,label=true){const R=(size-sw)/2,C=2*Math.PI*R;return `<div class="ring" style="width:${size}px;height:${size}px"><svg viewBox="0 0 ${size} ${size}"><circle cx="${size/2}" cy="${size/2}" r="${R}" fill="none" stroke="color-mix(in srgb,var(--sub) 18%,transparent)" stroke-width="${sw}"/><circle cx="${size/2}" cy="${size/2}" r="${R}" fill="none" stroke="var(--p)" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-Math.min(100,v)/100)}"/></svg>${label?`<b style="font-size:${Math.round(size/4.4)}px">${v}%</b>`:''}</div>`}
const check=(on,attrs)=>`<button class="check ${on?'on':''}" ${attrs} aria-label="Toggle">${ic('check')}</button>`;
const emptyBox=(i,h,p)=>`<div class="empty">${ic(i)}<h4>${h}</h4><p class="xs">${p}</p></div>`;
const stickyAdd=(act,label)=>`<div class="sticky-bar"><button class="btn btn-primary block" data-act="${act}">${ic('plus')}${label}</button></div>`;
const greeting=()=>{const h=new Date().getHours();return h<12?'Good morning':h<18?'Good afternoon':'Good evening'};
const byDue=(a,b)=>(a.due||'9999').localeCompare(b.due||'9999')||(a.time||'').localeCompare(b.time||'')||(['high','med','low'].indexOf(a.pri)-['high','med','low'].indexOf(b.pri));

/* tasks */
const openTasks=()=>all('task',t=>t.status!=='done');
const dueBy=ds=>openTasks().filter(t=>t.due&&t.due<=ds);
function routineOn(r,ds){return r.days&&r.days.length?r.days.includes(dow(ds)):true}
function dayItems(ds){
  const out=[];
  all('event',e=>occursOn(e,ds)).forEach(e=>out.push({date:ds,time:e.start||'',title:e.title,kind:'event',id:e.id,sub:[e.end&&`until ${fmtTime(e.end)}`,e.loc].filter(Boolean).join(' · ')}));
  all('task',t=>t.status!=='done'&&t.due===ds&&t.time).forEach(t=>out.push({date:ds,time:t.time,title:t.title,kind:'task',id:t.id,sub:t.cat}));
  all('routine',r=>routineOn(r,ds)&&r.time).forEach(r=>out.push({date:ds,time:r.time,title:r.title,kind:'routine',id:r.id,sub:`${r.steps.length} steps`}));
  out.push(...itemCalItems(ds));
  return out.sort((a,b)=>a.time.localeCompare(b.time));
}
function hasStuff(ds){return itemCalItems(ds).length>0||all('event',e=>occursOn(e,ds)).length>0||all('task',t=>t.status!=='done'&&t.due===ds).length>0}
function progressToday(){
  const td=today();
  const doneT=all('comp',c=>c.kind==='task'&&c.date===td).length,openT=dueBy(td).length;
  const rs=all('routine',r=>routineOn(r,td)).flatMap(r=>r.steps),doneS=rs.filter(s=>isDone(s.id,td)).length;
  const hb=all('habit'),doneH=hb.filter(h=>isDone(h.id,td)).length;
  const total=doneT+openT+rs.length+hb.length,done=doneT+doneS+doneH;
  return{done,total,pct:total?pct(done,total):0};
}
function weekDots(h){const td=today();return Array.from({length:7},(_,i)=>isDone(h.id,addDays(td,i-6)))}


/* titles and kinds across every record type (used by search and the recycle bin) */
const KINDS={task:'Task',event:'Event',routine:'Routine',habit:'Habit',goal:'Goal',project:'Project',dump:'Thought',reward:'Reward',item:'Item',tpl:'Tracker'};
const recTitle=r=>r.type==='item'?itemTitle(r):(r.title||'');
const kindOf=r=>r.type==='item'?(collOf(r.coll)?collOf(r.coll).noun:null):KINDS[r.type];
