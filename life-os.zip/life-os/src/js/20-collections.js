/* ---------- COLLECTION ENGINE ----------
   Every department is built from collections. A collection is a schema (fields),
   and its records are stored as {type:'item', coll:<id>, ...fields} in the same
   universal store as everything else. Dates on items show up on the calendar and
   in reminders automatically (see `cal`), quantities drive low-stock alerts. */
const cur=()=>DB.set.cur||'$';
const money=n=>{const v=+n||0;return (v<0?'-':'')+cur()+Math.abs(v).toLocaleString(undefined,{minimumFractionDigits:v%1?2:0,maximumFractionDigits:2})};
const COLLS=[],DEPTS=[];
const collF={};
/* field tuple: [key,label,type,options,flags]  types: text area num money date time sel ref check; flag 'n' = default today */
const mkF=a=>({k:a[0],l:a[1],t:a[2]||'text',o:a[3],n:(a[4]||'').includes('n')});
function C(o){o.f=o.f.map(mkF);o.show=o.show||[];COLLS.push(o);return o}
const D=o=>{DEPTS.push(o);return o};
const collOf=id=>COLLS.find(c=>c.id===id);
const deptOf=id=>DEPTS.find(d=>d.id===id);
const itemsOf=id=>all('item',r=>r.coll===id);
const itemTitle=r=>{const c=collOf(r.coll);return c?(r[c.tk]||c.noun):'Item'};
const optsOf=f=>typeof f.o==='function'?f.o():(f.o||[]);
const monthKey=d=>(d||today()).slice(0,7);
const inMonth=(r,k='date')=>r[k]&&r[k].slice(0,7)===monthKey();
const sumBy=(l,k)=>l.reduce((a,r)=>a+(+r[k]||0),0);

function fmtF(c,r,k){
  const f=c.f.find(x=>x.k===k),v=r[k];if(v==null||v==='')return'';
  if(f.t==='money')return money(v);if(f.t==='date')return dayLabel(v);if(f.t==='time')return fmtTime(v);
  if(f.t==='ref'){const x=DB.rec[v];return x?itemTitle(x):''}
  if(f.t==='check')return v?f.l:'';
  if(f.t==='num'&&f.o&&typeof f.o==='string')return `${v} ${f.o}`;
  return String(v);
}
const subOf=(c,r)=>c.sub?c.sub(r):c.show.map(k=>fmtF(c,r,k)).filter(Boolean).join(' · ');

function itemRow(c,r){
  const b=c.badge?c.badge(r):null;
  const tog=c.tog?check(!!r[c.tog],`data-act="ci-tog" data-id="${r.id}"`):'';
  return `<div class="item ${c.tog&&r[c.tog]?'done':''}">${tog}<button class="grow" style="text-align:left" data-act="edit-item" data-coll="${c.id}" data-id="${r.id}"><h4 class="t trunc">${esc(itemTitle(r))}</h4><div class="meta trunc">${esc(subOf(c,r))}</div></button>${b?`<span class="pill ${b[1]}">${esc(b[0])}</span>`:''}${c.row?c.row(r):''}</div>`;
}
const stat=(k,v)=>`<div class="card metric"><div class="k">${k}</div><div class="v">${v}</div></div>`;
const stats=a=>`<div class="grid2" style="margin-bottom:12px">${a.map(x=>stat(x[0],x[1])).join('')}</div>`;

function collBody(c,withAdd=true){
  let l=itemsOf(c.id);const f=collF[c.id]||'all';
  if(c.chip&&f!=='all')l=l.filter(r=>r[c.chip]===f);
  const sk=c.sk;
  l.sort((a,b)=>{
    if(c.tog&&!!a[c.tog]!==!!b[c.tog])return a[c.tog]?1:-1;
    if(sk){const x=a[sk]||'',y=b[sk]||'';if(x!==y){if(!x)return 1;if(!y)return -1;return c.asc?String(x).localeCompare(String(y),undefined,{numeric:true}):String(y).localeCompare(String(x),undefined,{numeric:true})}}
    return b.created-a.created;
  });
  const chipF=c.chip?c.f.find(x=>x.k===c.chip):null;
  const chips=chipF?`<div class="chips" style="margin-bottom:10px">${['all',...optsOf(chipF)].map(o=>`<button class="chip ${f===o?'on':''}" data-act="cchip" data-c="${c.id}" data-f="${esc(o)}">${o==='all'?'All':esc(o)}</button>`).join('')}</div>`:'';
  const quick=c.quick?`<div class="row" style="margin-bottom:12px"><div class="grow"><input class="input" id="qa-in" placeholder="Quick add ${c.noun.toLowerCase()}" data-enter="qa" autocomplete="off"></div><button class="icon-btn p" data-act="qa" data-c="${c.id}" aria-label="Add">${ic('plus')}</button></div>`:'';
  const all_=itemsOf(c.id);
  return `${c.sum?c.sum(all_):''}${c.note?`<div class="alert" style="margin-bottom:12px">${c.note}</div>`:''}${chips}${quick}${l.length?`<div class="card"><div class="stack-sm">${l.map(r=>itemRow(c,r)).join('')}</div></div>`:`<div class="card">${emptyBox(c.icon,'Nothing here yet',c.empty||`Add your first ${c.noun.toLowerCase()}.`)}</div>`}${c.after?c.after(all_):''}${withAdd?stickyAdd('add-item" data-coll="'+c.id,'Add '+c.noun.toLowerCase()):''}`;
}

/* ---------- item editor ---------- */
const SMALL=['num','money','date','time','sel','ref'];
function fieldHtml(f,d){
  const v=d[f.k]==null?'':d[f.k];let h;
  switch(f.t){
   case 'area':h=`<textarea class="input" data-f="${f.k}" rows="3">${esc(v)}</textarea>`;break;
   case 'num':h=inp(f.k,v,'','number','step="any" inputmode="decimal"');break;
   case 'money':h=inp(f.k,v,'0.00','number','step="0.01" inputmode="decimal"');break;
   case 'date':case 'time':h=inp(f.k,v,'',f.t);break;
   case 'sel':h=sel(f.k,[['','None'],...optsOf(f).map(o=>[o,o])],v);break;
   case 'ref':h=sel(f.k,[['','None'],...itemsOf(f.o).map(r=>[r.id,itemTitle(r)])],v);break;
   case 'check':return `<div class="fld"><span>${f.l}</span><button type="button" class="chip ${d[f.k]?'on':''}" style="align-self:flex-start" data-act="ed-chk" data-f="${f.k}">${d[f.k]?'Yes':'No'}</button></div>`;
   default:h=inp(f.k,v,f.ph||'');
  }
  return `<label class="fld"><span>${f.l}${f.t==='money'?` (${cur()})`:''}${f.t==='num'&&typeof f.o==='string'?` (${f.o})`:''}</span>${h}</label>`;
}
function itemForm(c,d){
  let out='',buf=[];const flush=()=>{if(buf.length){out+=`<div class="grid2">${buf.join('')}</div>`;buf=[]}};
  for(const f of c.f){
    if(SMALL.includes(f.t)){buf.push(fieldHtml(f,d));if(buf.length===2)flush()}
    else{flush();out+=fieldHtml(f,d)}
  }
  flush();return out+(c.hint?`<p class="xs sub">${c.hint}</p>`:'');
}
EDITORS.item={
  get label(){const c=ED&&collOf(ED.ctx);return c?c.noun.toLowerCase():'item'},
  blank:()=>({}),
  body(d){return itemForm(collOf(ED.ctx),d)},
  save(d,id){
    const c=collOf(ED.ctx);
    if(!String(d[c.tk]||'').trim()){toast(`Add a ${c.f.find(x=>x.k===c.tk).l.toLowerCase()}`);return false}
    const v=Object.assign({},d);v[c.tk]=String(v[c.tk]).trim();
    if(c.before)c.before(v);
    if(id)upd(id,v);else add('item',Object.assign({coll:c.id},v));
    if(c.after_save)c.after_save(v);return true;
  }
};
function openItemEditor(cid,id,pre){
  const rec=id?DB.rec[id]:null;if(rec)cid=rec.coll;
  const c=collOf(cid);if(!c)return;
  const base=rec?clone(rec):Object.assign({},c.def||{},pre||{});
  if(!rec)c.f.forEach(f=>{if(f.n&&base[f.k]==null)base[f.k]=today()});
  ED={kind:'item',id:id||null,d:base,ctx:cid};drawEditor();
}

/* ---------- calendar + alerts from item dates ---------- */
function calVal(r,d){return d.fn?d.fn(r):r[d.k]}
function itemCalItems(ds){
  const out=[];
  for(const c of COLLS){
    if(!c.cal)continue;
    for(const r of itemsOf(c.id)){
      for(const d of c.cal){
        if(d.skip&&d.skip(r))continue;
        const v=calVal(r,d);if(!v)continue;
        const hit=d.yearly?(v.slice(5)===ds.slice(5)&&v.slice(0,4)<=ds.slice(0,4)):v===ds;
        if(hit)out.push({date:ds,time:(d.t&&r[d.t])||'',title:`${d.label}: ${itemTitle(r)}`,kind:'item',item:true,coll:c.id,id:r.id,sub:c.noun});
      }
    }
  }
  return out;
}
function nextOcc(v,yearly,td){
  if(!yearly)return v;
  let t=td.slice(0,4)+v.slice(4);if(t<td)t=(+td.slice(0,4)+1)+v.slice(4);return t;
}
function watchItems(cb){
  const td=today();
  for(const c of COLLS){
    for(const r of itemsOf(c.id)){
      for(const d of c.cal||[]){
        if(!d.alert||(d.skip&&d.skip(r)))continue;const v=calVal(r,d);if(!v)continue;
        const t=nextOcc(v,d.yearly,td),n=diffDays(td,t);
        if(d.alert.includes(n))cb(`i_${r.id}_${d.k||'x'}_${t}_${n}`,`${d.label}: ${itemTitle(r)}`,n===0?'Today':`In ${n} day${n>1?'s':''}`);
      }
      if(c.low&&r.qty!==''&&r.qty!=null&&r.low!==''&&r.low!=null&&+r.qty<=+r.low)cb(`low_${r.id}_${r.qty}`,`Running low: ${itemTitle(r)}`,`${r.qty} left`);
    }
  }
}
/* things worth a glance: expiring, due soon, running low. Used by Home and the assistant. */
function attention(limit=12){
  const td=today(),out=[];
  for(const c of COLLS){
    for(const r of itemsOf(c.id)){
      for(const d of c.cal||[]){
        if(!d.att||(d.skip&&d.skip(r)))continue;const v=calVal(r,d);if(!v)continue;
        const t=nextOcc(v,d.yearly,td),n=diffDays(td,t);
        if(n<=(d.within||14)&&n>=-30)out.push({n,coll:c.id,id:r.id,title:itemTitle(r),text:n<0?`${d.label} ${-n} day${n<-1?'s':''} ago`:n===0?`${d.label} today`:`${d.label} in ${n} day${n>1?'s':''}`});
      }
      if(c.low&&r.qty!==''&&r.qty!=null&&r.low!==''&&r.low!=null&&+r.qty<=+r.low)out.push({n:-1,coll:c.id,id:r.id,title:itemTitle(r),text:`Running low (${r.qty} left)`});
    }
  }
  return out.sort((a,b)=>a.n-b.n).slice(0,limit);
}
function expiryBadge(k){return r=>{if(!r[k])return null;const n=diffDays(today(),r[k]);return n<0?['Expired','warn']:n<=30?[`${n}d left`,'warn']:null}}

/* ---------- actions ---------- */
ACT['edit-item']=d=>{openItemEditor(d.coll,d.id);return false};
ACT['add-item']=d=>{openItemEditor(d.coll,null);return false};
ACT['ed-chk']=d=>{ED.d[d.f]=!ED.d[d.f];drawEditor();return false};
ACT['cchip']=d=>{collF[d.c]=d.f};
ACT['ci-tog']=d=>{const r=DB.rec[d.id],c=collOf(r.coll);upd(d.id,{[c.tog]:!r[c.tog]});if(c.togXp&&!r[c.tog])gain(c.togXp,1)};
ACT['ci-q']=d=>{const r=DB.rec[d.id];upd(d.id,{qty:Math.max(0,(+r.qty||0)+(+d.dir))})};
ACT['qa']=d=>{
  const c=collOf(d.c),el=$('#qa-in'),v=el.value.trim();if(!v)return false;
  add('item',Object.assign({coll:c.id},c.def||{},{[c.tk]:v}));el.value='';
  setTimeout(()=>{const e=$('#qa-in');e&&e.focus()},30);
};
const qtyBtns=r=>`<div class="row" style="gap:2px;flex:none"><button class="icon-btn sm" data-act="ci-q" data-id="${r.id}" data-dir="-1" aria-label="Less">${ic('minus')}</button><span class="b num" style="min-width:20px;text-align:center;font-size:13px">${r.qty===''||r.qty==null?0:r.qty}</span><button class="icon-btn sm" data-act="ci-q" data-id="${r.id}" data-dir="1" aria-label="More">${ic('plus')}</button></div>`;
const lowBadge=r=>(r.qty!==''&&r.qty!=null&&r.low!==''&&r.low!=null&&+r.qty<=+r.low)?['Low','warn']:null;
