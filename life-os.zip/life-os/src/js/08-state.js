/* ---------- STATE ---------- */
let view='home',tf='today',ef='any',selDay=today(),calM=(()=>{const d=new Date();return{y:d.getFullYear(),m:d.getMonth()}})(),chatLog=[],hideRestart=false,away=0,ED=null;
/* feature modules register page actions here: ACT.name=(dataset,el)=>{...}; return false to skip the re-render */
const ACT={};
let viewArg=null;
const TITLES={home:'Home',tasks:'Tasks',calendar:'Calendar',life:'My Life',more:'More',dump:'Brain Dump',routines:'Routines',trackers:'Trackers',focus:'Focus',dopamine:'Dopamine Menu',projects:'Projects',goals:'Goals',rewards:'Rewards',assistant:'Assistant',insights:'Insights',settings:'Settings'};
const MORE=[['dump','Brain Dump','Capture anything, decide later','lightbulb'],['routines','Routines','Routines and habits','repeat'],['trackers','Trackers','Water, mood, energy, sleep','activity'],['focus','Focus','Timer, parking lot, body doubling','play'],['dopamine','Dopamine Menu','Things you enjoy, suggested by time and energy','zap'],['projects','Projects','Milestones and tasks','folder'],['goals','Goals','Short and long term','target'],['rewards','Rewards','Companion, quests, badges and shop','trophy'],['assistant','Assistant','Plan your day, ask anything','sparkles'],['insights','Insights','Descriptive, never judgmental','bar-chart'],['settings','Settings','Theme, layout, reminders and your data','sliders']];
const TABS=[['home','Home','house'],['tasks','Tasks','list-checks'],['calendar','Calendar','calendar'],['life','My Life','layout-grid'],['more','More','more-horizontal']];

