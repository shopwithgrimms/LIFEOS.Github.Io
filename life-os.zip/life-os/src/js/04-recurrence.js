/* ---------- RECURRENCE ENGINE ---------- */
/* rule = {freq:'none'|'daily'|'weekly'|'monthly'|'yearly'|'after', every:n, days:[0-6], unit:'day'|'week'|'month'}
   A record with a rule is anchored on r.date and may carry r.until and r.skip[] */
function occursOn(r,ds){
  const s=r.date;if(!s||ds<s)return false;
  if(r.until&&ds>r.until)return false;
  if(r.skip&&r.skip.includes(ds))return false;
  const rule=r.rule;
  if(!rule||rule.freq==='none'||rule.freq==='after')return ds===s;
  const n=Math.max(1,+rule.every||1),d=diffDays(s,ds);
  switch(rule.freq){
    case 'daily':return d%n===0;
    case 'weekly':{const days=rule.days&&rule.days.length?rule.days:[dow(s)];return Math.floor((d+dow(s))/7)%n===0&&days.includes(dow(ds))}
    case 'monthly':{const a=parse(s),b=parse(ds),m=(b.getFullYear()-a.getFullYear())*12+b.getMonth()-a.getMonth();if(m%n)return false;const dim=new Date(b.getFullYear(),b.getMonth()+1,0).getDate();return b.getDate()===Math.min(a.getDate(),dim)}
    case 'yearly':{const a=parse(s),b=parse(ds),y=b.getFullYear()-a.getFullYear();if(y%n||a.getMonth()!==b.getMonth())return false;const dim=new Date(b.getFullYear(),b.getMonth()+1,0).getDate();return b.getDate()===Math.min(a.getDate(),dim)}
  }
  return false;
}
const isRepeating=r=>!!(r.rule&&r.rule.freq&&r.rule.freq!=='none');
/* next due date strictly after `after`; 'after' frequency counts from today (completion-triggered) */
function nextDue(t,after){
  const rule=t.rule;if(!isRepeating(t))return null;
  if(rule.freq==='after'){const n=Math.max(1,+rule.every||1),u=rule.unit||'day';return u==='month'?addMonths(today(),n):addDays(today(),u==='week'?7*n:n)}
  const probe={date:t.anchor||t.due,rule,skip:t.skip,until:t.until};
  for(let i=1;i<=1100;i++){const c=addDays(after,i);if(occursOn(probe,c))return c}
  return null;
}
function ruleText(r){
  if(!isRepeating(r))return 'Does not repeat';
  const x=r.rule,n=Math.max(1,+x.every||1);
  if(x.freq==='after')return `${n} ${x.unit||'day'}${n>1?'s':''} after I finish it`;
  const u={daily:'day',weekly:'week',monthly:'month',yearly:'year'}[x.freq];
  let s=n===1?`Every ${u}`:`Every ${n} ${u}s`;
  if(x.freq==='weekly'&&x.days&&x.days.length)s+=' on '+[...x.days].sort().map(d=>DOWL[d]).join(', ');
  return s;
}

