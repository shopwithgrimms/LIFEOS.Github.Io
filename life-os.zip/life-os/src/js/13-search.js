/* ---------- SEARCH / NOTIFICATIONS / BIN ---------- */
function openSearch(q=''){
  sheet('Search',`<input class="input" id="sq" placeholder="Search everything you have saved" autocomplete="off" value="${esc(q)}"><div id="sres" style="margin-top:12px"></div>`);
  const run=()=>{const q=$('#sq').value.trim().toLowerCase();
    const hit=r=>{if(r.deleted||!kindOf(r))return false;return Object.values(r).filter(v=>typeof v==='string').join(' ').toLowerCase().includes(q)};
    $('#sres').innerHTML=q?(Object.values(DB.rec).filter(hit).slice(0,30).map(r=>`<button class="tl" data-act="open-result" data-kind="${r.type}" data-id="${r.id}"><div class="grow"><h4 style="font-size:14px;font-weight:700" class="trunc">${esc(recTitle(r))}</h4>${r.due||r.date?`<div class="xs sub">${dayLabel(r.due||r.date)}</div>`:''}</div><span class="pill brand">${esc(kindOf(r))}</span></button>`).join('')||emptyBox('search','No matches','Try another word.')):`<p class="xs sub">Type to search everything you have saved.</p>`};
  $('#sq').addEventListener('input',run);run();setTimeout(()=>$('#sq')&&$('#sq').focus(),50);
}
function openBell(){
  const l=all('notif').sort((a,b)=>b.at-a.at).slice(0,30);l.forEach(n=>{if(!n.read)DB.rec[n.id].read=true});persist();
  const ago=ts=>{const m=Math.round((Date.now()-ts)/60000);return m<1?'just now':m<60?`${m} min ago`:m<1440?`${Math.round(m/60)} h ago`:`${Math.round(m/1440)} d ago`};
  sheet('Notifications',l.length?l.map(n=>`<div class="kv" style="align-items:flex-start"><div class="grow"><div class="b" style="font-size:13px">${esc(n.title)}</div><div class="xs sub">${esc(n.body||'')} · ${ago(n.at)}</div></div><button class="btn btn-soft btn-sm" data-act="snooze" data-id="${n.id}">Snooze 10m</button><button class="icon-btn sm" data-act="notif-x" data-id="${n.id}" aria-label="Dismiss">${ic('x')}</button></div>`).join(''):emptyBox('bell','All caught up','Reminders you set will show up here.'),l.length?`<button class="btn btn-line" data-act="notif-clear">Clear all</button>`:'');
  chrome();
}
function openBin(){
  const l=Object.values(DB.rec).filter(r=>r.deleted&&kindOf(r)).sort((a,b)=>b.deleted-a.deleted);
  sheet('Recycle bin',l.length?l.map(r=>`<div class="kv"><div class="grow"><div class="b trunc" style="font-size:13px">${esc(recTitle(r))}</div><div class="xs sub">${esc(kindOf(r))}</div></div><button class="btn btn-soft btn-sm" data-act="bin-restore" data-id="${r.id}">Restore</button><button class="icon-btn sm" data-act="bin-purge" data-id="${r.id}" aria-label="Delete forever">${ic('trash')}</button></div>`).join(''):emptyBox('archive','Empty','Deleted items wait here until you remove them.'),l.length?`<button class="btn btn-danger" data-act="bin-empty">Empty bin</button>`:'');
}
function confirmSheet(title,msg,label,fn){window._confirm=fn;sheet(title,`<p class="sub sm-t">${msg}</p>`,`<button class="btn btn-line" data-act="close">Cancel</button><button class="btn btn-primary" data-act="confirm-yes">${label}</button>`)}
ACT['open-result']=d=>{closeSheet();const r=DB.rec[d.id];if(!r)return false;
  if(r.type==='item'){openItemEditor(r.coll,r.id);return false}
  if(r.type==='goal'){go('goal',r.id);return false}
  if(r.type==='project'){go('project',r.id);return false}
  if(r.type==='dump'){go('dump');return false}
  openEditor(r.type,r.id);return false};
