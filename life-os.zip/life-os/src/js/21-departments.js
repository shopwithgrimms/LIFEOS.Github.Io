/* ---------- DEPARTMENTS (schemas) ---------- */
const EXP_CATS=['Groceries','Dining','Home','Transport','Health','Beauty','Fun','Bills','Shopping','Other'];
const STATUS3=['Want to','In progress','Finished'];
const dueBadge=k=>r=>{if(!r[k])return null;const n=diffDays(today(),r[k]);return n<0?['Overdue','warn']:n<=7?[n===0?'Today':`${n}d`,'brand']:null};
const calDue=(label,k='due',alert=[3,0],extra={})=>[Object.assign({k,label,att:true,alert},extra)];
const weekAgo=()=>addDays(today(),-6);

/* ---- Mind ---- */
C({id:'notes',dept:'mind',title:'Knowledge library',noun:'Note',icon:'book',tk:'name',empty:'Save ideas, facts and things worth keeping.',
  f:[['name','Title'],['tag','Tag'],['text','Note','area']],show:['tag'],chip:null});
C({id:'dopa',dept:'mind',title:'Dopamine menu',noun:'Activity',icon:'zap',tk:'name',quick:true,chip:'kind',def:{kind:'Quick',energy:'Low'},
  f:[['name','Activity'],['kind','Type','sel',['Quick','Relaxing','Active','Productive']],['mins','Minutes','num','min'],['energy','Energy needed','sel',['Low','Medium','High']]],show:['kind','mins','energy']});

/* ---- Memories ---- */
C({id:'journal',dept:'memories',title:'Journal',noun:'Entry',icon:'edit',tk:'name',sk:'date',chip:'mood',
  f:[['name','Title'],['date','Date','date',null,'n'],['mood','Mood','sel',['Low','Okay','Good','Great']],['text','Write','area']],show:['date','mood']});
C({id:'memory',dept:'memories',title:'Memories',noun:'Memory',icon:'camera',tk:'name',sk:'date',
  f:[['name','Title'],['date','When','date',null,'n'],['people','Who was there'],['text','What happened','area']],show:['date','people']});

/* ---- Learning ---- */
C({id:'course',dept:'learning',title:'Courses and books',noun:'Course',icon:'cap',tk:'name',chip:'status',def:{status:'In progress',progress:0},
  f:[['name','Name'],['platform','Where'],['status','Status','sel',['Want to','In progress','Finished']],['progress','Progress','num','%']],show:['platform','progress'],
  badge:r=>r.progress!==''&&r.progress!=null?[`${r.progress}%`,'brand']:null});
C({id:'skill',dept:'learning',title:'Skills',noun:'Skill',icon:'target',tk:'name',def:{level:'Beginner'},
  f:[['name','Skill'],['level','Level','sel',['Beginner','Improving','Comfortable','Strong']],['notes','Notes','area']],show:['level']});
const cardsDue=()=>itemsOf('card').filter(r=>!r.due||r.due<=today());
C({id:'card',dept:'learning',title:'Flashcards',noun:'Card',icon:'layers',tk:'name',empty:'Add a card, then study the ones that are due.',
  f:[['name','Front'],['back','Back','area'],['deck','Deck'],['due','Next review','date']],show:['deck','due'],
  sum:l=>{const n=cardsDue().length;return `<div class="card row between" style="margin-bottom:12px"><div><div class="b">${n} due to study</div><div class="xs sub">${l.length} cards in total</div></div><button class="btn btn-primary btn-sm" data-act="study" ${n?'':'disabled'}>${ic('play')}Study</button></div>`}});

/* ---- Body ---- */
C({id:'med',dept:'health',title:'Medications and supplements',noun:'Medication',icon:'pill',tk:'name',low:true,def:{qty:'',low:5},
  f:[['name','Name'],['dose','Dose'],['when','When'],['qty','Amount left','num'],['low','Warn me at','num'],['refill','Refill date','date']],show:['dose','when','refill'],
  hint:'Informational only. This is not medical advice.',badge:lowBadge,row:r=>r.qty!==''&&r.qty!=null?qtyBtns(r):'',
  cal:[{k:'refill',label:'Refill',att:true,alert:[3,0]}]});
C({id:'hlog',dept:'health',title:'Health log',noun:'Entry',icon:'activity',tk:'name',sk:'date',
  f:[['name','What happened'],['date','Date','date',null,'n'],['sev','How strong','sel',['Mild','Moderate','Strong']],['notes','Notes','area']],show:['date','sev']});
C({id:'appt',dept:'health',title:'Appointments',noun:'Appointment',icon:'calendar',tk:'name',sk:'date',asc:true,
  f:[['name','Appointment'],['date','Date','date'],['time','Time','time'],['who','Provider'],['notes','Notes','area']],show:['date','time','who'],
  cal:[{k:'date',label:'Appointment',t:'time',alert:[1,0]}],badge:dueBadge('date')});
C({id:'hrec',dept:'health',title:'Records',noun:'Record',icon:'file',tk:'name',sk:'date',
  f:[['name','Title'],['kind','Type','sel',['Lab result','Vaccine','Prescription','Visit summary','Other']],['date','Date','date',null,'n'],['notes','Notes','area']],show:['kind','date'],
  hint:'Keep summaries here. Do not store ID or insurance numbers in notes.'});
C({id:'vital',dept:'health',title:'Measurements',noun:'Measurement',icon:'activity',tk:'name',sk:'date',def:{name:'Weight'},
  f:[['name','Measure'],['value','Value','num'],['unit','Unit'],['date','Date','date',null,'n']],show:['value','unit','date']});

C({id:'food',dept:'nutrition',title:'Food diary',noun:'Food',icon:'utensils',tk:'name',sk:'date',chip:'meal',def:{meal:'Lunch'},
  f:[['name','Food'],['meal','Meal','sel',['Breakfast','Lunch','Dinner','Snack']],['cal','Calories','num','kcal'],['date','Date','date',null,'n']],show:['meal','cal','date'],
  sum:l=>{const t=l.filter(r=>r.date===today()),k=sumBy(t,'cal'),g=+DB.set.calGoal||0;return stats([['Today',`${k} kcal`],['Daily goal',g?`${g} kcal`:'Not set']])}});
C({id:'recipe',dept:'nutrition',title:'Recipes',noun:'Recipe',icon:'book',tk:'name',
  f:[['name','Recipe'],['mins','Time','num','min'],['ing','Ingredients (one per line)','area'],['steps','Steps','area']],show:['mins']});
C({id:'pantry',dept:'nutrition',title:'Pantry',noun:'Ingredient',icon:'inbox',tk:'name',quick:true,low:true,def:{qty:1,low:1},
  f:[['name','Item'],['qty','Amount','num'],['low','Warn me at','num'],['expires','Expires','date']],show:['expires'],badge:r=>lowBadge(r)||expiryBadge('expires')(r),row:qtyBtns,
  cal:[{k:'expires',label:'Expires',att:true,alert:[2,0]}]});
C({id:'meal',dept:'nutrition',title:'Meal plan',noun:'Meal',icon:'calendar',tk:'name',sk:'date',asc:true,
  f:[['name','Meal'],['date','Date','date',null,'n'],['slot','Slot','sel',['Breakfast','Lunch','Dinner','Snack']],['recipe','Recipe','ref','recipe']],show:['date','slot','recipe'],
  cal:[{k:'date',label:'Meal',alert:null}]});

C({id:'workout',dept:'fitness',title:'Workouts',noun:'Workout',icon:'dumbbell',tk:'name',sk:'date',chip:'kind',def:{kind:'Strength'},
  f:[['name','Workout'],['kind','Type','sel',['Strength','Cardio','Walk','Yoga','Sport','Stretch']],['mins','Minutes','num','min'],['date','Date','date',null,'n'],['notes','Notes','area']],show:['kind','mins','date'],
  sum:l=>{const w=l.filter(r=>r.date>=weekAgo());return stats([['Last 7 days',`${w.length} sessions`],['Minutes',`${sumBy(w,'mins')}`]])}});
C({id:'pr',dept:'fitness',title:'Personal records',noun:'Record',icon:'award',tk:'name',sk:'date',
  f:[['name','Exercise'],['value','Best','num'],['unit','Unit'],['date','Date','date',null,'n']],show:['value','unit','date']});

const sleepHrs=r=>{if(!r.bed||!r.wake)return null;let m=mins(r.wake)-mins(r.bed);if(m<=0)m+=1440;return m/60};
C({id:'sleep',dept:'sleep',title:'Sleep log',noun:'Night',icon:'moon',tk:'date',sk:'date',def:{quality:'Okay'},
  f:[['date','Night of','date',null,'n'],['bed','Bedtime','time'],['wake','Woke up','time'],['quality','How it felt','sel',['Poor','Okay','Good','Great']],['notes','Notes','area']],
  sub:r=>[sleepHrs(r)&&`${sleepHrs(r).toFixed(1)} h`,r.quality].filter(Boolean).join(' · '),
  sum:l=>{const h=l.filter(r=>r.date>=weekAgo()).map(sleepHrs).filter(Boolean);return stats([['7-day average',h.length?`${(h.reduce((a,b)=>a+b,0)/h.length).toFixed(1)} h`:'No data'],['Nights logged',`${l.length}`]])}});

/* ---- Self-care ---- */
const ACTIVES=['None','Retinol','AHA/BHA','Vitamin C','Benzoyl peroxide','Niacinamide','SPF'];
const CLASH=[['Retinol','AHA/BHA','Use on different evenings to limit irritation.'],['Retinol','Benzoyl peroxide','These can be drying together. Consider alternating.'],['AHA/BHA','Benzoyl peroxide','Layering both can irritate. Alternate days.'],['Vitamin C','AHA/BHA','Both are strong. Many people use vitamin C in the morning and acids at night.']];
C({id:'bprod',dept:'beauty',title:'Products',noun:'Product',icon:'palette',tk:'name',chip:'cat',low:true,def:{cat:'Skincare',active:'None',qty:'',low:''},
  f:[['name','Product'],['brand','Brand'],['cat','Category','sel',['Skincare','Haircare','Body','Makeup','Nails','Oral']],['active','Key active','sel',ACTIVES],['opened','Opened on','date'],['expires','Expires on','date'],['qty','Amount left','num'],['low','Warn me at','num'],['price','Price','money']],show:['brand','cat','active'],
  badge:r=>lowBadge(r)||expiryBadge('expires')(r),
  cal:[{k:'expires',label:'Product expires',att:true,alert:[7,0],within:30}],
  after:l=>{const have=new Set(l.map(r=>r.active).filter(a=>a&&a!=='None')),hits=CLASH.filter(c=>have.has(c[0])&&have.has(c[1]));
    return hits.length?`<div class="eyebrow sec-h">Worth knowing</div><div class="stack-sm">${hits.map(h=>`<div class="alert"><b>${h[0]} and ${h[1]}.</b> ${h[2]}</div>`).join('')}</div><p class="xs sub" style="margin-top:8px">General guidance only. Patch test new products and ask a professional if unsure.</p>`:''}});
C({id:'skinj',dept:'beauty',title:'Skin and hair journal',noun:'Entry',icon:'edit',tk:'name',sk:'date',chip:'skin',
  f:[['name','Summary'],['date','Date','date',null,'n'],['skin','How it looks','sel',['Clear','Dry','Oily','Irritated','Breakout','Glowing']],['notes','Notes','area']],show:['date','skin']});
C({id:'btreat',dept:'beauty',title:'Appointments and treatments',noun:'Appointment',icon:'scissors',tk:'name',sk:'date',asc:true,
  f:[['name','Appointment'],['date','Date','date'],['time','Time','time'],['place','Where'],['cost','Cost','money'],['next','Rebook around','date']],show:['date','time','place'],badge:dueBadge('date'),
  cal:[{k:'date',label:'Appointment',t:'time',alert:[1,0]},{k:'next',label:'Time to rebook',alert:[0]}]});

/* ---- Home ---- */
C({id:'csupply',dept:'cleaning',title:'Cleaning supplies',noun:'Supply',icon:'inbox',tk:'name',quick:true,low:true,def:{qty:1,low:1},
  f:[['name','Supply'],['qty','Amount','num'],['low','Warn me at','num'],['store','Where to buy']],show:['store'],badge:lowBadge,row:qtyBtns});
C({id:'supply',dept:'home',title:'Household supplies',noun:'Supply',icon:'inbox',tk:'name',quick:true,low:true,def:{qty:1,low:1},
  f:[['name','Item'],['qty','Amount','num'],['low','Warn me at','num'],['store','Where to buy']],show:['store'],badge:lowBadge,row:qtyBtns});
C({id:'appl',dept:'home',title:'Appliances and warranties',noun:'Appliance',icon:'home2',tk:'name',
  f:[['name','Appliance'],['brand','Brand'],['bought','Bought on','date'],['warranty','Warranty ends','date'],['service','Next service','date'],['notes','Notes','area']],show:['brand','warranty'],
  badge:expiryBadge('warranty'),cal:[{k:'warranty',label:'Warranty ends',att:true,alert:[30,0],within:30},{k:'service',label:'Service due',att:true,alert:[7,0]}]});
C({id:'hmaint',dept:'home',title:'Home maintenance',noun:'Job',icon:'wrench',tk:'name',sk:'due',asc:true,
  f:[['name','Job'],['area','Where'],['due','Due','date'],['every','Repeats every','num','months'],['last','Last done','date']],show:['area','due'],badge:dueBadge('due'),
  cal:calDue('Home job','due',[3,0]),
  row:r=>`<button class="btn btn-soft btn-sm" data-act="ci-maint" data-id="${r.id}">Done</button>`});
const plantNext=r=>r.last&&r.every?addDays(r.last,+r.every):'';
C({id:'plant',dept:'garden',title:'Plants',noun:'Plant',icon:'flower',tk:'name',def:{every:7,last:''},
  f:[['name','Plant'],['place','Where'],['every','Water every','num','days'],['last','Last watered','date'],['notes','Care notes','area']],
  sub:r=>{const n=plantNext(r);return [r.place,n?`water ${dayLabel(n).toLowerCase()}`:'no schedule'].filter(Boolean).join(' · ')},
  badge:r=>{const n=plantNext(r);if(!n)return null;const d=diffDays(today(),n);return d<=0?['Water','brand']:null},
  row:r=>`<button class="btn btn-soft btn-sm" data-act="ci-water" data-id="${r.id}">Watered</button>`,
  cal:[{fn:plantNext,k:'water',label:'Water',att:true,alert:[0],within:1}]});

/* ---- Money ---- */
C({id:'expense',dept:'finance',title:'Expenses',noun:'Expense',icon:'wallet',tk:'name',sk:'date',chip:'cat',def:{cat:'Other'},
  f:[['name','What'],['amount','Amount','money'],['cat','Category','sel',EXP_CATS],['date','Date','date',null,'n'],['note','Note']],show:['amount','cat','date'],
  sum:l=>{const m=l.filter(r=>inMonth(r)),by={};m.forEach(r=>by[r.cat||'Other']=(by[r.cat||'Other']||0)+(+r.amount||0));const top=Object.entries(by).sort((a,b)=>b[1]-a[1])[0];
    return stats([['This month',money(sumBy(m,'amount'))],['Top category',top?`${top[0]}`:'None yet']])}});
C({id:'income',dept:'finance',title:'Income',noun:'Income',icon:'arrow-down',tk:'name',sk:'date',
  f:[['name','Source'],['amount','Amount','money'],['date','Date','date',null,'n']],show:['amount','date'],
  sum:l=>stats([['This month',money(sumBy(l.filter(r=>inMonth(r)),'amount'))],['Entries',`${l.length}`]])});
C({id:'bill',dept:'finance',title:'Bills',noun:'Bill',icon:'file',tk:'name',sk:'due',asc:true,def:{freq:'Monthly'},
  f:[['name','Bill'],['amount','Amount','money'],['due','Next due','date'],['freq','Repeats','sel',['Monthly','Weekly','Yearly','One time']]],show:['amount','due','freq'],badge:dueBadge('due'),
  cal:[{k:'due',label:'Bill due',att:true,alert:[3,0],within:7}],
  row:r=>`<button class="btn btn-soft btn-sm" data-act="ci-paid" data-id="${r.id}">Paid</button>`,
  sum:l=>stats([['Due in 7 days',money(sumBy(l.filter(r=>r.due&&diffDays(today(),r.due)<=7),'amount'))],['Monthly total',money(sumBy(l.filter(r=>r.freq==='Monthly'),'amount'))]])});
C({id:'sub',dept:'finance',title:'Subscriptions',noun:'Subscription',icon:'repeat',tk:'name',def:{cycle:'Monthly'},
  f:[['name','Service'],['cost','Cost','money'],['cycle','Billed','sel',['Monthly','Yearly']],['renews','Renews on','date']],show:['cost','cycle','renews'],
  cal:[{k:'renews',label:'Renews',att:true,alert:[3],within:7,yearly:false}],
  sum:l=>{const m=l.reduce((a,r)=>a+(r.cycle==='Yearly'?(+r.cost||0)/12:(+r.cost||0)),0);return stats([['Per month',money(m)],['Per year',money(m*12)]])}});
C({id:'saving',dept:'finance',title:'Savings goals',noun:'Savings goal',icon:'target',tk:'name',def:{saved:0},
  f:[['name','Goal'],['target','Target','money'],['saved','Saved so far','money'],['by','Aiming for','date']],show:['saved','target'],
  badge:r=>r.target?[`${Math.min(100,pct(+r.saved||0,+r.target))}%`,'brand']:null});
C({id:'debt',dept:'finance',title:'Debts',noun:'Debt',icon:'minus',tk:'name',
  f:[['name','Debt'],['balance','Balance','money'],['pay','Monthly payment','money'],['rate','Interest rate','num','%'],['due','Next payment','date']],show:['balance','pay','due'],
  cal:[{k:'due',label:'Payment due',att:true,alert:[3,0],within:7}],
  sum:l=>stats([['Total owed',money(sumBy(l,'balance'))],['Monthly payments',money(sumBy(l,'pay'))]])});
C({id:'budget',dept:'finance',title:'Budgets',noun:'Budget',icon:'bar-chart',tk:'name',
  f:[['name','Category','sel',EXP_CATS],['limit','Monthly limit','money']],
  sub:r=>{const s=sumBy(itemsOf('expense').filter(e=>inMonth(e)&&(e.cat||'Other')===r.name),'amount');return `${money(s)} of ${money(r.limit)} this month`},
  badge:r=>{const s=sumBy(itemsOf('expense').filter(e=>inMonth(e)&&(e.cat||'Other')===r.name),'amount');return r.limit?[`${pct(s,+r.limit)}%`,s>+r.limit?'warn':'brand']:null}});

C({id:'shop',dept:'shopping',title:'Shopping list',noun:'Item',icon:'cart',tk:'name',quick:true,tog:'bought',togXp:0,
  f:[['name','Item'],['qty','Quantity','num'],['store','Store'],['bought','Got it','check']],show:['qty','store'],
  after:l=>l.some(r=>r.bought)?`<div style="margin-top:12px"><button class="btn btn-line btn-sm block" data-act="shop-clear">Clear bought items</button></div>`:''});
C({id:'wish',dept:'shopping',title:'Wishlist',noun:'Wish',icon:'heart',tk:'name',quick:true,tog:'bought',def:{pri:'Someday'},
  f:[['name','Item'],['price','Price','money'],['pri','How much I want it','sel',['Someday','Soon','Really want']],['link','Link'],['bought','Got it','check']],show:['price','pri'],
  sum:l=>stats([['Wishlist total',money(sumBy(l.filter(r=>!r.bought),'price'))],['Items',`${l.filter(r=>!r.bought).length}`]])});

/* ---- Work ---- */
C({id:'timelog',dept:'work',title:'Time log',noun:'Entry',icon:'clock',tk:'name',sk:'date',
  f:[['name','What you worked on'],['project','Project or client'],['mins','Minutes','num','min'],['date','Date','date',null,'n']],show:['project','mins','date'],
  sum:l=>{const w=l.filter(r=>r.date>=weekAgo());return stats([['Last 7 days',`${(sumBy(w,'mins')/60).toFixed(1)} h`],['Entries',`${w.length}`]])}});
const profit=r=>r.status==='Sold'||r.status==='Shipped'?(+r.sold||0)-(+r.cost||0)-(+r.fees||0):null;
C({id:'resale',dept:'work',title:'Resale inventory and orders',noun:'Listing',icon:'tag',tk:'name',chip:'status',def:{status:'Sourced',platform:'Other'},
  f:[['name','Item'],['status','Status','sel',['Sourced','Listed','Sold','Shipped']],['platform','Platform','sel',['Vinted','Depop','eBay','Poshmark','Etsy','Facebook','Other']],['cost','Cost','money'],['price','Listed at','money'],['sold','Sold for','money'],['fees','Fees and postage','money'],['date','Sold on','date']],show:['status','platform','price'],
  badge:r=>{const p=profit(r);return p==null?null:[`${p>=0?'+':''}${money(p)}`,p>=0?'ok':'warn']},
  sum:l=>{const s=l.filter(r=>profit(r)!=null),rev=sumBy(s,'sold'),pr=s.reduce((a,r)=>a+profit(r),0),stock=l.filter(r=>r.status==='Sourced'||r.status==='Listed');
    return stats([['Profit',money(pr)],['Revenue',money(rev)],['In stock',`${stock.length}`],['Stock cost',money(sumBy(stock,'cost'))]])}});

/* ---- Play ---- */
C({id:'hobby',dept:'hobbies',title:'Hobby projects',noun:'Project',icon:'palette',tk:'name',chip:'status',def:{status:'Active'},
  f:[['name','Project'],['kind','Hobby'],['status','Status','sel',['Idea','Active','Paused','Finished']],['notes','Notes','area']],show:['kind','status']});
C({id:'hobbylog',dept:'hobbies',title:'Practice log',noun:'Session',icon:'clock',tk:'name',sk:'date',
  f:[['name','What you did'],['mins','Minutes','num','min'],['date','Date','date',null,'n'],['notes','Notes','area']],show:['mins','date'],
  sum:l=>stats([['Last 7 days',`${sumBy(l.filter(r=>r.date>=weekAgo()),'mins')} min`],['Sessions',`${l.length}`]])});
C({id:'media',dept:'entertainment',title:'Watch, read, play, listen',noun:'Title',icon:'film',tk:'name',chip:'mtype',def:{mtype:'Movie',status:'Want to'},
  f:[['name','Title'],['mtype','Type','sel',['Movie','TV','Book','Game','Music','Podcast']],['status','Status','sel',STATUS3],['rating','Rating','sel',['1','2','3','4','5']],['notes','Notes','area']],show:['mtype','status','rating'],
  badge:r=>r.status==='In progress'?['Now','brand']:null});
C({id:'trip',dept:'travel',title:'Trips',noun:'Trip',icon:'plane',tk:'name',sk:'start',asc:true,
  f:[['name','Destination'],['start','From','date'],['end','To','date'],['budget','Budget','money'],['notes','Plans and notes','area']],show:['start','end','budget'],
  cal:[{k:'start',label:'Trip starts',alert:[7,1]}],badge:dueBadge('start')});
C({id:'bucket',dept:'travel',title:'Bucket list',noun:'Dream',icon:'star',tk:'name',quick:true,tog:'done',togXp:20,
  f:[['name','Dream'],['cat','Type','sel',['Travel','Experience','Learn','Create','Other']],['done','Done','check']],show:['cat']});

/* ---- People and things ---- */
C({id:'person',dept:'social',title:'People',noun:'Person',icon:'users',tk:'name',
  f:[['name','Name'],['bday','Birthday','date'],['last','Last caught up','date'],['notes','Notes','area']],show:['bday','last'],
  cal:[{k:'bday',label:'Birthday',yearly:true,att:true,alert:[7,0]}]});
C({id:'gift',dept:'social',title:'Gift ideas',noun:'Gift',icon:'heart',tk:'name',chip:'status',def:{status:'Idea'},
  f:[['name','Idea'],['who','For','ref','person'],['price','Price','money'],['status','Status','sel',['Idea','Bought','Given']]],show:['who','price','status']});
C({id:'pet',dept:'pets',title:'Pets',noun:'Pet',icon:'paw',tk:'name',
  f:[['name','Name'],['species','Species'],['bday','Birthday','date'],['notes','Notes','area']],show:['species','bday'],
  cal:[{k:'bday',label:'Birthday',yearly:true,alert:[0]}]});
C({id:'petcare',dept:'pets',title:'Care and vet',noun:'Care item',icon:'heart',tk:'name',sk:'due',asc:true,chip:'kind',def:{kind:'Vet'},
  f:[['name','What'],['pet','Pet','ref','pet'],['kind','Type','sel',['Vet','Vaccine','Medication','Grooming','Food','Other']],['due','Due','date'],['cost','Cost','money']],show:['pet','kind','due'],badge:dueBadge('due'),
  cal:calDue('Pet care')});
C({id:'vehicle',dept:'vehicle',title:'Vehicles',noun:'Vehicle',icon:'car',tk:'name',
  f:[['name','Vehicle'],['plate','Registration'],['miles','Mileage','num'],['notes','Notes','area']],show:['plate','miles']});
C({id:'vmaint',dept:'vehicle',title:'Maintenance and renewals',noun:'Job',icon:'wrench',tk:'name',sk:'due',asc:true,
  f:[['name','What'],['veh','Vehicle','ref','vehicle'],['due','Due','date'],['last','Last done','date'],['cost','Cost','money'],['miles','Mileage','num']],show:['veh','due','cost'],badge:dueBadge('due'),
  cal:calDue('Vehicle',  'due',[7,0],{within:30})});
C({id:'wear',dept:'wardrobe',title:'Wardrobe',noun:'Piece',icon:'shirt',tk:'name',chip:'cat',def:{cat:'Tops',worn:0},
  f:[['name','Piece'],['cat','Type','sel',['Tops','Bottoms','Dresses','Outerwear','Shoes','Accessories']],['color','Colour'],['season','Season','sel',['All year','Spring and summer','Autumn and winter']],['worn','Times worn','num'],['lastw','Last worn','date']],show:['color','worn'],
  row:r=>`<button class="btn btn-soft btn-sm" data-act="ci-wore" data-id="${r.id}">Wore it</button>`});

/* ---- Admin ---- */
C({id:'doc',dept:'admin',title:'Documents',noun:'Document',icon:'file',tk:'name',sk:'expires',asc:true,chip:'kind',def:{kind:'Other'},
  f:[['name','Document'],['kind','Type','sel',['ID','Insurance','Tax','Medical','Home','Other']],['expires','Renews or expires','date'],['where','Where it is kept']],show:['kind','expires','where'],badge:expiryBadge('expires'),
  hint:'Note where a document is kept. Do not type ID numbers or passwords here.',
  cal:[{k:'expires',label:'Document expires',att:true,alert:[60,30,7,0],within:60}]});
C({id:'warranty',dept:'admin',title:'Warranties and receipts',noun:'Warranty',icon:'shield',tk:'name',sk:'ends',asc:true,
  f:[['name','Product'],['store','Bought from'],['ends','Warranty ends','date'],['notes','Notes','area']],show:['store','ends'],badge:expiryBadge('ends'),
  cal:[{k:'ends',label:'Warranty ends',att:true,alert:[30,0],within:30}]});
C({id:'contact',dept:'admin',title:'Useful contacts',noun:'Contact',icon:'users',tk:'name',
  f:[['name','Name'],['role','Role'],['phone','Phone'],['email','Email']],show:['role','phone']});
C({id:'renewal',dept:'admin',title:'Renewals and deadlines',noun:'Renewal',icon:'repeat',tk:'name',sk:'date',asc:true,
  f:[['name','What'],['date','Date','date'],['cost','Cost','money'],['notes','Notes','area']],show:['date','cost'],badge:dueBadge('date'),
  cal:[{k:'date',label:'Deadline',att:true,alert:[14,7,0],within:14}]});
C({id:'dig',dept:'digital',title:'Digital life',noun:'Service',icon:'globe',tk:'name',sk:'renews',asc:true,def:{kind:'Account'},
  f:[['name','Service'],['kind','Type','sel',['Account','Domain','Cloud storage','Backup','Subscription','Other']],['renews','Renews on','date'],['notes','Notes','area']],show:['kind','renews'],
  hint:'Never store passwords here. Use a dedicated password manager.',cal:[{k:'renews',label:'Renews',alert:[7,0]}]});

/* ---- Departments ---- */
const AREAS=['Mind','Body','Self-care','Home','Money','Work','Play','People and things','Admin'];
D({id:'mind',name:'Knowledge and ideas',area:'Mind',icon:'lightbulb',desc:'Notes, ideas and your dopamine menu.',colls:['notes','dopa'],links:[['dump','Brain Dump'],['focus','Focus']]});
D({id:'memories',name:'Memories and journal',area:'Mind',icon:'edit',desc:'Journal entries and moments worth keeping.',colls:['journal','memory']});
D({id:'learning',name:'Learning',area:'Mind',icon:'cap',desc:'Courses, skills and flashcards.',cat:'Learning',colls:['course','skill','card']});
D({id:'health',name:'Health',area:'Body',icon:'heart',desc:'Medications, appointments and records.',cat:'Health',colls:['med','appt','hlog','vital','hrec']});
D({id:'nutrition',name:'Food and nutrition',area:'Body',icon:'utensils',desc:'Food diary, recipes, pantry and meal plan.',colls:['food','recipe','pantry','meal']});
D({id:'fitness',name:'Fitness',area:'Body',icon:'dumbbell',desc:'Workouts and personal records.',cat:'Fitness',colls:['workout','pr']});
D({id:'sleep',name:'Sleep',area:'Body',icon:'moon',desc:'Sleep log and patterns.',colls:['sleep']});
D({id:'beauty',name:'Skincare and beauty',area:'Self-care',icon:'palette',desc:'Products, expiry dates, a journal and appointments.',cat:'Beauty',colls:['bprod','skinj','btreat']});
D({id:'cleaning',name:'Cleaning and laundry',area:'Home',icon:'house',desc:'Chores and supplies.',cat:'Household',colls:['csupply']});
D({id:'home',name:'Home',area:'Home',icon:'home2',desc:'Supplies, appliances, warranties and maintenance.',colls:['supply','appl','hmaint']});
D({id:'garden',name:'Plants and garden',area:'Home',icon:'flower',desc:'Watering schedule and care notes.',cat:'Plants',colls:['plant']});
D({id:'finance',name:'Finance',area:'Money',icon:'wallet',desc:'Expenses, income, bills, subscriptions, savings and budgets.',cat:'Financial',colls:['expense','income','bill','sub','budget','saving','debt']});
D({id:'shopping',name:'Shopping and wishlists',area:'Money',icon:'cart',desc:'What to buy and what you want.',cat:'Shopping',colls:['shop','wish']});
D({id:'work',name:'Work and business',area:'Work',icon:'briefcase',desc:'Time log and an optional resale workspace.',cat:'Work',colls:['timelog','resale']});
D({id:'hobbies',name:'Hobbies',area:'Play',icon:'palette',desc:'Projects and practice.',cat:'Hobbies',colls:['hobby','hobbylog']});
D({id:'entertainment',name:'Entertainment',area:'Play',icon:'film',desc:'Movies, shows, books, games and music.',colls:['media']});
D({id:'travel',name:'Travel and bucket list',area:'Play',icon:'plane',desc:'Trips and things you want to do.',cat:'Travel',colls:['trip','bucket']});
D({id:'social',name:'People and gifts',area:'People and things',icon:'users',desc:'Birthdays, catching up and gift ideas.',cat:'Social',colls:['person','gift']});
D({id:'pets',name:'Pets',area:'People and things',icon:'paw',desc:'Vet visits, medication and care.',cat:'Pets',colls:['pet','petcare']});
D({id:'vehicle',name:'Vehicle',area:'People and things',icon:'car',desc:'Maintenance and renewals.',cat:'Vehicle',colls:['vehicle','vmaint']});
D({id:'wardrobe',name:'Wardrobe',area:'People and things',icon:'shirt',desc:'What you own and wear.',colls:['wear']});
D({id:'admin',name:'Life admin',area:'Admin',icon:'file',desc:'Documents, warranties, contacts and deadlines.',cat:'Admin',colls:['doc','warranty','renewal','contact']});
D({id:'digital',name:'Digital life',area:'Admin',icon:'globe',desc:'Accounts, domains and backups.',cat:'Digital',colls:['dig']});
COLLS.forEach(c=>{const d=DEPTS.find(x=>x.colls.includes(c.id));if(d)c.deptRef=d.id});

/* ---- row actions ---- */
const addMonthsS=(s,n)=>addMonths(s,n);
ACT['ci-water']=d=>{upd(d.id,{last:today()});gain(2,1);toast('Watered')};
ACT['ci-wore']=d=>{const r=DB.rec[d.id];upd(d.id,{worn:(+r.worn||0)+1,lastw:today()})};
ACT['ci-paid']=d=>{
  const r=DB.rec[d.id],snap=JSON.stringify(r);
  const e=add('item',{coll:'expense',name:r.name,amount:r.amount,cat:'Bills',date:today(),note:'Bill paid'});
  const nx=r.freq==='Weekly'?addDays(r.due||today(),7):r.freq==='Yearly'?addMonths(r.due||today(),12):r.freq==='One time'?'':addMonths(r.due||today(),1);
  upd(d.id,{due:nx});gain(5,2);
  toast(nx?`Paid. Next due ${dayLabel(nx)}`:'Paid',()=>{DB.rec[d.id]=JSON.parse(snap);purge(e.id);render(true)});
};
ACT['ci-maint']=d=>{const r=DB.rec[d.id],n=+r.every?addMonths(today(),+r.every):'';upd(d.id,{last:today(),due:n});gain(5,2);toast(n?`Done. Next ${dayLabel(n)}`:'Done')};
ACT['shop-clear']=()=>{const l=itemsOf('shop').filter(r=>r.bought);l.forEach(r=>del(r.id));toast(`Cleared ${l.length}`,()=>{l.forEach(r=>restore(r.id));render(true)})};
ACT['study']=()=>{studyNext(true);return false};
let studyQ=[],studyShow=false;
function studyNext(init){
  if(init){studyQ=cardsDue().map(r=>r.id);studyShow=false}
  const id=studyQ[0];
  if(!id){closeSheet();toast('All caught up');gain(10,5);render(true);return}
  const r=DB.rec[id];
  sheet(`Study (${studyQ.length} left)`,`<div class="card" style="text-align:center;padding:28px 16px"><div class="b" style="font-size:18px">${esc(r.name)}</div>${studyShow?`<hr style="border:0;border-top:1px solid var(--line);margin:16px 0"><div style="white-space:pre-wrap">${esc(r.back||'')}</div>`:''}</div>`,
   studyShow?`<button class="btn btn-line" data-act="study-rate" data-r="1">Again</button><button class="btn btn-soft" data-act="study-rate" data-r="2">Good</button><button class="btn btn-primary" data-act="study-rate" data-r="3">Easy</button>`:`<button class="btn btn-primary block" data-act="study-show">Show answer</button>`);
}
ACT['study-show']=()=>{studyShow=true;studyNext();return false};
ACT['study-rate']=d=>{
  const id=studyQ.shift(),r=DB.rec[id],x=+d.r,iv=+r.iv||1,n=x===1?1:x===2?Math.max(2,iv*2):Math.max(4,iv*3);
  upd(id,{iv:n,due:addDays(today(),n)});studyShow=false;studyNext();return false;
};
