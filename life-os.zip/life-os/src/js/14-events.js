/* ---------- EVENTS ---------- */
/* feature modules register page actions here: ACT.name=(dataset,el)=>{...}; return false to skip the re-render */
document.addEventListener('input',e=>{
  const t=e.target;
  if(t.dataset&&t.dataset.set){setS(t.dataset.set,t.dataset.num!==undefined?(+t.value||0):t.value);return}
  const f=t.dataset&&t.dataset.f;if(!f||!ED)return;
  setPath(ED.d,f,t.type==='number'?(t.value===''?'':+t.value):t.value);
  if(t.dataset.out){const o=document.getElementById(t.dataset.out);if(o)o.textContent=t.value+(t.dataset.unit||'')}
  if(t.dataset.re!==undefined)drawEditor();
});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&$('#modal').classList.contains('on'))return closeSheet();
  if(e.key==='Enter'&&e.target.dataset&&e.target.dataset.enter){e.preventDefault();const b=document.querySelector(`[data-act="${e.target.dataset.enter}"]`);if(b)b.click()}
});
document.addEventListener('click',e=>{
  if(e.target.id==='modal')return closeSheet();
  const g=e.target.closest('[data-go]');if(g){if($('#modal').classList.contains('on'))closeSheet();return go(g.dataset.go,g.dataset.arg)}
  const a=e.target.closest('[data-act]');if(!a)return;const d=a.dataset,act=d.act;
  if(ACT[act]){if(ACT[act](d,a)!==false)render(true);return}
  /* modal and editor actions return early */
  switch(act){
   case 'close':return closeSheet();
   case 'undo':{const f=undoFn;undoFn=null;$('#toast').classList.remove('on');if(f)f();return}
   case 'new':return openEditor(d.kind,null);
   case 'edit':case 'open-result':{if(act==='open-result'&&d.kind==='dump'){closeSheet();return go('dump')}if(act==='open-result')closeSheet();if(d.kind==='item')return openItemEditor(d.coll,d.id);return openEditor(d.kind,d.id,d.ctx||selDay)}
   case 'go-routines':return go('routines');
   case 'ed-wd':{const arr=d.path.split('.').reduce((o,k)=>o[k],ED.d),i=+d.i,x=arr.indexOf(i);x<0?arr.push(i):arr.splice(x,1);return drawEditor()}
   case 'ed-subt':{ED.d.subs[+d.i].done=!ED.d.subs[+d.i].done;return drawEditor()}
   case 'ed-subx':{ED.d.subs.splice(+d.i,1);return drawEditor()}
   case 'ed-subadd':{const v=$('#newsub').value.trim();if(v){ED.d.subs.push({id:uid(),t:v,done:false});drawEditor();setTimeout(()=>$('#newsub')&&$('#newsub').focus(),30)}return}
   case 'ed-stepx':{ED.d.steps.splice(+d.i,1);return drawEditor()}
   case 'ed-stepadd':{const v=$('#newstep').value.trim();if(v){ED.d.steps.push({id:uid(),t:v});drawEditor();setTimeout(()=>$('#newstep')&&$('#newstep').focus(),30)}return}
   case 'ed-tomorrow':{ED.d.due=addDays(today(),1);return drawEditor()}
   case 'ed-skipnext':{const t=DB.rec[ED.id],n=nextDue(Object.assign({},t,{rule:ED.d.rule,anchor:t.anchor||t.due}),t.due>today()?t.due:today());if(n){upd(ED.id,{due:n});toast(`Skipped. Next: ${dayLabel(n)}`)}closeSheet();return render(true)}
   case 'ed-skipdate':{const ev=DB.rec[ED.id];upd(ED.id,{skip:[...(ev.skip||[]),ED.ctx]});toast('Skipped that day');closeSheet();return render(true)}
   case 'ed-save':{if(EDITORS[ED.kind].save(ED.d,ED.id)){const k=ED.kind;closeSheet();toast(k==='task'?'Task saved':'Saved');render(true)}return}
   case 'ed-del':{const id=ED.id,k=ED.kind;closeSheet();del(id);toast('Moved to recycle bin',()=>{restore(id);render(true)});return render(true)}
   case 'search':return openSearch();
   case 'bell':return openBell();
   case 'snooze':{const n=DB.rec[d.id];DB.snz.push({at:Date.now()+600000,title:n.title,body:n.body,ref:n.ref});purge(d.id);toast('Snoozed for 10 minutes');return openBell()}
   case 'notif-x':purge(d.id);return openBell();
   case 'notif-clear':all('notif').forEach(n=>purge(n.id));return openBell();
   case 'bin':return openBin();
   case 'bin-restore':restore(d.id);toast('Restored');openBin();return render(true);
   case 'bin-purge':purge(d.id);return openBin();
   case 'bin-empty':Object.values(DB.rec).filter(r=>r.deleted).forEach(r=>purge(r.id));openBin();return render(true);
   case 'confirm-yes':{const f=window._confirm;window._confirm=null;closeSheet();if(f)f();return}
   case 'export':{flush();const b=new Blob([JSON.stringify(DB,null,2)],{type:'application/json'}),l=document.createElement('a');l.href=URL.createObjectURL(b);l.download=`lifeos-backup-${today()}.json`;l.click();toast('Backup downloaded');return}
   case 'import':return $('#importFile').click();
   case 'reset':return confirmSheet('Erase everything','This permanently deletes all tasks, events, routines and settings on this device. Export a backup first if unsure.','Erase',()=>{try{localStorage.removeItem(KEY)}catch(e){}location.reload()});
   case 'clear-sample':return confirmSheet('Remove sample data','Deletes only the example items that came with the app. Anything you added stays.','Remove',()=>{Object.values(DB.rec).filter(r=>r.sample).forEach(r=>purge(r.id));toast('Sample data removed');render(true)});
   case 'notif-perm':{try{Notification.requestPermission().then(()=>render(true))}catch(err){}return}
  }
  /* simple page actions */
  if(act==='tt')toggleTask(d.id);
  else if(act==='rs')toggleStep(d.rid,d.sid);
  else if(act==='hb')toggleHabit(d.id);
  else if(act==='tf')tf=d.f;
  else if(act==='ef')ef=d.f;
  else if(act==='day')selDay=d.d;
  else if(act==='mprev'){calM.m--;if(calM.m<0){calM.m=11;calM.y--}}
  else if(act==='mnext'){calM.m++;if(calM.m>11){calM.m=0;calM.y++}}
  else if(act==='mtoday'){const n=new Date();calM={y:n.getFullYear(),m:n.getMonth()};selDay=today()}
  else if(act==='mode')setS('mode',d.m);
  else if(act==='pref')setS(d.k,d.k==='weekStart'?+d.v:d.v==='1');
  else if(act==='theme')setS('theme',d.k);
  else if(act==='water'){const w=Math.min(8,(getLog('water',today())||0)+1);setLog('water',today(),w);toast(`${w} of 8 glasses`)}
  else if(act==='logw'){const td=today(),cur=getLog('water',td)||0,v=+d.i;setLog('water',td,cur===v?v-1||null:v)}
  else if(act==='log'){const td=today(),cur=getLog(d.k,td);setLog(d.k,td,cur===+d.v?null:+d.v)}
  else if(act==='d2t'){const x=DB.rec[d.id];add('task',Object.assign(EDITORS.task.blank(),{title:x.title,due:today(),anchor:today()}));del(d.id);toast('Moved to tasks')}
  else if(act==='rm'){const id=d.id;del(id);toast('Moved to recycle bin',()=>{restore(id);render(true)})}
  else if(act==='restart-move'){dueBy(addDays(today(),-1)).forEach(t=>upd(t.id,{due:today()}));hideRestart=true;toast('Fresh start. Everything is on today.')}
  else if(act==='restart-hide')hideRestart=true;
  render(true);
});
$('#importFile').addEventListener('change',e=>{
  const f=e.target.files[0];if(!f)return;const r=new FileReader();
  r.onload=()=>{try{const j=JSON.parse(r.result);if(!j||typeof j.rec!=='object'||!j.set)throw 0;const n=Object.keys(j.rec).length;
    confirmSheet('Restore backup',`This replaces everything on this device with the backup (${n} records).`,'Restore',()=>{DB.rec=j.rec;Object.assign(DB.set,j.set);DB.fired=j.fired||{};DB.snz=j.snz||[];flush();location.reload()})}catch(err){toast('That file is not a Life OS backup')}};
  r.readAsText(f);e.target.value='';
});

