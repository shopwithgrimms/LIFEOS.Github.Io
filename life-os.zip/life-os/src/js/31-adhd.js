/* ---------- ADHD TOOLS: focus, dopamine menu, brain dump, decision help ---------- */
const DAYS3=['sun','mon','tue','wed','thu','fri','sat'];
function parseWhen(s){
  let t=s,date='',time='',m;const td=today(),low=s.toLowerCase();
  if(/\btomorrow\b/.test(low)){date=addDays(td,1);t=t.replace(/\btomorrow\b/i,'')}
  else if(/\btoday\b/.test(low)){date=td;t=t.replace(/\btoday\b/i,'')}
  else if(/\bnext week\b/.test(low)){date=addDays(td,7);t=t.replace(/\bnext week\b/i,'')}
  else if((m=low.match(/\bin (\d+) days?\b/))){date=addDays(td,+m[1]);t=t.replace(/\bin \d+ days?\b/i,'')}
  else if((m=low.match(/\b(?:on |next )?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/))){
    const i=DAYS3.indexOf(m[1].slice(0,3));let d=addDays(td,1);while(dow(d)!==i)d=addDays(d,1);date=d;t=t.replace(/\b(?:on |next )?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i,'');
  }
  if((m=low.match(/\b(?:at )?(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/))){
    let h=+m[1]%12;if(m[3]==='pm')h+=12;time=`${pad(h)}:${pad(+m[2]||0)}`;t=t.replace(/\b(?:at )?\d{1,2}(?::\d{2})?\s*(am|pm)\b/i,'');
  }else if((m=low.match(/\bat (\d{1,2}):(\d{2})\b/))){time=`${pad(+m[1])}:${m[2]}`;t=t.replace(/\bat \d{1,2}:\d{2}\b/i,'')}
  t=t.replace(/\s+/g,' ').replace(/\s+(on|at|for|by)\s*$/i,'').replace(/^(remind me to|remember to|i need to|need to)\s+/i,'').trim();
  if(t)t=t[0].toUpperCase()+t.slice(1);
  return{text:t,date,time};
}
const CAT_HINTS=[[/clean|tidy|laundry|dishes|vacuum|bins?\b|declutter/,'Household'],[/doctor|dentist|pills?|prescription|appointment|gp\b/,'Health'],[/\bpay\b|bill|bank|tax|invoice|budget/,'Financial'],[/\bbuy\b|order|shop|groceries/,'Shopping'],[/email|report|meeting|client|work\b/,'Work'],[/birthday|gift|text |call mum|call dad|friend/,'Social'],[/\bvet\b|dog|cat\b|pet\b/,'Pets'],[/\bcar\b|mot\b|tyres?|service the/,'Vehicle'],[/plant|water the|garden/,'Plants'],[/skincare|haircut|nails|makeup/,'Beauty'],[/gym|workout|run\b|walk\b/,'Fitness'],[/passport|renew|licen[cs]e|insurance|form\b/,'Admin']];
const guessCat=s=>{const l=s.toLowerCase();for(const [r,c] of CAT_HINTS)if(r.test(l))return c;return 'Personal'};
function classify(raw){
  const w=parseWhen(raw),low=raw.toLowerCase().trim(),words=w.text.split(' ').length;
  let kind='task';
  if(/^(buy|get|pick up|order|grab|need)\b/.test(low)&&words<=5&&!w.date)kind='shop';
  else if(/^(idea|maybe|someday|what if|research|look into|learn|start learning|read about|remember|note)\b/.test(low))kind='note';
  return{kind,title:w.text||raw.trim(),due:w.date,time:w.time,cat:guessCat(low)};
}
const splitThoughts=s=>s.split(/\n|;|\bthen\b/i).map(x=>x.trim()).filter(Boolean);

/* ---- brain dump ---- */
V.dump=function(){
  const l=all('dump').sort((a,b)=>b.created-a.created);
  return `<div class="stack"><div class="row"><div class="grow"><input class="input" id="dump-in" placeholder="What is on your mind" data-enter="dump-add" autocomplete="off"></div><button class="icon-btn p" data-act="dump-add" aria-label="Add">${ic('plus')}</button></div>
  ${l.length?`<button class="btn btn-soft block" data-act="dump-sort">${ic('sparkles')}Sort ${l.length} with me</button>`:''}
  ${l.length?`<div class="card"><div class="stack-sm">${l.map(x=>`<div class="item"><button class="grow" style="text-align:left" data-act="edit" data-kind="dump" data-id="${x.id}"><h4 class="t">${esc(x.title)}</h4>${x.parked?'<div class="meta">Parked during focus</div>':''}</button><button class="btn btn-soft btn-sm" data-act="d2t" data-id="${x.id}">Task</button><button class="icon-btn sm" data-act="rm" data-id="${x.id}" aria-label="Delete">${ic('x')}</button></div>`).join('')}</div></div>`:`<div class="card">${emptyBox('lightbulb','Your head is clear','Anything that pops up goes here. Decide later.')}</div>`}</div>`;
};
ACT['dump-add']=()=>{const el=$('#dump-in'),v=el.value.trim();if(!v)return false;splitThoughts(v).forEach(x=>add('dump',{title:x}));toast('Captured');render(true);setTimeout(()=>{const e=$('#dump-in');e&&e.focus()},30);return false};
let sortPlan=[];
const KIND_OPTS=[['task','Task'],['shop','Shopping list'],['note','Note'],['keep','Keep in dump'],['del','Delete']];
function sortSheet(){
  const dueTxt=p=>[p.due&&dayLabel(p.due),p.time&&fmtTime(p.time)].filter(Boolean).join(' ');
  sheet('Sort your brain dump',`<p class="sub sm-t" style="margin-bottom:12px">Here is a suggestion for each thought. Change anything, then apply. Nothing happens until you tap Apply.</p><div class="stack-sm">${sortPlan.map((p,i)=>`<div class="card" style="padding:12px"><input class="input" data-sp="title" data-i="${i}" value="${esc(p.title)}"><div class="row" style="margin-top:8px;gap:8px"><div class="grow">${`<select class="select" data-sp="kind" data-i="${i}">${KIND_OPTS.map(o=>`<option value="${o[0]}" ${p.kind===o[0]?'selected':''}>${o[1]}</option>`).join('')}</select>`}</div>${dueTxt(p)?`<span class="pill brand">${dueTxt(p)}</span>`:''}</div></div>`).join('')}</div>`,`<button class="btn btn-line" data-act="close">Cancel</button><button class="btn btn-primary" data-act="dump-apply">Apply</button>`);
}
ACT['dump-sort']=()=>{
  sortPlan=[];all('dump').sort((a,b)=>a.created-b.created).slice(0,25).forEach(x=>splitThoughts(x.title).forEach(part=>sortPlan.push(Object.assign({src:x.id},classify(part)))));
  sortSheet();return false;
};
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.sp){sortPlan[+t.dataset.i][t.dataset.sp]=t.value}});
ACT['dump-apply']=()=>{
  const made=[],gone=new Set(),keep=new Set();
  sortPlan.forEach(p=>{
    if(p.kind==='keep'){keep.add(p.src);return}
    gone.add(p.src);
    if(p.kind==='task')made.push(add('task',Object.assign(EDITORS.task.blank(),{title:p.title,cat:p.cat,due:p.due||'',time:p.time||'',anchor:p.due||''})).id);
    else if(p.kind==='shop')made.push(add('item',{coll:'shop',name:p.title}).id);
    else if(p.kind==='note')made.push(add('item',{coll:'notes',name:p.title}).id);
  });
  const ids=[...gone].filter(id=>!keep.has(id));ids.forEach(del);
  closeSheet();toast(`Sorted ${sortPlan.length} thought${sortPlan.length>1?'s':''}`,()=>{made.forEach(purge);ids.forEach(restore);render(true)});
  gain(sortPlan.length*2,sortPlan.length);
};

/* ---- help me pick ---- */
let pickSkip=[];
function pickTask(){
  const td=today(),h=new Date().getHours(),mode=DB.set.mode;
  let l=openTasks().filter(t=>!pickSkip.includes(t.id));
  if(mode==='low'){const x=l.filter(t=>t.e==='low');if(x.length)l=x}
  if(!l.length&&pickSkip.length){pickSkip=[];l=openTasks()}
  const sc=t=>{let s=0;if(t.due){const n=diffDays(td,t.due);s+=n<0?5:n===0?4:n<=2?2:0}
    s+={high:3,med:1,low:0}[t.pri]||0;
    if(mode==='overwhelmed'||mode==='low')s+=(t.est&&t.est<=15?3:0)+(t.e==='low'?2:0);
    if(h>=20&&t.e==='low')s+=2;if(h<12&&t.e==='high')s+=1;return s};
  return l.sort((a,b)=>sc(b)-sc(a))[0]||null;
}
function openPick(){
  const t=pickTask();
  if(!t){sheet('Help me pick',`<p class="sub sm-t">Nothing open. That is a good place to be.</p>`);return}
  sheet('Try this one',`<div class="card" style="text-align:center;padding:22px 16px"><div class="b" style="font-size:18px">${esc(t.title)}</div><div class="xs sub" style="margin-top:6px">${esc(taskMeta(t))}</div></div><p class="xs sub" style="margin-top:12px">Chosen from what is due, how big it is and the mode you are in. You do not have to.</p>`,
   `<button class="btn btn-line" data-act="pick-another" data-id="${t.id}">Another</button><button class="btn btn-soft" data-act="pick-done" data-id="${t.id}">Done</button><button class="btn btn-primary" data-act="focus-task" data-id="${t.id}">${ic('play')}Start</button>`);
}
ACT['pick']=()=>{openPick();return false};
ACT['pick-another']=d=>{pickSkip.push(d.id);openPick();return false};
ACT['pick-done']=d=>{closeSheet();toggleTask(d.id);return false};

/* ---- break it down ---- */
const BREAK=[[/clean|tidy|declutter|organi[sz]e/,['Put on music or a podcast','Clear rubbish and put things away','Group like with like','Wipe or sweep the surface','Take a last look and reset']],[/email|reply|message/,['Open it and read it once','Decide the one thing to say','Write a rough reply','Reread and send']],[/plan|schedule/,['List what needs to happen','Pick the dates','Put them in the calendar','Note anything to prepare']],[/write|essay|report|draft/,['Gather notes','Outline in bullets','Write a rough first draft','Edit and finish']],[/pack|trip|travel/,['Check the forecast','List the essentials','Gather everything in one place','Pack and close up']],[/cook|meal|dinner|bake/,['Pick the recipe','Check what you have','Prep the ingredients','Cook','Clean up']],[/study|learn|revise/,['Set up your space','Review notes for ten minutes','Do one practice question','Write down what is still hard']],[/call|phone|ring/,['Find the number','Note what you need to say','Make the call','Write down the outcome']],[/pay|bill|tax|form|apply|renew/,['Find the document or login','Gather what is needed','Fill it in','Submit and save proof']],[/laundry|wash/,['Gather the clothes','Start the wash','Move it on or hang it up','Fold and put away']]];
const breakSteps=t=>{const l=t.toLowerCase();for(const [r,s] of BREAK)if(r.test(l))return s;return['Decide what finished looks like','Gather what you need','Do the first five minutes','Do the main part','Check it and wrap up']};
ACT['ed-breakdown']=()=>{
  if(!ED.d.title.trim()){toast('Give the task a name first');return false}
  const have=new Set((ED.d.subs||[]).map(s=>s.t));breakSteps(ED.d.title).forEach(t=>{if(!have.has(t))ED.d.subs.push({id:uid(),t,done:false})});
  drawEditor();toast('Steps added. Edit or remove any you do not need.');return false;
};
ACT['ed-focus']=()=>{const id=ED.id;closeSheet();startFocus(id);return false};

/* ---- dopamine menu ---- */
let dopaSkip=[];
function dopaPick(){
  const h=new Date().getHours(),prefer=h<12?['Active','Quick']:h<18?['Productive','Quick']:['Relaxing','Quick'];
  let l=itemsOf('dopa').filter(r=>!dopaSkip.includes(r.id));
  if(DB.set.mode==='low'){const x=l.filter(r=>r.energy==='Low');if(x.length)l=x}
  const pr=l.filter(r=>prefer.includes(r.kind));if(pr.length)l=pr;
  if(!l.length&&dopaSkip.length){dopaSkip=[];return dopaPick()}
  return l[Math.floor(Math.random()*l.length)]||null;
}
function openDopa(){
  const r=dopaPick();
  if(!r){sheet('Dopamine menu',`<p class="sub sm-t">Add a few things you enjoy first.</p>`);return}
  sheet('How about this',`<div class="card" style="text-align:center;padding:22px 16px"><div class="b" style="font-size:18px">${esc(r.name)}</div><div class="xs sub" style="margin-top:6px">${[r.kind,r.mins&&`${r.mins} min`].filter(Boolean).join(' · ')}</div></div>`,`<button class="btn btn-line" data-act="dopa-another" data-id="${r.id}">Another</button><button class="btn btn-primary" data-act="close">Sounds good</button>`);
}
V.dopamine=function(){const c=collOf('dopa');return `<div class="stack"><p class="sub sm-t">Things that give you a lift. Pick by mood, time and energy instead of scrolling.</p><button class="btn btn-primary block" data-act="dopa-suggest">${ic('shuffle')}Suggest something</button>${collBody(c,false)}${stickyAdd('add-item" data-coll="dopa','Add activity')}</div>`};
ACT['dopa-suggest']=()=>{dopaSkip=[];openDopa();return false};
ACT['dopa-another']=d=>{dopaSkip.push(d.id);openDopa();return false};

/* ---- focus timer, parking lot, body doubling ---- */
const fcfg={task:'',mins:25,brk:5,bd:false,intent:''};
const fmtMS=ms=>{const s=Math.max(0,Math.ceil(ms/1000));return `${pad(Math.floor(s/60))}:${pad(s%60)}`};
const FOCUS_NUDGES=['Still with it? You are doing fine.','A sip of water, then back to it.','Small progress counts.','Unclench your jaw and drop your shoulders.','Nearly there. Keep the next step tiny.'];
function startFocus(taskId){
  const t=taskId&&DB.rec[taskId];
  fcfg.task=taskId||'';if(t&&t.est>0&&t.est<=90)fcfg.mins=t.est;
  go('focus');
}
const focusRing=(frac,txt='')=>{const S=200,sw=10,R=(S-sw)/2,Cc=2*Math.PI*R;return `<div class="ring" style="width:${S}px;height:${S}px"><svg viewBox="0 0 ${S} ${S}"><circle cx="${S/2}" cy="${S/2}" r="${R}" fill="none" stroke="var(--line)" stroke-width="${sw}"/><circle id="fcirc" cx="${S/2}" cy="${S/2}" r="${R}" fill="none" stroke="var(--p)" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${Cc}" stroke-dashoffset="${Cc*(1-frac)}"/></svg><b id="ftime" style="font-size:38px;letter-spacing:-.02em">${txt}</b></div>`};
const parkList=()=>{const l=all('dump',x=>x.parked).sort((a,b)=>b.created-a.created).slice(0,6);return `<div class="card"><div class="eyebrow" style="margin-bottom:8px">Parking lot</div><p class="xs sub" style="margin-bottom:10px">Stray thought? Park it here and get back to work.</p><div class="row"><div class="grow"><input class="input" id="park-in" placeholder="Park a thought" data-enter="park" autocomplete="off"></div><button class="icon-btn p" data-act="park" aria-label="Park">${ic('plus')}</button></div>${l.length?`<div class="stack-sm" style="margin-top:10px">${l.map(x=>`<div class="xs">${esc(x.title)}</div>`).join('')}</div>`:''}</div>`};
V.focus=function(){
  const f=DB.set.focus,td=today(),tm=getLog('focus',td)||0;
  if(f){
    const t=f.task&&DB.rec[f.task];
    return `<div class="stack"><div class="card" style="text-align:center"><div class="eyebrow" style="margin-bottom:12px">${f.mode==='break'?'Break':'Focus'}${t?` · ${esc(t.title)}`:''}</div><div style="display:flex;justify-content:center">${focusRing(f.paused?(f.left/f.total):((f.end-Date.now())/f.total),fmtMS(f.paused?f.left:f.end-Date.now()))}</div>
    ${f.bd&&f.mode==='focus'?`<p class="sm-t" style="margin-top:14px">Working alongside you${f.intent?`: <b>${esc(f.intent)}</b>`:''}. I will check in gently.</p>`:''}
    <div class="grid2" style="margin-top:16px"><button class="btn btn-line" data-act="f-pause">${ic(f.paused?'play':'pause')}${f.paused?'Resume':'Pause'}</button><button class="btn btn-primary" data-act="f-finish">${f.mode==='break'?'Skip break':'Finish'}</button></div>
    ${f.mode==='focus'?`<button class="link" style="margin-top:12px" data-act="f-add">Add 5 minutes</button>`:''}</div>${f.mode==='focus'?parkList():''}</div>`;
  }
  const tasks=openTasks().sort(byDue);
  return `<div class="stack"><div class="card"><div class="eyebrow" style="margin-bottom:12px">Start a session</div>
   <label class="fld"><span>Working on</span><select class="select" data-fc="task"><option value="">Anything</option>${tasks.map(t=>`<option value="${t.id}" ${fcfg.task===t.id?'selected':''}>${esc(t.title)}</option>`).join('')}</select></label>
   <div class="fld"><span>Length</span><div class="chips">${[[15,3],[25,5],[50,10]].map(p=>`<button class="chip ${fcfg.mins===p[0]?'on':''}" data-act="f-pre" data-m="${p[0]}" data-b="${p[1]}">${p[0]} / ${p[1]}</button>`).join('')}</div></div>
   <div class="grid2"><label class="fld"><span>Focus (min)</span><input class="input" type="number" min="1" max="180" data-fc="mins" value="${fcfg.mins}"></label><label class="fld"><span>Break (min)</span><input class="input" type="number" min="1" max="60" data-fc="brk" value="${fcfg.brk}"></label></div>
   <div class="fld"><span>Body doubling</span><button type="button" class="chip ${fcfg.bd?'on':''}" style="align-self:flex-start" data-act="f-bd">${fcfg.bd?'On':'Off'}</button><div class="xs sub" style="margin-top:4px">Work alongside a quiet presence with gentle check-ins. A nudge only, not a person.</div></div>
   ${fcfg.bd?`<label class="fld"><span>What will you do?</span><input class="input" data-fc="intent" value="${esc(fcfg.intent)}" placeholder="Say it out loud, then type it"></label>`:''}
   <button class="btn btn-primary block" data-act="f-start">${ic('play')}Start focus</button></div>
  <div class="grid2">${stat('Focused today',`${tm} min`)}${stat('Sessions',`${getLog('focusN',td)||0}`)}</div>${parkList()}</div>`;
};
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.fc){const k=t.dataset.fc;fcfg[k]=t.type==='number'?(+t.value||0):t.value}});
ACT['f-pre']=d=>{fcfg.mins=+d.m;fcfg.brk=+d.b};
ACT['f-bd']=()=>{fcfg.bd=!fcfg.bd};
ACT['f-start']=()=>{
  const m=Math.max(1,Math.min(180,+fcfg.mins||25)),now=Date.now();
  DB.set.focus={mode:'focus',end:now+m*60000,total:m*60000,paused:false,task:fcfg.task,bd:fcfg.bd,intent:fcfg.intent,nextCheck:now+10*60000,n:0};persist();
};
ACT['f-pause']=()=>{const f=DB.set.focus;if(f.paused){f.end=Date.now()+f.left;f.paused=false}else{f.left=f.end-Date.now();f.paused=true}persist()};
ACT['f-add']=()=>{const f=DB.set.focus;if(f.paused)f.left+=300000;else f.end+=300000;f.total+=300000;persist()};
ACT['f-finish']=()=>{endFocus(false)};
ACT['park']=()=>{const el=$('#park-in'),v=el.value.trim();if(!v)return false;add('dump',{title:v,parked:true});toast('Parked');render(true);setTimeout(()=>{const e=$('#park-in');e&&e.focus()},30);return false};
function endFocus(done){
  const f=DB.set.focus;if(!f)return;DB.set.focus=null;persist();
  if(f.mode==='break'){if(done)fire('Break over','Ready when you are.','');render(true);return}
  const elapsed=done?f.total:Math.max(0,f.total-(f.paused?f.left:Math.max(0,f.end-Date.now()))),m=Math.round(elapsed/60000);
  if(m>=1){const td=today();setLog('focus',td,(getLog('focus',td)||0)+m);if(done)setLog('focusN',td,(getLog('focusN',td)||0)+1)}
  if(done){gain(15,8);checkBadges();fire('Focus session complete',`${m} minutes. Nicely done.`,'')}
  const t=f.task&&DB.rec[f.task]&&DB.rec[f.task].status!=='done'?DB.rec[f.task]:null;
  if(done){sheet('Nice work',`<p class="sub sm-t">You focused for ${m} minutes. Stand up, stretch and drink some water before the next thing.</p>${t?`<p class="b" style="margin-top:12px">Is "${esc(t.title)}" finished?</p>`:''}`,`${t?`<button class="btn btn-soft" data-act="f-taskdone" data-id="${t.id}">Mark done</button>`:''}<button class="btn btn-line" data-act="f-break">Take a break</button><button class="btn btn-primary" data-act="f-again">Another round</button>`)}
  else{toast(m?`Logged ${m} min`:'Session ended')}
  if(view==='focus')render(true);
}
ACT['f-taskdone']=d=>{closeSheet();toggleTask(d.id);return false};
ACT['f-break']=()=>{closeSheet();const m=Math.max(1,+fcfg.brk||5);DB.set.focus={mode:'break',end:Date.now()+m*60000,total:m*60000,paused:false};persist();go('focus');return false};
ACT['f-again']=()=>{closeSheet();ACT['f-start']();go('focus');return false};
function focusTick(){
  const f=DB.set.focus;if(!f||f.paused)return;
  const left=f.end-Date.now();
  if(left<=0)return endFocus(true);
  if(f.bd&&f.mode==='focus'&&Date.now()>=f.nextCheck){f.nextCheck+=600000;f.n=(f.n||0)+1;persist();toast(FOCUS_NUDGES[f.n%FOCUS_NUDGES.length])}
  if(view==='focus'){const e=$('#ftime');if(e){e.textContent=fmtMS(left);const c=$('#fcirc');if(c){const C_=+c.getAttribute('stroke-dasharray');c.setAttribute('stroke-dashoffset',C_*(1-left/f.total))}}}
}
/* a small banner on Home while a session runs */
const _homeV=V.home;V.home=function(){const f=DB.set.focus;return (f?`<button class="card row between" style="width:100%;margin-bottom:12px;border-color:var(--p)" data-go="focus"><span><span class="b">${f.mode==='break'?'Break':'Focus'} in progress</span><span class="xs sub" style="display:block">Tap to return</span></span>${ic('play')}</button>`:'')+_homeV()};
