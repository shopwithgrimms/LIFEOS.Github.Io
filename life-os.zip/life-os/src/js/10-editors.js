/* ---------- EDITORS (draft-based bottom sheets) ---------- */
const NR=()=>({freq:'none',every:1,days:[],unit:'day'});
const setPath=(o,p,v)=>{const k=p.split('.');let c=o;for(let i=0;i<k.length-1;i++)c=c[k[i]];c[k[k.length-1]]=v};
const sel=(f,opts,val,re)=>`<select class="select" data-f="${f}" ${re?'data-re':''}>${opts.map(o=>`<option value="${o[0]}" ${String(o[0])===String(val)?'selected':''}>${o[1]}</option>`).join('')}</select>`;
const inp=(f,val,ph,type='text',extra='')=>`<input class="input" type="${type}" data-f="${f}" value="${esc(val)}" placeholder="${esc(ph||'')}" ${extra}>`;
function ruleBlock(d){
  const r=d.rule,rep=r.freq!=='none',u={daily:'day(s)',weekly:'week(s)',monthly:'month(s)',yearly:'year(s)'}[r.freq];
  return `<label class="fld"><span>Repeat</span>${sel('rule.freq',[['none','Does not repeat'],['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['yearly','Yearly'],['after','After I finish it']],r.freq,true)}</label>`+
  (rep&&r.freq!=='after'?`<div class="grid2"><label class="fld"><span>Every</span>${inp('rule.every',r.every,'1','number','min="1" max="99" inputmode="numeric"')}</label><div class="fld"><span>&nbsp;</span><div class="sub sm-t" style="padding:13px 2px">${u}</div></div></div>`:'')+
  (r.freq==='after'?`<div class="grid2"><label class="fld"><span>Wait</span>${inp('rule.every',r.every,'1','number','min="1" max="99" inputmode="numeric"')}</label><label class="fld"><span>Unit</span>${sel('rule.unit',[['day','Days'],['week','Weeks'],['month','Months']],r.unit)}</label></div>`:'')+
  (r.freq==='weekly'?`<div class="fld"><span>On</span><div class="wk">${DOWL.map((n,i)=>`<button type="button" class="chip ${r.days.includes(i)?'on':''}" data-act="ed-wd" data-path="rule.days" data-i="${i}">${n[0]}</button>`).join('')}</div></div>`:'')+
  (rep&&r.freq!=='after'?`<label class="fld"><span>Ends on (optional)</span>${inp('until',d.until||'','','date')}</label>`:'');
}
const remindFld=d=>`<label class="fld"><span>Reminder</span>${sel('remind',REMIND,d.remind==null?'none':d.remind)}</label>`;
const EDITORS={
 task:{label:'task',blank:()=>({title:'',notes:'',cat:'Personal',pri:'med',e:'med',est:0,due:today(),time:'',rule:NR(),remind:'none',subs:[],status:'open',project:'',goal:'',area:''}),
  body(d,id){return `<label class="fld"><span>Task</span>${inp('title',d.title,'What needs doing')}</label>
   <label class="fld"><span>Notes</span><textarea class="input" data-f="notes" rows="2" placeholder="Optional">${esc(d.notes)}</textarea></label>
   <div class="grid2"><label class="fld"><span>Due date</span>${inp('due',d.due,'','date')}</label><label class="fld"><span>Time</span>${inp('time',d.time,'','time')}</label></div>
   <div class="grid2"><label class="fld"><span>Category</span>${sel('cat',CATS.map(c=>[c,c]),d.cat)}</label><label class="fld"><span>Priority</span>${sel('pri',Object.entries(PRI),d.pri)}</label></div>
   <div class="grid2"><label class="fld"><span>Energy needed</span>${sel('e',[['low','Low'],['med','Medium'],['high','High']],d.e)}</label><label class="fld"><span>Estimate (min)</span>${inp('est',d.est||'','0','number','min="0" inputmode="numeric"')}</label></div>
   <div class="grid2"><label class="fld"><span>Project</span>${sel('project',[['','None'],...all('project',p=>p.status!=='done').map(p=>[p.id,p.title])],d.project||'')}</label><label class="fld"><span>Goal</span>${sel('goal',[['','None'],...all('goal',g=>g.status!=='done').map(g=>[g.id,g.title])],d.goal||'')}</label></div>
   <label class="fld"><span>Area (room, pet, vehicle, plant)</span><input class="input" data-f="area" list="areas" value="${esc(d.area||'')}" placeholder="Optional"><datalist id="areas">${[...new Set(all('task').map(t=>t.area).filter(Boolean))].map(a=>`<option value="${esc(a)}">`).join('')}</datalist></label>
   ${ruleBlock(d)}${remindFld(d)}
   <div class="fld"><span>Subtasks</span><div class="stack-sm">${(d.subs||[]).map((s,i)=>`<div class="row">${check(s.done,`data-act="ed-subt" data-i="${i}"`)}<div class="grow">${inp(`subs.${i}.t`,s.t,'Subtask')}</div><button class="icon-btn sm" data-act="ed-subx" data-i="${i}" aria-label="Remove">${ic('x')}</button></div>`).join('')}
   <div class="row"><div class="grow"><input class="input" id="newsub" placeholder="Add a subtask" data-enter="ed-subadd"></div><button class="icon-btn p" data-act="ed-subadd" aria-label="Add subtask">${ic('plus')}</button></div></div></div>
   <div class="grid2" style="margin-top:4px"><button class="btn btn-line btn-sm" data-act="ed-breakdown">${ic('sparkles')}Break it down</button>${id?`<button class="btn btn-line btn-sm" data-act="ed-focus">${ic('play')}Start focus</button>`:'<span></span>'}</div>
   ${id?`<div class="grid2" style="margin-top:10px"><button class="btn btn-line btn-sm" data-act="ed-tomorrow">${ic('clock')}Do tomorrow</button>${isRepeating(d)?`<button class="btn btn-line btn-sm" data-act="ed-skipnext">${ic('skip')}Skip this time</button>`:'<span></span>'}</div>`:''}`},
  save(d,id){
    if(!d.title.trim()){toast('Add a title');return false}
    const v=Object.assign({},d,{title:d.title.trim(),est:+d.est||0});
    if(isRepeating(v)&&!v.due)v.due=today();
    if(v.rule.freq==='weekly'&&!(v.rule.days||[]).length&&v.due)v.rule.days=[dow(v.due)];
    v.anchor=v.due||'';if(!isRepeating(v))v.until='';
    if(id)upd(id,v);else add('task',v);return true;}},
 event:{label:'event',blank:()=>({title:'',date:selDay,start:'09:00',end:'',loc:'',cat:'',notes:'',rule:NR(),remind:'none'}),
  body(d,id){return `<label class="fld"><span>Event</span>${inp('title',d.title,'What is happening')}</label>
   <label class="fld"><span>Date</span>${inp('date',d.date,'','date')}</label>
   <div class="grid2"><label class="fld"><span>Starts</span>${inp('start',d.start,'','time')}</label><label class="fld"><span>Ends</span>${inp('end',d.end,'','time')}</label></div>
   <label class="fld"><span>Location</span>${inp('loc',d.loc,'Optional')}</label>
   <label class="fld"><span>Category</span>${sel('cat',[['','None'],...CATS.map(c=>[c,c])],d.cat||'')}</label>
   <label class="fld"><span>Notes</span><textarea class="input" data-f="notes" rows="2" placeholder="Optional">${esc(d.notes)}</textarea></label>
   ${ruleBlock(d)}${remindFld(d)}
   ${id&&isRepeating(d)&&ED.ctx?`<button class="btn btn-line btn-sm block" data-act="ed-skipdate">${ic('skip')}Skip ${dayLabel(ED.ctx)} only</button>`:''}`},
  save(d,id){
    if(!d.title.trim()){toast('Add a title');return false}
    if(!d.date){toast('Pick a date');return false}
    const v=Object.assign({},d,{title:d.title.trim()});
    if(v.rule.freq==='after')v.rule=NR();
    if(v.rule.freq==='weekly'&&!(v.rule.days||[]).length)v.rule.days=[dow(v.date)];
    if(!isRepeating(v))v.until='';
    if(id)upd(id,v);else add('event',v);return true;}},
 routine:{label:'routine',blank:()=>({title:'',time:'08:00',days:[],remind:'none',steps:[]}),
  body(d){return `<label class="fld"><span>Routine</span>${inp('title',d.title,'For example, morning skincare')}</label>
   <label class="fld"><span>Time</span>${inp('time',d.time,'','time')}</label>
   <div class="fld"><span>Days <em style="text-transform:none;font-style:normal;font-weight:500">none selected means every day</em></span><div class="wk">${DOWL.map((n,i)=>`<button type="button" class="chip ${d.days.includes(i)?'on':''}" data-act="ed-wd" data-path="days" data-i="${i}">${n[0]}</button>`).join('')}</div></div>
   ${remindFld(d)}
   <div class="fld"><span>Steps</span><div class="stack-sm">${d.steps.map((s,i)=>`<div class="row"><div class="grow">${inp(`steps.${i}.t`,s.t,'Step')}</div><button class="icon-btn sm" data-act="ed-stepx" data-i="${i}" aria-label="Remove">${ic('x')}</button></div>`).join('')}
   <div class="row"><div class="grow"><input class="input" id="newstep" placeholder="Add a step" data-enter="ed-stepadd"></div><button class="icon-btn p" data-act="ed-stepadd" aria-label="Add step">${ic('plus')}</button></div></div></div>`},
  save(d,id){
    if(!d.title.trim()){toast('Add a name');return false}
    const v=Object.assign({},d,{title:d.title.trim(),steps:d.steps.filter(s=>s.t.trim()).map(s=>Object.assign({},s,{t:s.t.trim()}))});
    if(id)upd(id,v);else add('routine',v);return true;}},
 habit:{label:'habit',blank:()=>({title:'',target:5}),
  body(d){return `<label class="fld"><span>Habit</span>${inp('title',d.title,'For example, read ten pages')}</label><label class="fld"><span>Days per week you are aiming for</span>${sel('target',[1,2,3,4,5,6,7].map(n=>[n,`${n} ${n>1?'days':'day'}`]),d.target)}</label><p class="xs sub">Flexible by design. No streaks, no pressure.</p>`},
  save(d,id){if(!d.title.trim()){toast('Add a name');return false}const v=Object.assign({},d,{title:d.title.trim(),target:+d.target||5});if(id)upd(id,v);else add('habit',v);return true}},
 dump:{label:'thought',blank:()=>({title:''}),
  body(d){return `<label class="fld"><span>Thought</span><textarea class="input" data-f="title" rows="3" placeholder="What is on your mind">${esc(d.title)}</textarea></label>`},
  save(d,id){if(!d.title.trim()){toast('Write something first');return false}const v={title:d.title.trim()};if(id)upd(id,v);else add('dump',v);return true}},
 reward:{label:'reward',blank:()=>({title:'',cost:20}),
  body(d){return `<label class="fld"><span>Reward</span>${inp('title',d.title,'For example, a long bath')}</label><label class="fld"><span>Cost (coins)</span>${inp('cost',d.cost,'20','number','min="1" inputmode="numeric"')}</label>`},
  save(d,id){if(!d.title.trim()){toast('Name the reward');return false}const v={title:d.title.trim(),cost:Math.max(1,+d.cost||1)};if(id)upd(id,v);else add('reward',v);return true}}
};
function openEditor(kind,id,ctx){
  const base=id?clone(DB.rec[id]):EDITORS[kind].blank();
  if(kind==='task'||kind==='event'){base.rule=Object.assign(NR(),base.rule||{});base.rule.days=base.rule.days||[]}
  if(kind==='task')base.subs=base.subs||[];
  ED={kind,id,d:base,ctx};drawEditor();
}
function drawEditor(){
  const e=ED,old=$('#modal .sheet-body'),st=old?old.scrollTop:0;
  $('#modal').innerHTML=`<div class="sheet"><div class="sheet-head"><h3>${e.id?'Edit':'New'} ${EDITORS[e.kind].label}</h3><button class="icon-btn" data-act="close" aria-label="Close">${ic('x')}</button></div><div class="sheet-body">${EDITORS[e.kind].body(e.d,e.id)}</div><div class="sheet-foot">${e.id?`<button class="icon-btn btn-danger" data-act="ed-del" aria-label="Delete">${ic('trash')}</button>`:''}<button class="btn btn-primary" data-act="ed-save">${e.id?'Save changes':'Add'}</button></div></div>`;
  $('#modal').classList.add('on');
  const nb=$('#modal .sheet-body');if(nb)nb.scrollTop=st;
}
const closeSheet=()=>{$('#modal').classList.remove('on');$('#modal').innerHTML='';ED=null;chrome()};
function sheet(title,body,foot){$('#modal').innerHTML=`<div class="sheet"><div class="sheet-head"><h3>${title}</h3><button class="icon-btn" data-act="close" aria-label="Close">${ic('x')}</button></div><div class="sheet-body">${body}</div>${foot?`<div class="sheet-foot">${foot}</div>`:''}</div>`;$('#modal').classList.add('on')}

