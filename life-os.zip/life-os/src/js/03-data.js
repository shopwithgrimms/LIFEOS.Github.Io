/* ---------- DATA LAYER (universal records) ---------- */
const KEY='lifeos_db_v1';
const DB={v:1,rec:{},set:{theme:'blush',mode:'normal',weekStart:0,clock12:true,qOn:true,qStart:'22:00',qEnd:'07:00',xp:0,coins:0,lastOpen:'',seeded:false},fired:{},snz:[]};
let storageOK=true;
function load(){try{const j=JSON.parse(localStorage.getItem(KEY)||'null');if(j&&j.rec){DB.rec=j.rec;Object.assign(DB.set,j.set||{});DB.fired=j.fired||{};DB.snz=j.snz||[]}}catch(e){storageOK=false}}
let saveT;
function persist(){clearTimeout(saveT);saveT=setTimeout(flush,120)}
function flush(){try{localStorage.setItem(KEY,JSON.stringify(DB))}catch(e){if(storageOK){storageOK=false;toast('Could not save. Export a backup from Settings.')}}}
window.addEventListener('pagehide',flush);
const uid=()=>(window.crypto&&crypto.randomUUID?crypto.randomUUID().slice(0,8):Math.random().toString(36).slice(2,10));
const clone=o=>JSON.parse(JSON.stringify(o));
const add=(type,d)=>{const r=Object.assign({id:uid(),type,created:Date.now(),updated:Date.now()},d);DB.rec[r.id]=r;persist();return r};
const upd=(id,p)=>{if(!DB.rec[id])return;Object.assign(DB.rec[id],p,{updated:Date.now()});persist()};
const del=id=>{if(DB.rec[id]){DB.rec[id].deleted=Date.now();persist()}};
const restore=id=>{if(DB.rec[id]){delete DB.rec[id].deleted;persist()}};
const purge=id=>{delete DB.rec[id];persist()};
const all=(type,f)=>Object.values(DB.rec).filter(r=>r.type===type&&!r.deleted&&(!f||f(r)));
const setS=(k,v)=>{DB.set[k]=v;persist()};
const gain=(x,c)=>{DB.set.xp=Math.max(0,DB.set.xp+x);DB.set.coins=Math.max(0,DB.set.coins+c);persist()};
const level=()=>Math.floor(DB.set.xp/100)+1;
/* completions: one record per (item, date) so toggling never duplicates */
const cid=(ref,date)=>`c_${ref}_${date}`;
const isDone=(ref,date)=>!!DB.rec[cid(ref,date)];
function setDone(ref,date,on,kind){const k=cid(ref,date);if(on){DB.rec[k]={id:k,type:'comp',ref,date,kind,created:Date.now(),updated:Date.now()}}else delete DB.rec[k];persist()}
/* logs: one record per (kind, date) */
const getLog=(kind,date)=>{const r=DB.rec[`l_${kind}_${date}`];return r?r.value:null};
function setLog(kind,date,value){const k=`l_${kind}_${date}`;if(value==null)delete DB.rec[k];else DB.rec[k]={id:k,type:'log',kind,date,value,created:Date.now(),updated:Date.now()};persist()}

