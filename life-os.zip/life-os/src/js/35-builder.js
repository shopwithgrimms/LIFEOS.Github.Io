/* ---------- CUSTOM TRACKER BUILDER ---------- */
const TPL_PRESETS=[
  {title:'Weight',fields:[{t:'num',l:'Weight',u:'kg'}]},
  {title:'Gratitude',fields:[{t:'text',l:'Something good today',u:''}]},
  {title:'Medication taken',fields:[{t:'check',l:'Taken',u:''},{t:'text',l:'Notes',u:''}]},
  {title:'Reading',fields:[{t:'num',l:'Pages',u:'pages'},{t:'scale',l:'Enjoyment',u:''}]},
  {title:'Screen time',fields:[{t:'num',l:'Hours',u:'h'}]},
  {title:'Blank tracker',fields:[{t:'num',l:'Value',u:''}]}];
const FTYPES=[['num','Number'],['scale','Scale 1 to 5'],['check','Yes or no'],['text','Short text']];
const tentId=(tpl,date)=>`te_${tpl}_${date}`;
const getEntry=(tpl,date)=>DB.rec[tentId(tpl,date)];

EDITORS.tpl={label:'tracker',blank:()=>({title:'',fields:[{id:uid(),l:'Value',t:'num',u:''}]}),
  body(d){return `<label class="fld"><span>Tracker name</span>${inp('title',d.title,'For example, weight')}</label>
   <div class="fld"><span>What to record</span><div class="stack-sm">${d.fields.map((f,i)=>`<div class="card" style="padding:10px"><div class="row" style="gap:8px"><div class="grow">${inp(`fields.${i}.l`,f.l,'Label')}</div><button class="icon-btn sm" data-act="ed-fx" data-i="${i}" aria-label="Remove">${ic('x')}</button></div><div class="grid2" style="margin-top:8px">${sel(`fields.${i}.t`,FTYPES,f.t)}${f.t==='num'?inp(`fields.${i}.u`,f.u,'Unit'):'<span></span>'}</div></div>`).join('')}<button class="btn btn-line btn-sm" data-act="ed-fadd">${ic('plus')}Add a field</button></div></div>`},
  save(d,id){if(!d.title.trim()){toast('Name the tracker');return false}const f=d.fields.filter(x=>x.l.trim());if(!f.length){toast('Add at least one field');return false}
    const v=Object.assign({},d,{title:d.title.trim(),fields:f.map(x=>Object.assign({},x,{l:x.l.trim()}))});if(id)upd(id,v);else add('tpl',v);return true}};
ACT['ed-fadd']=()=>{ED.d.fields.push({id:uid(),l:'',t:'num',u:''});drawEditor();return false};
ACT['ed-fx']=d=>{ED.d.fields.splice(+d.i,1);drawEditor();return false};

const entrySummary=(t,e)=>e?t.fields.map(f=>{const v=e.vals[f.id];if(v==null||v==='')return'';return f.t==='check'?(v?f.l:''):f.t==='num'?`${v}${f.u?' '+f.u:''}`:f.t==='scale'?`${f.l} ${v}/5`:v}).filter(Boolean).join(' · '):'';
function customTrackers(){
  const l=all('tpl'),td=today();
  return `<div class="row between"><span class="eyebrow">Your trackers</span><button class="link" data-act="tpl-new">New tracker</button></div>
  ${l.length?l.map(t=>{const e=getEntry(t.id,td),nf=t.fields.find(f=>f.t==='num'),vals=nf?Array.from({length:7},(_,i)=>getEntry(t.id,addDays(td,-i))).map(x=>x&&x.vals[nf.id]).filter(v=>v!==''&&v!=null&&v!==undefined).map(Number):[],av=vals.length?(vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(1):null;
    return `<div class="card"><div class="row between" style="margin-bottom:8px"><span class="b">${esc(t.title)}</span><span class="row" style="gap:4px"><button class="icon-btn sm" data-act="tpl-hist" data-id="${t.id}" aria-label="History">${ic('clock')}</button><button class="icon-btn sm" data-act="edit" data-kind="tpl" data-id="${t.id}" aria-label="Edit">${ic('pencil')}</button></span></div>
    <div class="xs sub" style="margin-bottom:10px">${e?`Today: ${esc(entrySummary(t,e))||'logged'}`:'Nothing logged today'}${av?` · 7-day average ${av}${nf.u?' '+esc(nf.u):''}`:''}</div><button class="btn btn-soft btn-sm" data-act="tpl-log" data-id="${t.id}">${e?'Update today':'Log today'}</button></div>`}).join(''):`<div class="card">${emptyBox('activity','No custom trackers','Track anything: weight, pages read, gratitude, medication.')}</div>`}`;
}
ACT['tpl-new']=()=>{sheet('New tracker',`<div class="stack-sm">${TPL_PRESETS.map((p,i)=>`<button class="list-row" data-act="tpl-use" data-i="${i}"><div class="grow"><h4>${p.title}</h4><div class="xs sub">${p.fields.map(f=>f.l).join(', ')}</div></div>${ic('chevron-right')}</button>`).join('')}</div>`);return false};
ACT['tpl-use']=d=>{const p=TPL_PRESETS[+d.i];closeSheet();openEditor('tpl',null);if(p.title!=='Blank tracker')ED.d.title=p.title;ED.d.fields=p.fields.map(f=>Object.assign({id:uid()},f));drawEditor();return false};
let TLOG=null;
function logSheet(){
  const t=DB.rec[TLOG.tpl];
  sheet(`${esc(t.title)} · today`,t.fields.map(f=>{const v=TLOG.vals[f.id];
    if(f.t==='scale')return `<div class="fld"><span>${esc(f.l)}</span><div class="seg">${[1,2,3,4,5].map(n=>`<button class="${v===n?'on':''}" data-act="tl-scale" data-f="${f.id}" data-v="${n}">${n}</button>`).join('')}</div></div>`;
    if(f.t==='check')return `<div class="fld"><span>${esc(f.l)}</span><button type="button" class="chip ${v?'on':''}" style="align-self:flex-start" data-act="tl-chk" data-f="${f.id}">${v?'Yes':'No'}</button></div>`;
    return `<label class="fld"><span>${esc(f.l)}${f.u?` (${esc(f.u)})`:''}</span><input class="input" ${f.t==='num'?'type="number" step="any" inputmode="decimal"':''} data-tl="${f.id}" value="${esc(v==null?'':v)}"></label>`}).join(''),
   `<button class="btn btn-line" data-act="close">Cancel</button><button class="btn btn-primary" data-act="tl-save">Save</button>`);
}
ACT['tpl-log']=d=>{const e=getEntry(d.id,today());TLOG={tpl:d.id,vals:e?Object.assign({},e.vals):{}};logSheet();return false};
ACT['tl-scale']=d=>{TLOG.vals[d.f]=+d.v;logSheet();return false};
ACT['tl-chk']=d=>{TLOG.vals[d.f]=!TLOG.vals[d.f];logSheet();return false};
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.tl&&TLOG)TLOG.vals[t.dataset.tl]=t.type==='number'?(t.value===''?'':+t.value):t.value});
ACT['tl-save']=()=>{const k=tentId(TLOG.tpl,today()),had=!!DB.rec[k];DB.rec[k]={id:k,type:'tent',tpl:TLOG.tpl,date:today(),vals:TLOG.vals,created:(DB.rec[k]||{}).created||Date.now(),updated:Date.now()};persist();if(!had)gain(5,2);closeSheet();toast('Logged')};
ACT['tpl-hist']=d=>{const t=DB.rec[d.id],l=all('tent',e=>e.tpl===d.id).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,14);
  sheet(`${esc(t.title)} history`,l.length?l.map(e=>`<div class="kv"><span class="sub">${dayLabel(e.date)}</span><b style="font-size:13px;text-align:right">${esc(entrySummary(t,e))||'Logged'}</b></div>`).join(''):`<p class="sub sm-t">Nothing logged yet.</p>`);return false};
