/* ---------- DATES (all dates are local 'YYYY-MM-DD' strings) ---------- */
const pad=n=>String(n).padStart(2,'0');
const fmt=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const parse=s=>{const[a,b,c]=s.split('-').map(Number);return new Date(a,b-1,c,12)};
const today=()=>fmt(new Date());
const addDays=(s,n)=>{const d=parse(s);d.setDate(d.getDate()+n);return fmt(d)};
const addMonths=(s,n)=>{const d=parse(s),day=d.getDate();d.setDate(1);d.setMonth(d.getMonth()+n);const dim=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(day,dim));return fmt(d)};
const diffDays=(a,b)=>Math.round((parse(b)-parse(a))/864e5);
const dow=s=>parse(s).getDay();
const DOWL=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

