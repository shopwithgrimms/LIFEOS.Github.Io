/* ---------- VIEWS ---------- */
const taskMeta=t=>[t.cat,t.due&&dayLabel(t.due),t.time&&fmtTime(t.time),t.est&&`${t.est} min`,(t.subs&&t.subs.length)&&`${t.subs.filter(s=>s.done).length}/${t.subs.length} steps`].filter(Boolean).join(' · ');
const taskItem=(t,bare)=>{const inner=`<div class="item ${t.status==='done'?'done':''}">${check(t.status==='done',`data-act="tt" data-id="${t.id}"`)}<button class="grow" style="text-align:left" data-act="edit" data-kind="task" data-id="${t.id}"><h4 class="t trunc">${esc(t.title)}</h4><div class="meta trunc">${esc(taskMeta(t))}</div></button>${isRepeating(t)?ic('repeat'):''}<span class="pill ${EN[t.e||'med'][1]}">${EN[t.e||'med'][0]}</span></div>`;return bare?inner:`<div class="card sm">${inner}</div>`};
const habitRow=h=>{const td=today(),dots=weekDots(h),n=dots.filter(Boolean).length;return `<div class="item ${isDone(h.id,td)?'done':''}">${check(isDone(h.id,td),`data-act="hb" data-id="${h.id}"`)}<button class="grow" style="text-align:left" data-act="edit" data-kind="habit" data-id="${h.id}"><h4 class="t">${esc(h.title)}</h4><div class="meta">${n} of ${h.target} this week</div></button><div class="wkdots">${dots.map(x=>`<i class="${x?'on':''}"></i>`).join('')}</div></div>`};
const tlRow=i=>`<button class="tl" data-act="${i.item?'edit-item':i.kind==='routine'?'go-routines':'edit'}" data-kind="${i.kind}" data-id="${i.id}" data-ctx="${i.date||selDay}"><span class="tm num">${i.time?fmtTime(i.time):'All day'}</span><div class="grow"><h4 style="font-size:14px;font-weight:700" class="trunc">${esc(i.title)}</h4>${i.sub?`<div class="xs sub trunc">${esc(i.sub)}</div>`:''}</div><span class="pill ${i.kind==='event'?'brand':i.kind==='routine'?'ok':'mute'}">${i.kind}</span></button>`;
function section(label,html){return html?`<div class="eyebrow sec-h">${label}</div><div class="stack-sm">${html}</div>`:''}

const V={
tasks(){
  const td=today(),fl=[['today','Today'],['upcoming','Upcoming'],['all','All'],['done','Done']],el=[['any','Any energy'],['low','Low'],['med','Medium'],['high','High']];
  let l=all('task');const en=DB.set.mode==='low'&&ef==='any'?'low':ef;
  if(tf==='done')l=l.filter(t=>t.status==='done').sort((a,b)=>b.updated-a.updated);
  else{l=l.filter(t=>t.status!=='done');if(tf==='today')l=l.filter(t=>t.due&&t.due<=td);if(tf==='upcoming')l=l.filter(t=>t.due&&t.due>td);l.sort(byDue)}
  if(en!=='any')l=l.filter(t=>t.e===en);
  let body='';
  if(tf==='today')body=section('Earlier',l.filter(t=>t.due<td).map(t=>taskItem(t)).join(''))+section('Today',l.filter(t=>t.due===td).map(t=>taskItem(t)).join(''));
  else if(tf==='upcoming'){const g={};l.forEach(t=>(g[t.due]=g[t.due]||[]).push(t));body=Object.keys(g).sort().map(d=>section(dayLabel(d),g[d].map(t=>taskItem(t)).join(''))).join('')}
  else if(tf==='all')body=section('Scheduled',l.filter(t=>t.due).map(t=>taskItem(t)).join(''))+section('Anytime',l.filter(t=>!t.due).map(t=>taskItem(t)).join(''));
  else body=`<div class="stack-sm">${l.map(t=>taskItem(t)).join('')}</div>`;
  return `<div class="chips" style="margin-bottom:8px">${fl.map(f=>`<button class="chip ${tf===f[0]?'on':''}" data-act="tf" data-f="${f[0]}">${f[1]}</button>`).join('')}</div>
  <div class="chips" style="margin-bottom:6px">${el.map(f=>`<button class="chip ${en===f[0]?'on':''}" data-act="ef" data-f="${f[0]}">${f[1]}</button>`).join('')}</div>
  ${openTasks().length?`<div style="margin:6px 0 12px"><button class="btn btn-soft btn-sm" data-act="pick">${ic('sparkles')}Help me pick one</button></div>`:''}
  ${l.length?body:`<div class="card" style="margin-top:12px">${emptyBox('list-checks',tf==='done'?'Nothing completed yet':'Nothing here','Add a task to get started.')}</div>`}${stickyAdd('new" data-kind="task','Add task')}`;
},
calendar(){
  const td=today(),{y,m}=calM,ws=DB.set.weekStart,first=new Date(y,m,1),lead=(first.getDay()-ws+7)%7,n=new Date(y,m+1,0).getDate();
  let c=Array.from({length:7},(_,i)=>`<div class="dow">${DOWL[(i+ws)%7][0]}</div>`).join('')+'<span></span>'.repeat(lead);
  for(let i=1;i<=n;i++){const ds=`${y}-${pad(m+1)}-${pad(i)}`;c+=`<button data-act="day" data-d="${ds}" class="${ds===td?'today':''} ${ds===selDay?'sel':''}">${i}<span class="dot ${hasStuff(ds)?'on':''}"></span></button>`}
  const items=dayItems(selDay),tasks=all('task',t=>t.status!=='done'&&t.due===selDay&&!t.time).sort(byDue),evAll=all('event',e=>occursOn(e,selDay)&&!e.start);
  return `<div class="stack"><div class="card"><div class="row between" style="margin-bottom:12px"><button class="icon-btn sm" data-act="mprev" aria-label="Previous month">${ic('chevron-left')}</button><button class="b" data-act="mtoday">${new Date(y,m,1).toLocaleString(undefined,{month:'long',year:'numeric'})}</button><button class="icon-btn sm" data-act="mnext" aria-label="Next month">${ic('chevron-right')}</button></div><div class="cal">${c}</div></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:6px">${longDay(selDay)}</div>${items.map(tlRow).join('')}${evAll.map(e=>tlRow({date:selDay,time:'',title:e.title,kind:'event',id:e.id,sub:e.loc})).join('')}${tasks.length?`<div class="eyebrow sec-h">Tasks due</div><div class="stack-sm">${tasks.map(t=>taskItem(t,true)).join('')}</div>`:''}${!items.length&&!tasks.length&&!evAll.length?emptyBox('calendar','A free day','Nothing scheduled.'):''}</div></div>${stickyAdd('new" data-kind="event','Add event')}`;
},
more(){return `<div class="stack-sm">${MORE.map(m=>`<button class="list-row" data-go="${m[0]}"><div class="ico">${ic(m[3])}</div><div class="grow"><h4>${m[1]}</h4><div class="xs sub">${m[2]}</div></div>${ic('chevron-right')}</button>`).join('')}</div>`},
routines(){
  const td=today(),rs=all('routine'),act=rs.filter(r=>routineOn(r,td)),rest=rs.filter(r=>!routineOn(r,td));
  const card=(r,on)=>{const d=r.steps.filter(s=>isDone(s.id,td)).length,dl=r.days&&r.days.length?r.days.map(x=>DOWL[x]).join(', '):'Every day';
    return `<div class="card"><div class="row between" style="margin-bottom:12px"><div class="grow"><span class="b">${esc(r.title)}</span><div class="xs sub">${r.time?fmtTime(r.time)+' · ':''}${dl}</div></div>${on?`<span class="pill brand num">${d}/${r.steps.length}</span>`:''}<button class="icon-btn sm" data-act="edit" data-kind="routine" data-id="${r.id}" aria-label="Edit">${ic('pencil')}</button></div>${on?`<div class="bar" style="margin-bottom:14px"><i style="width:${pct(d,r.steps.length)}%"></i></div><div class="stack-sm">${r.steps.map(s=>`<div class="item ${isDone(s.id,td)?'done':''}">${check(isDone(s.id,td),`data-act="rs" data-rid="${r.id}" data-sid="${s.id}"`)}<div class="grow"><h4 class="t">${esc(s.t)}</h4></div></div>`).join('')||'<p class="xs sub">No steps yet. Tap the pencil to add some.</p>'}</div>`:''}</div>`};
  return `<div class="stack">${act.length?`<div class="eyebrow">Today</div>`+act.map(r=>card(r,true)).join(''):''}${rest.length?`<div class="eyebrow">Other days</div>`+rest.map(r=>card(r,false)).join(''):''}${!rs.length?`<div class="card">${emptyBox('repeat','No routines yet','Build a morning or evening routine.')}</div>`:''}
  <div class="row between"><span class="eyebrow">Habits</span><button class="link" data-act="new" data-kind="habit">Add habit</button></div><div class="card"><div class="stack-sm">${all('habit').map(habitRow).join('')||emptyBox('repeat','No habits yet','Track what you want, your way.')}</div></div></div>${stickyAdd('new" data-kind="routine','Add routine')}`;
},
trackers(){
  const td=today(),w=getLog('water',td)||0,L=(k)=>getLog(k,td);
  const avg=k=>{const v=Array.from({length:7},(_,i)=>getLog(k,addDays(td,-i))).filter(x=>x!=null);return v.length?(v.reduce((a,b)=>a+b,0)/v.length).toFixed(1):null};
  const scale=(k,labels)=>`<div class="seg">${labels.map((l,i)=>`<button class="${L(k)===i+1?'on':''}" data-act="log" data-k="${k}" data-v="${i+1}">${l}</button>`).join('')}</div>${avg(k)?`<p class="xs sub" style="margin-top:8px">7-day average ${avg(k)} of ${labels.length}</p>`:''}`;
  return `<div class="stack"><div class="card"><div class="row between" style="margin-bottom:12px"><span class="eyebrow">Water</span><span class="b num">${w} / 8</span></div><div class="drops">${Array.from({length:8},(_,i)=>`<button class="${i<w?'on':''}" data-act="logw" data-i="${i+1}" aria-label="${i+1} glasses"></button>`).join('')}</div></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Mood</div>${scale('mood',['Low','Meh','Okay','Good','Great'])}</div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Energy</div>${scale('energy',['Drained','Low','Steady','Good','High'])}</div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Sleep last night</div>${scale('sleep',['Under 5h','5-6h','7h','8h','9h+'])}</div>
  ${customTrackers()}</div>`}
};
