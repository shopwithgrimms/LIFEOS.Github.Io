/* ---------- THEMES ---------- */
const Lt=(n,p,soft,dark,bg)=>({n,p,soft,dark,bg,card:'#ffffff',text:'#2d2d2d',sub:'#737373',line:'#e5e5e5',d:false});
const Dk=(n,p,soft,dark,bg,card,text,sub,line)=>({n,p,soft,dark,bg,card,text,sub,line,d:true});
const THEMES={
 blush:Lt('Blush Rose','#d97793','#fdf2f4','#b35470','#f7f3f4'),
 lavender:Lt('Lavender Dream','#7c3aed','#f5f3ff','#5b21b6','#faf8fc'),
 mint:Lt('Minty Fresh','#059669','#ecfdf5','#047857','#f4f8f6'),
 vanilla:Lt('Vanilla Latte','#854d0e','#fefce8','#713f12','#fbf9f5'),
 ocean:Lt('Ocean Breeze','#0891b2','#ecfeff','#0e7490','#f3fafb'),
 paper:Lt('Paper White','#374151','#f3f4f6','#1f2937','#fafafa'),
 midnight:Dk('Midnight Luxe','#38bdf8','#1e293b','#0284c7','#12151e','#1c2130','#f1f5f9','#94a3b8','#2a324a'),
 rosewood:Dk('Rosewood','#f43f5e','#4c1d25','#e11d48','#151012','#21181c','#fce7f0','#d1a3b8','#3d262e'),
 lavender_noir:Dk('Lavender Noir','#a78bfa','#2e1065','#8b5cf6','#13111c','#1d1929','#f5f3ff','#b8a9d4','#312847'),
 espresso:Dk('Espresso Luxe','#fbbf24','#422006','#d97706','#16110e','#241b14','#fef3c7','#d4b896','#3b2b20'),
 sage_noir:Dk('Sage Noir','#34d399','#064e3b','#059669','#0f1713','#17251e','#ecfdf5','#98d8be','#223d30'),
 graphite:Dk('Graphite','#cbd5e1','#1e293b','#64748b','#0f1115','#1a1f26','#f1f5f9','#94a3b8','#2d3748')
};
const lum=h=>{const n=parseInt(h.slice(1),16),f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(n>>16)+.7152*f((n>>8)&255)+.0722*f(n&255)};

