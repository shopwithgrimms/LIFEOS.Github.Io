/* ---------- HOME, MY LIFE, DEPARTMENT VIEWS, SETTINGS ---------- */
const countIn=d=>d.colls.reduce((a,id)=>a+itemsOf(id).length,0);
const visibleDepts=()=>DEPTS.filter(d=>!(DB.set.hid||[]).includes(d.id));
const fmtLeft=m=>m<=0?'now':m<60?`in ${m} min`:`in ${Math.floor(m/60)} h${m%60?` ${m%60} min`:''}`;
const nowMins=()=>{const n=new Date();return n.getHours()*60+n.getMinutes()};

/* home widgets */
const WIDGETS={
 now:{name:'Up next',draw(){
   const nm=nowMins(),l=dayItems(today()).filter(i=>i.time&&mins(i.time)>=nm-5);
   const n=l[0];
   return `<div class="eyebrow" style="margin-bottom:8px">Up next</div>${n?`<div class="row between"><div class="grow"><div class="b">${esc(n.title)}</div><div class="xs sub">${fmtTime(n.time)}</div></div><span class="pill brand num">${fmtLeft(mins(n.time)-nm)}</span></div>`:`<div class="sub sm-t">Nothing else scheduled today.</div>`}`}},
 progress:{name:'Today progress',draw(){const p=progressToday();return `<div class="row" style="gap:16px">${ring(p.pct,64,7)}<div class="grow"><div class="b">${p.done} of ${p.total} done</div><div class="xs sub">${p.total?'Every bit counts. Nothing here is overdue in a bad way.':'A clear day. Add something when you are ready.'}</div></div></div>`}},
 tasks:{name:'Tasks today',draw(){
   let l=dueBy(today()).sort(byDue);if(DB.set.mode==='low')l=l.filter(t=>t.e==='low');
   return `<div class="row between" style="margin-bottom:8px"><span class="eyebrow">Tasks today</span><button class="link" data-go="tasks">See all</button></div>${l.length?`<div class="stack-sm">${l.slice(0,5).map(t=>taskItem(t)).join('')}</div>${l.length>5?`<div class="xs sub" style="margin-top:8px">+${l.length-5} more</div>`:''}`:`<div class="sub sm-t">Nothing due. Enjoy it.</div>`}`}},
 schedule:{name:'Schedule',draw(){const l=dayItems(today());return `<div class="row between" style="margin-bottom:6px"><span class="eyebrow">Schedule</span><button class="link" data-go="calendar">Calendar</button></div>${l.length?l.slice(0,5).map(tlRow).join(''):`<div class="sub sm-t">No scheduled items today.</div>`}`}},
 routines:{name:'Routines',draw(){const td=today(),rs=all('routine',r=>routineOn(r,td));if(!rs.length)return '';return `<div class="row between" style="margin-bottom:8px"><span class="eyebrow">Routines</span><button class="link" data-go="routines">Open</button></div><div class="stack-sm">${rs.map(r=>{const d=r.steps.filter(s=>isDone(s.id,td)).length;return `<button class="list-row" style="padding:10px 14px" data-go="routines"><div class="grow"><h4>${esc(r.title)}</h4><div class="xs sub">${r.time?fmtTime(r.time):''}</div></div><span class="pill brand num">${d}/${r.steps.length}</span></button>`}).join('')}</div>`}},
 habits:{name:'Habits',draw(){const h=all('habit');if(!h.length)return '';return `<div class="eyebrow" style="margin-bottom:8px">Habits</div><div class="stack-sm">${h.map(habitRow).join('')}</div>`}},
 quick:{name:'Quick add',draw(){return `<div class="quick"><button data-act="new" data-kind="task">${ic('plus')}Task</button><button data-act="new" data-kind="dump">${ic('lightbulb')}Thought</button><button data-go="focus">${ic('play')}Focus</button><button data-act="water">${ic('droplet')}Water</button></div>`}},
 attention:{name:'Needs attention',draw(){const l=attention(5);if(!l.length)return '';return `<div class="eyebrow" style="margin-bottom:6px">Needs a look</div>${l.map(a=>`<button class="kv" style="width:100%;text-align:left" data-act="edit-item" data-id="${a.id}" data-coll="${a.coll}"><div class="grow"><div class="b trunc" style="font-size:13px">${esc(a.title)}</div><div class="xs sub">${esc(a.text)}</div></div>${ic('chevron-right')}</button>`).join('')}`}},
 goals:{name:'Goals',draw(){const g=all('goal',x=>x.status!=='done').slice(0,3);if(!g.length)return '';return `<div class="row between" style="margin-bottom:8px"><span class="eyebrow">Goals</span><button class="link" data-go="goals">All</button></div><div class="stack-sm">${g.map(x=>`<button class="barrow" style="text-align:left;width:100%" data-go="goal" data-arg="${x.id}"><div class="top"><span class="b trunc">${esc(x.title)}</span><span class="num sub">${goalProgress(x)}%</span></div><div class="bar"><i style="width:${goalProgress(x)}%"></i></div></button>`).join('')}</div>`}},
 companion:{name:'Companion',draw(){return `<button class="row" style="gap:14px;width:100%;text-align:left" data-go="rewards"><div style="width:64px;flex:none">${companionSVG()}</div><div class="grow"><div class="b">${esc((DB.set.pet||{}).name||'Your companion')}</div><div class="xs sub">Level ${level()} · ${DB.set.coins} coins</div><div class="bar" style="margin-top:6px"><i style="width:${DB.set.xp%100}%"></i></div></div></button>`}},
 dump:{name:'Brain dump',draw(){const n=all('dump').length;return n?`<button class="row between" style="width:100%" data-go="dump"><span><span class="b">${n}</span> thought${n>1?'s':''} waiting</span>${ic('chevron-right')}</button>`:''}}
};
const WID_ALL=Object.keys(WIDGETS);
const WID_PRESETS={standard:{o:['now','progress','tasks','schedule','routines','habits','quick','attention','goals','companion','dump'],h:[]},minimal:{o:['now','tasks','schedule','quick','progress','routines','habits','attention','goals','companion','dump'],h:['routines','habits','attention','goals','companion','dump','progress']},focused:{o:['now','tasks','quick','schedule','progress','routines','habits','attention','goals','companion','dump'],h:['goals','companion','dump','attention']}};
const widOrder=()=>{const o=(DB.set.wido||WID_PRESETS.standard.o).filter(id=>WIDGETS[id]);WID_ALL.forEach(id=>{if(!o.includes(id))o.push(id)});return o};
const widHidden=()=>DB.set.widh||[];

V.home=function(){
  const td=today(),md=DB.set.mode;
  let out=`<div class="row between" style="margin-bottom:14px"><div><div class="xs sub">${longDay(td)}</div><h2 style="font-size:22px;font-weight:800;letter-spacing:-.01em">${greeting()}</h2></div><div class="seg" style="width:auto">${[['normal','Standard'],['overwhelmed','Calm'],['low','Low energy']].map(m=>`<button class="${md===m[0]?'on':''}" data-act="mode" data-m="${m[0]}" style="padding:6px 8px;font-size:11px">${m[1]}</button>`).join('')}</div></div>`;
  if(away>=3&&!hideRestart)out+=`<div class="card" style="margin-bottom:12px;border-color:var(--p)"><div class="b">Welcome back</div><p class="sub sm-t" style="margin:4px 0 12px">No catching up needed. Move anything that slipped onto today, or just start fresh from here.</p><div class="grid2"><button class="btn btn-primary btn-sm" data-act="restart-move">Move to today</button><button class="btn btn-line btn-sm" data-act="restart-hide">Dismiss</button></div></div>`;
  if(md==='overwhelmed'){
    const t=pickTask(),urgent=dueBy(td).filter(x=>x.pri==='high'&&(!t||x.id!==t.id)).slice(0,3);
    return out+`<div class="card" style="margin-bottom:12px"><div class="eyebrow" style="margin-bottom:8px">Just one thing</div>${t?`<div class="b" style="font-size:17px;margin-bottom:4px">${esc(t.title)}</div><div class="xs sub" style="margin-bottom:14px">${esc(taskMeta(t))}</div><div class="grid2"><button class="btn btn-primary" data-act="focus-task" data-id="${t.id}">${ic('play')}Start</button><button class="btn btn-line" data-act="pick-skip" data-id="${t.id}">Another</button></div>`:`<div class="sub sm-t">Nothing needs you right now. Rest is allowed.</div>`}</div>
    ${urgent.length?`<div class="card" style="margin-bottom:12px"><div class="eyebrow" style="margin-bottom:8px">Also important today</div><div class="stack-sm">${urgent.map(x=>taskItem(x)).join('')}</div></div>`:''}
    ${WIDGETS.now.draw()?`<div class="card" style="margin-bottom:12px">${WIDGETS.now.draw()}</div>`:''}
    <p class="xs sub" style="text-align:center">Everything else is hidden on purpose. Switch back to Standard any time.</p>`;
  }
  const hid=widHidden();
  widOrder().filter(id=>!hid.includes(id)).forEach(id=>{const h=WIDGETS[id].draw();if(h)out+=`<div class="card" style="margin-bottom:12px">${h}</div>`});
  return out;
};

V.life=function(){
  const v=visibleDepts();
  return `<div class="stack">${AREAS.map(a=>{const l=v.filter(d=>d.area===a);return l.length?`<div><div class="eyebrow" style="margin-bottom:8px">${a}</div><div class="stack-sm">${l.map(d=>{const n=countIn(d);return `<button class="list-row" data-go="dept" data-arg="${d.id}"><div class="ico">${ic(d.icon)}</div><div class="grow"><h4>${d.name}</h4><div class="xs sub">${d.desc}</div></div>${n?`<span class="pill mute num">${n}</span>`:''}${ic('chevron-right')}</button>`}).join('')}</div></div>`:''}).join('')}<p class="xs sub" style="text-align:center">Hide departments you do not use in Settings.</p></div>`;
};
V.dept=function(){
  const d=deptOf(viewArg);if(!d)return emptyBox('layout-grid','Not found','');
  const tasks=d.cat?openTasks().filter(t=>t.cat===d.cat).sort(byDue):[];
  return `<div class="stack"><p class="sub sm-t">${d.desc}</p>
  ${(d.links||[]).map(l=>`<button class="list-row" data-go="${l[0]}"><div class="ico">${ic(l[0]==='dump'?'lightbulb':'play')}</div><div class="grow"><h4>${l[1]}</h4></div>${ic('chevron-right')}</button>`).join('')}
  <div class="stack-sm">${d.colls.map(id=>{const c=collOf(id),n=itemsOf(id).length;return `<button class="list-row" data-go="coll" data-arg="${d.id}|${id}"><div class="ico">${ic(c.icon)}</div><div class="grow"><h4>${c.title}</h4><div class="xs sub">${n} ${n===1?c.noun.toLowerCase():c.noun.toLowerCase()+'s'}</div></div>${ic('chevron-right')}</button>`}).join('')}</div>
  ${d.cat?`<div class="row between"><span class="eyebrow">Tasks in this area</span><button class="link" data-act="area-task" data-cat="${d.cat}">Add task</button></div>${tasks.length?`<div class="card"><div class="stack-sm">${tasks.slice(0,8).map(t=>taskItem(t)).join('')}</div></div>`:`<div class="card">${emptyBox('list-checks','No open tasks','Recurring chores live here too.')}</div>`}`:''}</div>`;
};
V.coll=function(){const c=collOf(String(viewArg).split('|')[1]);return c?collBody(c):emptyBox('layout-grid','Not found','')};
ACT['area-task']=d=>{openEditor('task',null);ED.d.cat=d.cat;drawEditor();return false};

/* ---------- preferences applied to the page ---------- */
function applyPrefs(){
  const c=document.documentElement.classList;
  c.toggle('ts-l',DB.set.ts==='large');c.toggle('ts-xl',DB.set.ts==='xl');
  c.toggle('rm',!!DB.set.rm);c.toggle('hc',!!DB.set.hc);
}
ACT['setv']=d=>{const v=d.t==='b'?d.v==='1':d.t==='n'?+d.v:d.v;setS(d.k,v);applyPrefs()};
ACT['wid-up']=d=>{const o=widOrder(),i=o.indexOf(d.id);if(i>0){[o[i-1],o[i]]=[o[i],o[i-1]];DB.set.wido=o;persist()}};
ACT['wid-dn']=d=>{const o=widOrder(),i=o.indexOf(d.id);if(i<o.length-1){[o[i+1],o[i]]=[o[i],o[i+1]];DB.set.wido=o;persist()}};
ACT['wid-tog']=d=>{const h=widHidden().slice(),i=h.indexOf(d.id);i<0?h.push(d.id):h.splice(i,1);DB.set.widh=h;persist()};
ACT['wid-preset']=d=>{const p=WID_PRESETS[d.p];DB.set.wido=p.o.slice();DB.set.widh=p.h.slice();persist()};
ACT['dept-tog']=d=>{const h=(DB.set.hid||[]).slice(),i=h.indexOf(d.id);i<0?h.push(d.id):h.splice(i,1);DB.set.hid=h;persist()};
ACT['focus-task']=d=>{startFocus(d.id);return false};
ACT['pick-skip']=d=>{pickSkip.push(d.id)};
ACT['restart-move']=()=>{dueBy(addDays(today(),-1)).forEach(t=>upd(t.id,{due:today()}));hideRestart=true;toast('Fresh start. Everything is on today.')};

/* ---------- app lock (a privacy screen, not encryption) ---------- */
const pinHash=s=>{let h=5381;for(const ch of s+'lifeos')h=((h<<5)+h+ch.charCodeAt(0))|0;return String(h)};
function showLock(){
  if(!DB.set.pin||$('#lock'))return;
  const el=document.createElement('div');el.id='lock';el.className='lock';
  el.innerHTML=`<div class="lock-in">${ic('lock')}<h3>Life OS is locked</h3><input class="input" id="pin" type="password" inputmode="numeric" autocomplete="off" placeholder="Enter your PIN" style="text-align:center"><div class="xs sub" id="pinmsg" style="min-height:16px"></div></div>`;
  document.querySelector('.frame').appendChild(el);
  const inp_=$('#pin');inp_.focus();
  inp_.addEventListener('input',()=>{if(pinHash(inp_.value)===DB.set.pin){el.remove();render(true)}else if(inp_.value.length>=(DB.set.pinLen||4))$('#pinmsg').textContent='That is not it. Try again.'});
}
ACT['lock-now']=()=>{showLock();return false};
ACT['pin-set']=()=>{sheet('App lock',`<p class="sub sm-t" style="margin-bottom:12px">Choose a PIN of 4 to 8 digits. This hides the app on this device. It does not encrypt your data.</p><input class="input" id="newpin" type="password" inputmode="numeric" maxlength="8" placeholder="New PIN">`,`<button class="btn btn-line" data-act="close">Cancel</button><button class="btn btn-primary" data-act="pin-save">Save PIN</button>`);return false};
ACT['pin-save']=()=>{const v=$('#newpin').value.trim();if(!/^\d{4,8}$/.test(v)){toast('Use 4 to 8 digits');return false}DB.set.pin=pinHash(v);DB.set.pinLen=v.length;persist();closeSheet();toast('App lock is on')};
ACT['pin-off']=()=>{delete DB.set.pin;persist();toast('App lock removed')};

/* ---------- settings ---------- */
const segBtns=(k,t,opts,cur)=>`<div class="seg">${opts.map(o=>`<button class="${String(cur)===String(o[0])?'on':''}" data-act="setv" data-k="${k}" data-t="${t}" data-v="${o[0]}">${o[1]}</button>`).join('')}</div>`;
const onOff=(k,cur)=>segBtns(k,'b',[['1','On'],['0','Off']],cur?'1':'0');
const setRow=(l,h,c)=>`<div class="fld" style="margin-bottom:14px"><span>${l}</span>${c}${h?`<div class="xs sub" style="margin-top:6px">${h}</div>`:''}</div>`;
V.settings=function(){
  const s=DB.set,perm=('Notification' in window)?Notification.permission:'unsupported',hid=widHidden(),ord=widOrder();
  return `<div class="stack">
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Appearance</div>
   <div class="swatches" style="margin-bottom:6px">${Object.entries(THEMES).map(([k,t])=>`<button class="swatch ${s.theme===k?'on':''}" style="--sw-p:${t.p};background:${t.bg}" data-act="theme" data-k="${k}" aria-label="${t.n}" title="${t.n}"></button>`).join('')}</div>
   <div class="xs sub" style="margin-bottom:14px">${(THEMES[s.theme]||THEMES.blush).n}</div>
   ${setRow('Text size','',segBtns('ts','s',[['normal','Normal'],['large','Large'],['xl','Largest']],s.ts||'normal'))}
   ${setRow('Reduce motion','Turns off animations.',onOff('rm',s.rm))}
   ${setRow('High contrast','Stronger borders and text.',onOff('hc',s.hc))}
   ${setRow('Week starts on','',segBtns('weekStart','n',[[0,'Sunday'],[1,'Monday']],s.weekStart))}
   ${setRow('Clock','',segBtns('clock12','b',[['1','12 hour'],['0','24 hour']],s.clock12?'1':'0'))}
   <label class="fld"><span>Currency symbol</span><input class="input" data-set="cur" value="${esc(s.cur||'$')}" maxlength="3" style="max-width:100px"></label></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Mode</div>${segBtns('mode','s',[['normal','Standard'],['overwhelmed','Calm'],['low','Low energy']],s.mode)}<div class="xs sub" style="margin-top:8px">Calm shows one thing at a time. Low energy only suggests easy tasks.</div></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Home layout</div>
   <div class="chips" style="margin-bottom:12px">${Object.keys(WID_PRESETS).map(p=>`<button class="chip" data-act="wid-preset" data-p="${p}">${p[0].toUpperCase()+p.slice(1)}</button>`).join('')}</div>
   ${ord.map((id,i)=>`<div class="kv"><span class="${hid.includes(id)?'sub':'b'}" style="font-size:13px">${WIDGETS[id].name}</span><span class="row" style="gap:2px"><button class="icon-btn sm" data-act="wid-up" data-id="${id}" aria-label="Move up">${ic('arrow-up')}</button><button class="icon-btn sm" data-act="wid-dn" data-id="${id}" aria-label="Move down">${ic('arrow-down')}</button><button class="icon-btn sm" data-act="wid-tog" data-id="${id}" aria-label="Show or hide">${ic(hid.includes(id)?'eye-off':'eye')}</button></span></div>`).join('')}</div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Departments</div><div class="chips" style="flex-wrap:wrap">${DEPTS.map(d=>`<button class="chip ${(s.hid||[]).includes(d.id)?'':'on'}" data-act="dept-tog" data-id="${d.id}">${d.name}</button>`).join('')}</div><div class="xs sub" style="margin-top:8px">Highlighted departments show in My Life. Hidden ones keep their data.</div></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Reminders</div>
   ${setRow('Quiet hours','No reminders during this window.',onOff('qOn',s.qOn))}
   ${s.qOn?`<div class="grid2" style="margin-bottom:14px"><label class="fld"><span>From</span><input class="input" type="time" data-set="qStart" value="${s.qStart}"></label><label class="fld"><span>Until</span><input class="input" type="time" data-set="qEnd" value="${s.qEnd}"></label></div>`:''}
   ${setRow('Transition warnings','A nudge 10 minutes before events and timed tasks that have no reminder of their own.',onOff('warn',s.warn))}
   <div class="kv"><span>Browser notifications</span><span>${perm==='granted'?'<span class="pill ok">Allowed</span>':perm==='unsupported'?'<span class="pill mute">Unsupported</span>':`<button class="btn btn-soft btn-sm" data-act="notif-perm">Allow</button>`}</span></div>
   <p class="xs sub" style="margin-top:6px">Reminders run while Life OS is open in a tab or installed app. A web page cannot wake itself when closed.</p></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Goals and tracking</div><label class="fld"><span>Daily calorie goal (optional)</span><input class="input" type="number" inputmode="numeric" data-set="calGoal" data-num value="${s.calGoal||''}" placeholder="Not set" style="max-width:160px"></label></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Privacy</div>
   <div class="kv"><span>App lock (PIN)</span><span>${s.pin?`<button class="btn btn-line btn-sm" data-act="pin-off">Remove</button>`:`<button class="btn btn-soft btn-sm" data-act="pin-set">Set PIN</button>`}</span></div>
   ${s.pin?`<button class="btn btn-line btn-sm block" style="margin-top:8px" data-act="lock-now">${ic('lock')}Lock now</button>`:''}
   <p class="xs sub" style="margin-top:8px">The PIN hides the screen. Your data is stored in this browser unencrypted, so keep your device secure.</p></div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Your data</div>
   <div class="stack-sm"><button class="btn btn-line block" data-act="export">${ic('download')}Export backup</button><button class="btn btn-line block" data-act="import">${ic('upload')}Restore from backup</button><button class="btn btn-line block" data-act="bin">${ic('archive')}Recycle bin</button><button class="btn btn-line block" data-act="clear-sample">${ic('trash')}Remove sample data</button><button class="btn btn-danger block" data-act="reset">Erase everything</button></div>
   <p class="xs sub" style="margin-top:10px">Everything lives in this browser on this device. Export a backup regularly.${storageOK?'':' Saving is currently unavailable in this browser.'}</p></div>
  </div>`;
};
