/* ---------- REMINDERS ---------- */
const mins=t=>{const[h,m]=t.split(':').map(Number);return h*60+m};
function inQuiet(now=new Date()){
  if(!DB.set.qOn)return false;const a=mins(DB.set.qStart),b=mins(DB.set.qEnd),n=now.getHours()*60+now.getMinutes();
  if(a===b)return false;return a<b?(n>=a&&n<b):(n>=a||n<b);
}
function reminderCandidates(){
  const out=[],td=today(),days=[0,1,2].map(i=>addDays(td,i)),has=x=>x.remind!=null&&x.remind!==''&&x.remind!=='none',use=x=>has(x)||(DB.set.warn&&(x.start||x.time)),rm=x=>has(x)?+x.remind:10;
  all('task',t=>t.status!=='done'&&t.due&&use(t)).forEach(t=>out.push({id:t.id,title:t.title,date:t.due,time:t.time||'09:00',rm:rm(t),kind:'Task'}));
  all('event',use).forEach(e=>days.forEach(d=>{if(occursOn(e,d))out.push({id:e.id,title:e.title,date:d,time:e.start||'09:00',rm:rm(e),kind:'Event'})}));
  all('routine',r=>use(r)&&r.time).forEach(r=>days.forEach(d=>{if(routineOn(r,d))out.push({id:r.id,title:r.title,date:d,time:r.time,rm:rm(r),kind:'Routine'})}));
  return out;
}
function fire(title,body,ref){
  add('notif',{title,body,ref,at:Date.now(),read:false});
  const n=all('notif');if(n.length>150)n.sort((a,b)=>a.at-b.at).slice(0,n.length-150).forEach(x=>purge(x.id));
  if(!$('#modal').classList.contains('on'))toast(title);
  try{if('Notification' in window&&Notification.permission==='granted')new Notification(title,{body})}catch(e){}
  if(!$('#modal').classList.contains('on'))chrome();
}
function tick(){
  const now=Date.now(),quiet=inQuiet();let changed=false;
  if(!quiet){
    reminderCandidates().forEach(c=>{
      const key=`${c.id}|${c.date}|${c.time}|${c.rm}`,ts=new Date(`${c.date}T${c.time}:00`).getTime()-c.rm*60000;
      if(ts<=now&&now-ts<12*3600e3&&!DB.fired[key]){DB.fired[key]=now;changed=true;fire(`${c.kind}: ${c.title}`,c.rm?`Starts at ${fmtTime(c.time)}`:'Happening now',c.id)}
    });
    DB.snz=DB.snz.filter(s=>{if(s.at<=now){fire(s.title,s.body,s.ref);changed=true;return false}return true});
    watchItems((key,title,body)=>{if(!DB.fired[key]){DB.fired[key]=now;changed=true;fire(title,body,'')}});
  }
  for(const k in DB.fired)if(now-DB.fired[k]>7*864e5){delete DB.fired[k];changed=true}
  if(changed)persist();
}
const unread=()=>all('notif',n=>!n.read).length;

