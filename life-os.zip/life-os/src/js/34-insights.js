/* ---------- INSIGHTS (descriptive, never judgmental) ---------- */
let insR='week';
const INS_DAYS={week:7,month:30,year:365};
const hr12=h=>`${h%12||12} ${h<12?'AM':'PM'}`;
const avgLog=(k,from)=>{const v=all('log',l=>l.kind===k&&l.date>=from).map(l=>l.value);return v.length?v.reduce((a,b)=>a+b,0)/v.length:null};
function buckets(n){
  const td=today();
  if(n===7)return Array.from({length:7},(_,i)=>{const d=addDays(td,i-6);return{l:DOWL[dow(d)][0],f:d,t:d}});
  if(n===30)return Array.from({length:6},(_,i)=>{const f=addDays(td,i*5-29),t=addDays(td,i*5-25);return{l:parse(f).getDate()+'',f,t}});
  return Array.from({length:12},(_,i)=>{const d=new Date(parse(td).getFullYear(),parse(td).getMonth()-11+i,1),f=fmt(d),t=fmt(new Date(d.getFullYear(),d.getMonth()+1,0));return{l:d.toLocaleString(undefined,{month:'short'})[0],f,t}});
}
V.insights=function(){
  const n=INS_DAYS[insR],from=addDays(today(),-(n-1)),cs=all('comp',c=>c.date>=from),bk=buckets(n);
  const tasks=cs.filter(c=>c.kind==='task').length,habits=cs.filter(c=>c.kind==='habit').length,steps=cs.filter(c=>c.kind==='step').length;
  const series=bk.map(b=>cs.filter(c=>c.date>=b.f&&c.date<=b.t).length),mx=Math.max(1,...series);
  const foc=sumBy(all('log',l=>l.kind==='focus'&&l.date>=from).map(l=>({v:l.value})),'v');
  const catC={};cs.filter(c=>c.kind==='task').forEach(c=>{const t=DB.rec[c.ref];if(t)catC[t.cat||'Personal']=(catC[t.cat||'Personal']||0)+1});
  const cats=Object.entries(catC).sort((a,b)=>b[1]-a[1]).slice(0,5),cmx=cats.length?cats[0][1]:1;
  const hrs=new Array(24).fill(0);cs.filter(c=>c.kind!=='habit'||true).forEach(c=>{if(c.created)hrs[new Date(c.created).getHours()]++});
  const bestH=hrs.indexOf(Math.max(...hrs));
  const ex=itemsOf('expense').filter(r=>r.date>=from),inc=itemsOf('income').filter(r=>r.date>=from),by={};ex.forEach(r=>by[r.cat||'Other']=(by[r.cat||'Other']||0)+(+r.amount||0));
  const sp=Object.entries(by).sort((a,b)=>b[1]-a[1]).slice(0,4),smx=sp.length?sp[0][1]:1;
  const wk=itemsOf('workout').filter(r=>r.date>=from);
  const mood=avgLog('mood',from),en=avgLog('energy',from),sl=avgLog('sleep',from);
  const unused=visibleDepts().filter(d=>!countIn(d));
  const goalsDone=all('goal',g=>g.status==='done'&&(g.doneAt||'')>=from).length;
  return `<div class="stack"><div class="seg">${[['week','Week'],['month','Month'],['year','Year']].map(r=>`<button class="${insR===r[0]?'on':''}" data-act="insr" data-r="${r[0]}">${r[1]}</button>`).join('')}</div>
  <div class="grid2">${stat('Tasks done',tasks)}${stat('Habit check-ins',habits)}${stat('Routine steps',steps)}${stat('Focus time',`${foc} min`)}</div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Things completed</div><div class="bars">${series.map((v,i)=>`<div><i style="height:${Math.max(4,v/mx*100)}%" title="${v}"></i><span>${bk[i].l}</span></div>`).join('')}</div></div>
  ${cats.length?`<div class="card"><div class="eyebrow" style="margin-bottom:12px">Tasks by area</div>${cats.map(c=>`<div class="barrow" style="margin-bottom:10px"><div class="top"><span>${c[0]}</span><span class="num sub">${c[1]}</span></div><div class="bar"><i style="width:${c[1]/cmx*100}%"></i></div></div>`).join('')}</div>`:''}
  <div class="card"><div class="eyebrow" style="margin-bottom:10px">How you feel</div>
   <div class="kv"><span>Mood</span><b class="num">${mood?mood.toFixed(1)+' of 5':'No data'}</b></div><div class="kv"><span>Energy</span><b class="num">${en?en.toFixed(1)+' of 5':'No data'}</b></div><div class="kv"><span>Sleep</span><b class="num">${sl?sl.toFixed(1)+' of 5':'No data'}</b></div></div>
  ${(ex.length||inc.length)?`<div class="card"><div class="eyebrow" style="margin-bottom:10px">Money</div><div class="kv"><span>Spent</span><b class="num">${money(sumBy(ex,'amount'))}</b></div><div class="kv"><span>Earned</span><b class="num">${money(sumBy(inc,'amount'))}</b></div>${sp.map(c=>`<div class="barrow" style="margin-top:8px"><div class="top"><span>${c[0]}</span><span class="num sub">${money(c[1])}</span></div><div class="bar"><i style="width:${c[1]/smx*100}%"></i></div></div>`).join('')}</div>`:''}
  ${wk.length?`<div class="card"><div class="eyebrow" style="margin-bottom:10px">Movement</div><div class="kv"><span>Workouts</span><b class="num">${wk.length}</b></div><div class="kv"><span>Minutes</span><b class="num">${sumBy(wk,'mins')}</b></div></div>`:''}
  <div class="card"><div class="eyebrow" style="margin-bottom:10px">Patterns</div><div class="kv"><span>Most productive hour</span><b>${cs.length>=5?hr12(bestH):'Not enough data yet'}</b></div><div class="kv"><span>Active days</span><b class="num">${new Set(cs.map(c=>c.date)).size} of ${n}</b></div>${goalsDone?`<div class="kv"><span>Goals completed</span><b class="num">${goalsDone}</b></div>`:''}</div>
  ${unused.length?`<div class="card"><div class="eyebrow" style="margin-bottom:8px">Not used yet</div><p class="sub sm-t">${listText(unused.slice(0,8).map(d=>d.name))}${unused.length>8?' and more':''}. Hide anything you do not need in Settings.</p></div>`:''}
  <p class="xs sub" style="text-align:center">These numbers describe what happened. They are not a score.</p></div>`;
};
ACT['insr']=d=>{insR=d.r};
