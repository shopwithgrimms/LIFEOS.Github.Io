/* ---------- SAMPLE DATA ---------- */
function seed(){
  const td=today(),S=(type,d)=>add(type,Object.assign({sample:true},d));
  const T=(title,o)=>S('task',Object.assign({title,notes:'',cat:'Household',pri:'med',e:'med',est:0,due:td,time:'',rule:{freq:'none',every:1,days:[],unit:'day'},remind:'none',subs:[],status:'open'},o));
  T('Take out the recycling',{e:'low',est:5});
  T('Reply to one email',{e:'low',est:10,cat:'Personal'});
  T("Plan this week's meals",{e:'med',est:20,cat:'Household',due:addDays(td,1)});
  T('Organise the desk',{e:'high',est:45,pri:'high',due:addDays(td,3),subs:[{id:uid(),t:'Clear the surface',done:false},{id:uid(),t:'Sort the drawers',done:false}]});
  const sat=(()=>{let d=td;while(dow(d)!==6)d=addDays(d,1);return d})();
  T('Clean the kitchen',{e:'med',est:30,due:sat,rule:{freq:'weekly',every:1,days:[6],unit:'day'}});
  T('Water the plants',{e:'low',est:10,due:td,rule:{freq:'daily',every:3,days:[],unit:'day'}});
  S('event',{title:'Dentist',date:addDays(td,1),start:'10:30',end:'11:30',loc:'',notes:'',rule:{freq:'none',every:1,days:[],unit:'day'},remind:'60'});
  S('event',{title:'Dinner with friends',date:(()=>{let d=td;while(dow(d)!==5)d=addDays(d,1);return d})(),start:'19:00',end:'21:00',loc:'',notes:'',rule:{freq:'weekly',every:1,days:[5],unit:'day'},remind:'none'});
  S('routine',{title:'Morning skincare',time:'08:00',days:[],remind:'none',steps:[{id:uid(),t:'Cleanser'},{id:uid(),t:'Moisturiser'},{id:uid(),t:'SPF'}]});
  S('routine',{title:'Evening reset',time:'21:00',days:[],remind:'none',steps:[{id:uid(),t:'Dishes'},{id:uid(),t:'Set out clothes'},{id:uid(),t:'Wind down'}]});
  S('habit',{title:'Read ten pages',target:5});S('habit',{title:'Stretch',target:4});S('habit',{title:'Ten-minute tidy',target:5});
  S('goal',{type:'completion',title:'Become more organised',cat:'Household',progress:35});S('goal',{type:'completion',title:'Read twenty books',cat:'Hobbies',progress:15});S('goal',{type:'completion',title:'Save $1,000',cat:'Financial',progress:60});
  S('dump',{title:'Research a new vacuum'});S('dump',{title:'Start learning photography'});
  [['Watch a film',30],['One hour of gaming',20],['A small treat',25],['A slow evening',40]].forEach(r=>S('reward',{title:r[0],cost:r[1]}));
  seed2(S);
  DB.set.seeded=true;persist();
}
function seed2(S){
  const td=today(),I=(coll,d)=>S('item',Object.assign({coll},d));
  [['Take a walk outside','Active',15,'Low'],['Put on a favourite playlist','Quick',10,'Low'],['A long bath','Relaxing',30,'Low'],['Tidy one small area','Productive',10,'Medium'],['Call a friend','Quick',20,'Low'],['Watch a comfort show','Relaxing',45,'Low']].forEach(a=>I('dopa',{name:a[0],kind:a[1],mins:a[2],energy:a[3]}));
  I('bprod',{name:'Daily cleanser',brand:'',cat:'Skincare',active:'None',qty:60,low:15,expires:addDays(td,200)});
  I('bprod',{name:'Retinol serum',brand:'',cat:'Skincare',active:'Retinol',expires:addDays(td,20)});
  I('bprod',{name:'Exfoliating toner',brand:'',cat:'Skincare',active:'AHA/BHA',expires:addDays(td,300)});
  I('pantry',{name:'Rice',qty:3,low:1,expires:''});I('pantry',{name:'Eggs',qty:6,low:2,expires:addDays(td,8)});I('pantry',{name:'Tomatoes',qty:3,low:1,expires:addDays(td,4)});
  I('recipe',{name:'Tomato and egg rice',mins:20,ing:'2 eggs\n1 cup rice\n2 tomatoes\nspring onion',steps:'Cook the rice. Scramble the eggs. Fry the tomatoes. Combine.'});
  I('supply',{name:'Washing-up liquid',qty:3,low:1,store:''});
  I('plant',{name:'Monstera',place:'Living room',every:7,last:addDays(td,-5)});
  I('bill',{name:'Internet',amount:35,due:addDays(td,5),freq:'Monthly'});
  I('sub',{name:'Music streaming',cost:10.99,cycle:'Monthly',renews:addDays(td,12)});
  I('budget',{name:'Groceries',limit:300});
  I('expense',{name:'Groceries',amount:42.5,cat:'Groceries',date:td,note:''});
  I('shop',{name:'Oat milk',qty:2,store:''});I('wish',{name:'A good desk lamp',price:60,pri:'Soon'});
  I('bucket',{name:'See the northern lights',cat:'Travel'});
  I('media',{name:'A book to start',mtype:'Book',status:'Want to'});
  I('person',{name:'A friend',bday:addDays(td,6).replace(/^\d{4}/,'1995'),notes:''});
  I('doc',{name:'Passport',kind:'ID',expires:addDays(td,90),where:'Desk drawer'});
}

