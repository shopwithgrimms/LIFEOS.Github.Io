/* ---------- GOALS AND PROJECTS ---------- */
const GT={numeric:['Numeric','Hit a number, like 12 books or 5 kg.'],completion:['Completion','Finish something, once.'],consistency:['Consistency','Show up regularly. Linked habits drive the progress.'],maintenance:['Maintenance','Keep something as it is.'],learning:['Learning','Build a skill step by step.'],financial:['Financial','Save, pay off or earn an amount.'],experience:['Experience','Do something memorable.']};
const NUMERIC=t=>t==='numeric'||t==='financial';
const doneTasks=ref=>{const l=all('task',t=>ref(t)&&!isRepeating(t));return{done:l.filter(t=>t.status==='done').length,total:l.length}};
function projectProgress(p){
  if(p.status==='done')return 100;
  const ms=p.ms||[],tk=doneTasks(t=>t.project===p.id),tot=ms.length+tk.total;
  return tot?pct(ms.filter(m=>m.done).length+tk.done,tot):0;
}
function goalProgress(g){
  if(g.status==='done')return 100;
  const t=g.gt||'completion';
  if(NUMERIC(t))return g.target?Math.max(0,Math.min(100,Math.round((+g.current||0)/+g.target*100))):0;
  if(t==='consistency'){
    const hs=all('habit',h=>h.goal===g.id);
    if(hs.length){let done=0,need=0;hs.forEach(h=>{for(let i=0;i<28;i++)if(isDone(h.id,addDays(today(),-i)))done++;need+=(h.target||5)*4});return Math.min(100,pct(done,need))}
  }
  const parts=[],ms=g.ms||[];
  if(ms.length)parts.push(pct(ms.filter(m=>m.done).length,ms.length));
  all('project',p=>p.goal===g.id).forEach(p=>parts.push(projectProgress(p)));
  const tk=doneTasks(x=>x.goal===g.id);if(tk.total)parts.push(pct(tk.done,tk.total));
  if(parts.length)return Math.round(parts.reduce((a,b)=>a+b,0)/parts.length);
  return Math.max(0,Math.min(100,+g.progress||0));
}

/* milestone editing shared by goal and project editors */
const msBlock=d=>`<div class="fld"><span>Milestones</span><div class="stack-sm">${(d.ms||[]).map((m,i)=>`<div class="row">${check(m.done,`data-act="ed-mst" data-i="${i}"`)}<div class="grow">${inp(`ms.${i}.t`,m.t,'Milestone')}</div><button class="icon-btn sm" data-act="ed-msx" data-i="${i}" aria-label="Remove">${ic('x')}</button></div>`).join('')}<div class="row"><div class="grow"><input class="input" id="newms" placeholder="Add a milestone" data-enter="ed-msadd"></div><button class="icon-btn p" data-act="ed-msadd" aria-label="Add milestone">${ic('plus')}</button></div></div></div>`;
ACT['ed-mst']=d=>{ED.d.ms[+d.i].done=!ED.d.ms[+d.i].done;drawEditor();return false};
ACT['ed-msx']=d=>{ED.d.ms.splice(+d.i,1);drawEditor();return false};
ACT['ed-msadd']=()=>{const v=$('#newms').value.trim();if(v){ED.d.ms.push({id:uid(),t:v,done:false});drawEditor();setTimeout(()=>$('#newms')&&$('#newms').focus(),30)}return false};
const cleanMs=l=>(l||[]).filter(m=>m.t.trim()).map(m=>Object.assign({},m,{t:m.t.trim()}));

EDITORS.goal={label:'goal',blank:()=>({title:'',gt:'completion',cat:'Personal',due:'',why:'',obstacles:'',target:'',current:0,unit:'',progress:0,ms:[],status:'active'}),
  body(d){const t=d.gt;return `<label class="fld"><span>Goal</span>${inp('title',d.title,'What do you want to achieve')}</label>
   <label class="fld"><span>Type</span>${sel('gt',Object.entries(GT).map(([k,v])=>[k,v[0]]),t,true)}<div class="xs sub" style="margin-top:4px">${GT[t][1]}</div></label>
   ${NUMERIC(t)?`<div class="grid2"><label class="fld"><span>Target</span>${inp('target',d.target,'','number','step="any" inputmode="decimal"')}</label><label class="fld"><span>Current</span>${inp('current',d.current,'','number','step="any" inputmode="decimal"')}</label></div><label class="fld"><span>Unit</span>${inp('unit',d.unit,t==='financial'?'Symbol, like $':'books, kg, miles')}</label>`:''}
   ${t==='completion'||t==='learning'||t==='experience'||t==='maintenance'?`<label class="fld"><span>Progress so far (%) <em style="text-transform:none;font-style:normal;font-weight:500">used when there are no milestones</em></span>${inp('progress',d.progress,'0','number','min="0" max="100" inputmode="numeric"')}</label>`:''}
   <div class="grid2"><label class="fld"><span>Area</span>${sel('cat',CATS.map(c=>[c,c]),d.cat)}</label><label class="fld"><span>Target date</span>${inp('due',d.due,'','date')}</label></div>
   <label class="fld"><span>Why it matters</span>${inp('why',d.why,'Optional')}</label>
   ${t==='consistency'?`<p class="xs sub">Link habits to this goal from each habit's editor. Progress counts the last 28 days.</p>`:msBlock(d)}
   <label class="fld"><span>Obstacles and what might help</span><textarea class="input" data-f="obstacles" rows="2" placeholder="Optional">${esc(d.obstacles)}</textarea></label>`},
  save(d,id){if(!d.title.trim()){toast('Name the goal');return false}
    const v=Object.assign({},d,{title:d.title.trim(),ms:cleanMs(d.ms),progress:Math.max(0,Math.min(100,+d.progress||0))});
    if(id)upd(id,v);else add('goal',v);return true}};
EDITORS.project={label:'project',blank:()=>({title:'',notes:'',goal:'',due:'',ms:[],status:'active'}),
  body(d){return `<label class="fld"><span>Project</span>${inp('title',d.title,'What are you working on')}</label>
   <label class="fld"><span>Notes</span><textarea class="input" data-f="notes" rows="2" placeholder="Optional">${esc(d.notes)}</textarea></label>
   <div class="grid2"><label class="fld"><span>Goal</span>${sel('goal',[['','None'],...all('goal',g=>g.status!=='done').map(g=>[g.id,g.title])],d.goal||'')}</label><label class="fld"><span>Target date</span>${inp('due',d.due,'','date')}</label></div>${msBlock(d)}`},
  save(d,id){if(!d.title.trim()){toast('Name the project');return false}const v=Object.assign({},d,{title:d.title.trim(),ms:cleanMs(d.ms)});if(id)upd(id,v);else add('project',v);return true}};
/* habits can be linked to a goal */
(()=>{const b=EDITORS.habit.body;EDITORS.habit.body=d=>b(d)+`<label class="fld"><span>Goal</span>${sel('goal',[['','None'],...all('goal',g=>g.status!=='done').map(g=>[g.id,g.title])],d.goal||'')}</label>`;
  const bl=EDITORS.habit.blank;EDITORS.habit.blank=()=>Object.assign(bl(),{goal:''})})();
const _openEditor=openEditor;
openEditor=function(kind,id,ctx){
  _openEditor(kind,id,ctx);
  if((kind==='goal'||kind==='project')&&ED){ED.d.ms=ED.d.ms||[];drawEditor()}
};

/* ---------- views ---------- */
const goalCard=g=>{const p=goalProgress(g);return `<button class="card" style="text-align:left;width:100%" data-go="goal" data-arg="${g.id}"><div class="row" style="gap:14px">${ring(p,52,6)}<div class="grow" style="min-width:0"><div class="b trunc">${esc(g.title)}</div><div class="xs sub">${GT[g.gt||'completion'][0]}${g.due?` · by ${dayLabel(g.due)}`:''}</div></div>${ic('chevron-right')}</div></button>`};
let goalTab='active';
V.goals=function(){
  const l=all('goal',g=>goalTab==='done'?g.status==='done':g.status!=='done');
  return `<div class="chips" style="margin-bottom:12px">${[['active','Active'],['done','Completed']].map(f=>`<button class="chip ${goalTab===f[0]?'on':''}" data-act="goaltab" data-f="${f[0]}">${f[1]}</button>`).join('')}</div>
  <div class="stack-sm">${l.map(goalCard).join('')||`<div class="card">${emptyBox('target',goalTab==='done'?'No completed goals yet':'No goals yet','Start from a template or write your own.')}</div>`}</div>
  <div style="margin-top:12px"><button class="btn btn-soft btn-sm block" data-act="goal-tpl">${ic('sparkles')}Start from a template</button></div>${stickyAdd('new" data-kind="goal','Add goal')}`;
};
ACT['goaltab']=d=>{goalTab=d.f};
V.goal=function(){
  const g=DB.rec[viewArg];if(!g||g.deleted)return emptyBox('target','Goal not found','');
  const p=goalProgress(g),t=g.gt||'completion',ms=g.ms||[],projs=all('project',x=>x.goal===g.id),tks=all('task',x=>x.goal===g.id).sort(byDue),hs=all('habit',h=>h.goal===g.id);
  return `<div class="stack">
  <div class="card"><div class="row" style="gap:16px">${ring(p,76,8)}<div class="grow"><div class="b" style="font-size:16px">${esc(g.title)}</div><div class="xs sub">${GT[t][0]} · ${g.cat||''}${g.due?` · by ${dayLabel(g.due)}`:''}</div>${g.why?`<div class="sm-t" style="margin-top:6px">${esc(g.why)}</div>`:''}</div></div>
   ${NUMERIC(t)?`<div class="row between" style="margin-top:14px"><span class="b num">${t==='financial'?esc(g.unit||cur()):''}${g.current||0} of ${g.target||0} ${t==='financial'?'':esc(g.unit||'')}</span><button class="btn btn-soft btn-sm" data-act="goal-prog" data-id="${g.id}">Update</button></div>`:''}
   ${!NUMERIC(t)&&!ms.length&&!projs.length&&t!=='consistency'?`<div style="margin-top:14px"><input type="range" min="0" max="100" value="${+g.progress||0}" data-gp="${g.id}" data-out="gpv" data-unit="%" style="width:100%"><div class="xs sub num" id="gpv">${+g.progress||0}%</div></div>`:''}
   <div class="grid2" style="margin-top:14px"><button class="btn btn-line btn-sm" data-act="edit" data-kind="goal" data-id="${g.id}">${ic('pencil')}Edit</button>${g.status==='done'?`<button class="btn btn-line btn-sm" data-act="goal-reopen" data-id="${g.id}">Reopen</button>`:`<button class="btn btn-primary btn-sm" data-act="goal-done" data-id="${g.id}">${ic('check')}Complete</button>`}</div></div>
  ${ms.length?`<div class="card"><div class="eyebrow" style="margin-bottom:8px">Milestones</div><div class="stack-sm">${ms.map((m,i)=>`<div class="item ${m.done?'done':''}">${check(m.done,`data-act="ms-tog" data-id="${g.id}" data-i="${i}"`)}<div class="grow"><h4 class="t">${esc(m.t)}</h4></div></div>`).join('')}</div></div>`:''}
  ${t==='consistency'?`<div class="card"><div class="eyebrow" style="margin-bottom:8px">Linked habits</div>${hs.length?`<div class="stack-sm">${hs.map(habitRow).join('')}</div>`:`<p class="sub sm-t">No habits linked yet.</p>`}<button class="btn btn-soft btn-sm block" style="margin-top:10px" data-act="new-link" data-kind="habit" data-key="goal" data-val="${g.id}">${ic('plus')}Add a habit</button></div>`:''}
  <div class="card"><div class="row between" style="margin-bottom:8px"><span class="eyebrow">Projects</span><button class="link" data-act="new-link" data-kind="project" data-key="goal" data-val="${g.id}">Add</button></div>${projs.length?`<div class="stack-sm">${projs.map(p=>`<button class="barrow" style="text-align:left;width:100%" data-go="project" data-arg="${p.id}"><div class="top"><span class="b trunc">${esc(p.title)}</span><span class="num sub">${projectProgress(p)}%</span></div><div class="bar"><i style="width:${projectProgress(p)}%"></i></div></button>`).join('')}</div>`:`<p class="sub sm-t">None linked.</p>`}</div>
  <div class="card"><div class="row between" style="margin-bottom:8px"><span class="eyebrow">Tasks</span><button class="link" data-act="new-link" data-kind="task" data-key="goal" data-val="${g.id}">Add</button></div>${tks.length?`<div class="stack-sm">${tks.map(x=>taskItem(x)).join('')}</div>`:`<p class="sub sm-t">None linked. Tasks you link here count toward progress.</p>`}</div>
  ${g.obstacles?`<div class="card"><div class="eyebrow" style="margin-bottom:6px">Obstacles and what might help</div><div class="sm-t" style="white-space:pre-wrap">${esc(g.obstacles)}</div></div>`:''}
  <div class="card"><div class="row between" style="margin-bottom:8px"><span class="eyebrow">Reviews</span><button class="link" data-act="goal-review" data-id="${g.id}">Write one</button></div>${(g.reviews||[]).length?(g.reviews).slice(0,5).map(r=>`<div style="padding:8px 0;border-top:1px solid var(--line)"><div class="xs sub">${dayLabel(r.date)}</div><div class="sm-t" style="white-space:pre-wrap">${esc(r.text)}</div></div>`).join(''):`<p class="sub sm-t">A short weekly or monthly check-in helps you adjust, not judge.</p>`}</div></div>`;
};
ACT['new-link']=d=>{openEditor(d.kind,null);ED.d[d.key]=d.val;drawEditor();return false};
ACT['ms-tog']=d=>{const g=DB.rec[d.id],ms=g.ms.map((m,i)=>i===+d.i?Object.assign({},m,{done:!m.done}):m);upd(d.id,{ms});if(ms[+d.i].done)gain(10,5)};
ACT['goal-done']=d=>{upd(d.id,{status:'done',doneAt:today()});gain(50,25);toast('Goal complete. +50 XP');checkBadges()};
ACT['goal-reopen']=d=>{upd(d.id,{status:'active'})};
ACT['goal-prog']=d=>{const g=DB.rec[d.id];sheet('Update progress',`<label class="fld"><span>Current ${esc(g.unit||'')}</span><input class="input" id="gcur" type="number" step="any" inputmode="decimal" value="${g.current||0}"></label><p class="xs sub">Target: ${g.target||0}</p>`,`<button class="btn btn-line" data-act="close">Cancel</button><button class="btn btn-primary" data-act="goal-prog-save" data-id="${d.id}">Save</button>`);return false};
ACT['goal-prog-save']=d=>{upd(d.id,{current:+$('#gcur').value||0});closeSheet();toast('Progress updated')};
ACT['goal-review']=d=>{sheet('Quick review',`<label class="fld"><span>What moved forward?</span><textarea class="input" id="rv1" rows="2"></textarea></label><label class="fld"><span>What got in the way?</span><textarea class="input" id="rv2" rows="2"></textarea></label><label class="fld"><span>One small next step</span><textarea class="input" id="rv3" rows="2"></textarea></label>`,`<button class="btn btn-line" data-act="close">Cancel</button><button class="btn btn-primary" data-act="goal-review-save" data-id="${d.id}">Save review</button>`);return false};
ACT['goal-review-save']=d=>{const g=DB.rec[d.id],tx=[['Moved forward',$('#rv1').value],['In the way',$('#rv2').value],['Next step',$('#rv3').value]].filter(x=>x[1].trim()).map(x=>`${x[0]}: ${x[1].trim()}`).join('\n');
  if(!tx){toast('Write something first');return false}upd(d.id,{reviews:[{date:today(),text:tx},...(g.reviews||[])]});closeSheet();toast('Review saved. +5 XP');gain(5,2)};
/* slider on goal page */
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.gp){upd(t.dataset.gp,{progress:+t.value})}});

const GOAL_TPL=[
 {n:'Read 12 books this year',gt:'numeric',cat:'Hobbies',target:12,unit:'books'},
 {n:'Save for something that matters',gt:'financial',cat:'Financial',target:1000,unit:'$'},
 {n:'Move my body three times a week',gt:'consistency',cat:'Fitness',habit:{title:'Move my body',target:3}},
 {n:'Declutter the home',gt:'completion',cat:'Household',ms:['Wardrobe','Kitchen','Bathroom','Paperwork','Donate or sell what is left']},
 {n:'Learn a new skill',gt:'learning',cat:'Learning',ms:['Choose a resource','Learn the basics','Practise weekly','Make something with it']},
 {n:'Plan a trip',gt:'experience',cat:'Travel',ms:['Pick dates','Set a budget','Book travel','Book places to stay','Pack']},
 {n:'Keep my space tidy',gt:'maintenance',cat:'Household'}];
ACT['goal-tpl']=()=>{sheet('Goal templates',`<div class="stack-sm">${GOAL_TPL.map((t,i)=>`<button class="list-row" data-act="goal-tpl-use" data-i="${i}"><div class="grow"><h4>${t.n}</h4><div class="xs sub">${GT[t.gt][0]}</div></div>${ic('plus')}</button>`).join('')}</div>`);return false};
ACT['goal-tpl-use']=d=>{
  const t=GOAL_TPL[+d.i],g=add('goal',{title:t.n,gt:t.gt,cat:t.cat,due:'',why:'',obstacles:'',target:t.target||'',current:0,unit:t.unit||'',progress:0,status:'active',ms:(t.ms||[]).map(x=>({id:uid(),t:x,done:false}))});
  if(t.habit)add('habit',{title:t.habit.title,target:t.habit.target,goal:g.id});
  closeSheet();go('goal',g.id);return false;
};

V.projects=function(){
  const l=all('project',p=>p.status!=='done'),dn=all('project',p=>p.status==='done');
  return `<div class="stack-sm">${l.map(p=>`<button class="card" style="text-align:left;width:100%" data-go="project" data-arg="${p.id}"><div class="row" style="gap:14px">${ring(projectProgress(p),52,6)}<div class="grow" style="min-width:0"><div class="b trunc">${esc(p.title)}</div><div class="xs sub">${all('task',t=>t.project===p.id&&t.status!=='done').length} open tasks${p.due?` · by ${dayLabel(p.due)}`:''}</div></div>${ic('chevron-right')}</div></button>`).join('')||`<div class="card">${emptyBox('folder','No projects yet','Group tasks and milestones toward an outcome.')}</div>`}</div>
  ${dn.length?`<div class="eyebrow sec-h">Completed</div><div class="stack-sm">${dn.map(p=>`<button class="list-row" data-go="project" data-arg="${p.id}"><div class="grow"><h4>${esc(p.title)}</h4></div>${ic('chevron-right')}</button>`).join('')}</div>`:''}${stickyAdd('new" data-kind="project','Add project')}`;
};
V.project=function(){
  const p=DB.rec[viewArg];if(!p||p.deleted)return emptyBox('folder','Project not found','');
  const ms=p.ms||[],tks=all('task',t=>t.project===p.id).sort((a,b)=>(a.status==='done')-(b.status==='done')||byDue(a,b)),g=p.goal&&DB.rec[p.goal];
  return `<div class="stack"><div class="card"><div class="row" style="gap:16px">${ring(projectProgress(p),76,8)}<div class="grow"><div class="b" style="font-size:16px">${esc(p.title)}</div>${p.due?`<div class="xs sub">by ${dayLabel(p.due)}</div>`:''}${g?`<button class="link" data-go="goal" data-arg="${g.id}">Goal: ${esc(g.title)}</button>`:''}${p.notes?`<div class="sm-t" style="margin-top:6px">${esc(p.notes)}</div>`:''}</div></div>
   <div class="grid2" style="margin-top:14px"><button class="btn btn-line btn-sm" data-act="edit" data-kind="project" data-id="${p.id}">${ic('pencil')}Edit</button>${p.status==='done'?`<button class="btn btn-line btn-sm" data-act="proj-reopen" data-id="${p.id}">Reopen</button>`:`<button class="btn btn-primary btn-sm" data-act="proj-done" data-id="${p.id}">${ic('check')}Complete</button>`}</div></div>
  ${ms.length?`<div class="card"><div class="eyebrow" style="margin-bottom:8px">Milestones</div><div class="stack-sm">${ms.map((m,i)=>`<div class="item ${m.done?'done':''}">${check(m.done,`data-act="ms-tog" data-id="${p.id}" data-i="${i}"`)}<div class="grow"><h4 class="t">${esc(m.t)}</h4></div></div>`).join('')}</div></div>`:''}
  <div class="card"><div class="row between" style="margin-bottom:8px"><span class="eyebrow">Tasks</span><button class="link" data-act="new-link" data-kind="task" data-key="project" data-val="${p.id}">Add</button></div>${tks.length?`<div class="stack-sm">${tks.map(x=>taskItem(x)).join('')}</div>`:`<p class="sub sm-t">No tasks yet. Add the first small step.</p>`}</div></div>`;
};
ACT['proj-done']=d=>{upd(d.id,{status:'done'});gain(30,15);toast('Project complete. +30 XP');checkBadges()};
ACT['proj-reopen']=d=>{upd(d.id,{status:'active'})};
