/* ---------- BOOT ---------- */
load();
if(!Object.keys(DB.rec).length&&!DB.set.seeded)seed();
if(!THEMES[DB.set.theme])DB.set.theme='blush';
if(DB.set.lastOpen&&diffDays(DB.set.lastOpen,today())>=7)DB.set.came=true;
away=DB.set.lastOpen?Math.max(0,diffDays(DB.set.lastOpen,today())):0;
DB.set.lastOpen=today();persist();
applyPrefs();checkBadges();
render();tick();setInterval(tick,20000);setInterval(focusTick,1000);setInterval(checkBadges,6000);showLock();
document.addEventListener('visibilitychange',()=>{if(!document.hidden){tick();render(true)}});
window.__lifeos={DB,occursOn,nextDue,addDays,addMonths,today,diffDays,dow,tick,fire,reminderCandidates,toggleTask,add,all,upd,setDone,isDone,ruleText,flush,render,COLLS,DEPTS,collOf,itemsOf,openItemEditor,goalProgress,projectProgress,parseWhen,classify,answer,planDay,attention,go,V,ACT,money};
