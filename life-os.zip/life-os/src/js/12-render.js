/* ---------- RENDER ---------- */
const TAB_IDS=TABS.map(t=>t[0]);
const isSub=v=>!TAB_IDS.includes(v);
const curTab=v=>TAB_IDS.includes(v)?v:(v==='dept'||v==='coll')?'life':'more';
function titleFor(v,a){
  if(v==='dept'){const d=deptOf(a);return d?d.name:'Department'}
  if(v==='coll'){const c=collOf(String(a).split('|')[1]);return c?c.title:'List'}
  if(v==='goal'||v==='project'){const r=DB.rec[a];return r?r.title:TITLES[v+'s']}
  return TITLES[v]||v;
}
function goBack(){
  if(view==='coll')return go('dept',String(viewArg).split('|')[0]);
  if(view==='dept')return go('life');
  if(view==='goal')return go('goals');
  if(view==='project')return go('projects');
  return go('more');
}
function chrome(){
  applyTheme();
  const sub=isSub(view),n=unread();
  $('#hdr').innerHTML=`<div class="row" style="min-width:0">${sub?`<button class="icon-btn" data-act="back" aria-label="Back">${ic('arrow-left')}</button>`:''}<h1 class="trunc">${esc(titleFor(view,viewArg))}</h1></div>`+
   `<div class="row" style="gap:8px;flex:none">${DB.set.mode!=='normal'?`<span class="pill warn">${MODE[DB.set.mode]}</span>`:''}<button class="icon-btn" data-act="search" aria-label="Search">${ic('search')}</button><button class="icon-btn" data-act="bell" aria-label="Notifications">${ic('bell')}${n?`<span class="badge">${n>9?'9+':n}</span>`:''}</button></div>`;
  const cur=curTab(view);
  $('#nav').innerHTML=TABS.map(t=>`<button class="${cur===t[0]?'on':''}" data-go="${t[0]}">${ic(t[2])}${t[1]}</button>`).join('');
}
function render(keep){
  if(!V[view])view='home';
  chrome();const v=$('#view');v.innerHTML=V[view]();
  if(!keep){v.classList.remove('fade');void v.offsetWidth;v.classList.add('fade');$('#scroll').scrollTop=0}
}
const go=(v,a)=>{view=v;viewArg=a==null?null:a;render()};
