/* ---------- COMPANION, QUESTS, BADGES, REWARD SHOP ----------
   Nothing here ever takes progress away for missing a day. Quests reset on a
   schedule, XP and coins only go up from activity. */
const pet=()=>{if(!DB.set.pet)DB.set.pet={name:'Pip',kind:'cat'};return DB.set.pet};
const PET_KINDS=[['cat','Cat'],['bunny','Bunny'],['bear','Bear'],['sprout','Sprout']];
const COSMETICS=[{id:'bow',n:'Bow',cost:30},{id:'glasses',n:'Glasses',cost:40},{id:'scarf',n:'Scarf',cost:50},{id:'flower',n:'Flower',cost:35},{id:'crown',n:'Crown',cost:120}];
function companionSVG(){
  const p=pet(),eq=DB.set.eq||[],S='stroke="var(--p)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"',F='fill="var(--p-soft)"';
  const lvl=level(),sc=Math.min(1,.82+lvl*.03);
  let b='';
  if(p.kind==='cat')b=`<path d="M27 46 L29 22 L45 36 Z" ${F} ${S}/><path d="M73 46 L71 22 L55 36 Z" ${F} ${S}/><ellipse cx="50" cy="58" rx="27" ry="23" ${F} ${S}/><path d="M24 60h-10M24 65l-9 3M76 60h10M76 65l9 3" ${S} fill="none"/>`;
  else if(p.kind==='bunny')b=`<ellipse cx="38" cy="26" rx="7" ry="18" ${F} ${S}/><ellipse cx="62" cy="26" rx="7" ry="18" ${F} ${S}/><ellipse cx="50" cy="60" rx="24" ry="22" ${F} ${S}/>`;
  else if(p.kind==='bear')b=`<circle cx="29" cy="38" r="9" ${F} ${S}/><circle cx="71" cy="38" r="9" ${F} ${S}/><circle cx="50" cy="58" r="26" ${F} ${S}/>`;
  else b=`<path d="M50 40 C50 26 38 20 28 22 C30 34 38 40 50 40Z" ${F} ${S}/><path d="M50 40 C50 26 62 20 72 22 C70 34 62 40 50 40Z" ${F} ${S}/><ellipse cx="50" cy="62" rx="24" ry="22" ${F} ${S}/>`;
  b+=`<circle cx="41" cy="57" r="2.4" fill="var(--text)"/><circle cx="59" cy="57" r="2.4" fill="var(--text)"/><path d="M44 65 Q50 70 56 65" ${S} fill="none"/><circle cx="35" cy="64" r="3" fill="var(--p)" opacity=".25"/><circle cx="65" cy="64" r="3" fill="var(--p)" opacity=".25"/>`;
  if(eq.includes('glasses'))b+=`<circle cx="41" cy="57" r="7" fill="none" stroke="var(--text)" stroke-width="2"/><circle cx="59" cy="57" r="7" fill="none" stroke="var(--text)" stroke-width="2"/><path d="M48 57h4" stroke="var(--text)" stroke-width="2"/>`;
  if(eq.includes('scarf'))b+=`<rect x="30" y="76" width="40" height="9" rx="4.5" fill="var(--p)"/><rect x="58" y="80" width="8" height="14" rx="3" fill="var(--p)"/>`;
  if(eq.includes('bow'))b+=`<path d="M64 36 L76 30 L76 44 Z M64 36 L52 30 L52 44 Z" fill="var(--p)" transform="translate(6 -4) scale(.7) translate(10 12)"/><circle cx="73" cy="34" r="2.5" fill="var(--on-p)"/>`;
  if(eq.includes('flower'))b+=`<g transform="translate(66 36)"><circle r="3.2" fill="var(--on-p)" stroke="var(--p)" stroke-width="1.5"/><circle cx="0" cy="-5" r="3" fill="var(--p)"/><circle cx="5" cy="0" r="3" fill="var(--p)"/><circle cx="0" cy="5" r="3" fill="var(--p)"/><circle cx="-5" cy="0" r="3" fill="var(--p)"/><circle r="2.2" fill="var(--on-p)"/></g>`;
  if(eq.includes('crown'))b+=`<path d="M36 34 L40 22 L45 30 L50 20 L55 30 L60 22 L64 34 Z" fill="var(--p)" stroke="var(--p-dark)" stroke-width="1.5" stroke-linejoin="round"/>`;
  return `<svg viewBox="0 0 100 100" style="width:100%;height:auto;display:block" role="img" aria-label="Your companion"><g transform="translate(50 56) scale(${sc}) translate(-50 -56)">${b}</g></svg>`;
}
const petMood=()=>{const n=all('comp',c=>c.date===today()).length;return n===0?'Resting. No pressure.':n<3?'Content and cheering you on.':'Having a great day.'};

/* ---- quests ---- */
const actDays=(n)=>{const set=new Set();all('comp').forEach(c=>{if(c.date>=addDays(today(),-(n-1)))set.add(c.date)});return set.size};
const compsSince=n=>all('comp',c=>c.date>=addDays(today(),-(n-1))).length;
const weekStart=()=>addDays(today(),-dow(today()));
const QUESTS={
  daily:{label:'Today',key:()=>today(),list:[
    {id:'d_tasks',t:'Complete 3 things',goal:3,val:()=>all('comp',c=>c.date===today()).length,coins:10},
    {id:'d_log',t:'Log water or mood',goal:1,val:()=>(getLog('water',today())||getLog('mood',today())?1:0),coins:5},
    {id:'d_focus',t:'Finish a focus session',goal:1,val:()=>getLog('focusN',today())||0,coins:10}]},
  weekly:{label:'This week',key:()=>weekStart(),list:[
    {id:'w_done',t:'Complete 15 things',goal:15,val:()=>all('comp',c=>c.date>=weekStart()).length,coins:30},
    {id:'w_days',t:'Be active on 4 different days',goal:4,val:()=>new Set(all('comp',c=>c.date>=weekStart()).map(c=>c.date)).size,coins:25},
    {id:'w_dept',t:'Add something in 2 departments',goal:2,val:()=>new Set(all('item',r=>r.created>=new Date(weekStart()+'T00:00:00').getTime()).map(r=>r.coll)).size,coins:25}]},
  monthly:{label:'This month',key:()=>monthKey(),list:[
    {id:'m_items',t:'Add 10 entries across your life',goal:10,val:()=>all('item',r=>new Date(r.created).toISOString().slice(0,7)===monthKey()).length,coins:50},
    {id:'m_done',t:'Complete 40 things',goal:40,val:()=>all('comp',c=>c.date.slice(0,7)===monthKey()).length,coins:60}]}
};
const claimKey=(g,q)=>`${g}:${QUESTS[g].key()}:${q.id}`;
ACT['claim']=d=>{const q=QUESTS[d.g].list.find(x=>x.id===d.q),k=claimKey(d.g,q);if(!q||(DB.set.claims||{})[k]||q.val()<q.goal)return;DB.set.claims=Object.assign({},DB.set.claims,{[k]:1});gain(q.coins,q.coins);toast(`Quest complete. +${q.coins} coins`);checkBadges()};

/* ---- badges ---- */
const cntK=k=>all('comp',c=>c.kind===k).length;
const collsUsed=()=>new Set(all('item').map(r=>r.coll)).size;
const BADGES=[
  {id:'b_first',n:'First step',d:'Complete a task',t:()=>cntK('task')>=1},
  {id:'b_25',n:'Getting going',d:'Complete 25 tasks',t:()=>cntK('task')>=25},
  {id:'b_100',n:'Steady hands',d:'Complete 100 tasks',t:()=>cntK('task')>=100},
  {id:'b_routine',n:'Routine builder',d:'Tick off 10 routine steps',t:()=>cntK('step')>=10},
  {id:'b_habit',n:'Habit forming',d:'Check off a habit 7 times',t:()=>cntK('habit')>=7},
  {id:'b_focus',n:'In the zone',d:'Finish a focus session',t:()=>all('log',l=>l.kind==='focusN'&&l.value>0).length>=1},
  {id:'b_hour',n:'Deep work',d:'Focus for 60 minutes in total',t:()=>sumBy(all('log',l=>l.kind==='focus').map(l=>({v:l.value})),'v')>=60},
  {id:'b_goal',n:'Goal getter',d:'Complete a goal',t:()=>all('goal',g=>g.status==='done').length>=1},
  {id:'b_explore',n:'Explorer',d:'Use 3 different departments',t:()=>collsUsed()>=3},
  {id:'b_round',n:'Well rounded',d:'Use 8 different departments',t:()=>collsUsed()>=8},
  {id:'b_back',n:'Welcome back',d:'Return after a week or more away',t:()=>!!DB.set.came},
  {id:'b_l5',n:'Level 5',d:'Reach level 5',t:()=>level()>=5},
  {id:'b_l10',n:'Level 10',d:'Reach level 10',t:()=>level()>=10}
];
function checkBadges(){
  const b=DB.set.badges||(DB.set.badges={});let n=0;
  BADGES.forEach(x=>{if(!b[x.id]&&x.t()){b[x.id]=today();n++;if(!$('#modal').classList.contains('on'))toast(`Badge earned: ${x.n}`)}});
  if(n){persist();if(view==='rewards')render(true)}
}

/* ---- shop and rewards ---- */
ACT['redeem']=d=>{const r=DB.rec[d.id];if(DB.set.coins<r.cost){toast('Not enough coins yet');return false}gain(0,-r.cost);add('redeem',{title:r.title,at:Date.now()});toast(`Enjoy: ${r.title}`)};
ACT['cos-buy']=d=>{const c=COSMETICS.find(x=>x.id===d.id);if(DB.set.coins<c.cost){toast('Not enough coins yet');return false}gain(0,-c.cost);DB.set.own=[...(DB.set.own||[]),c.id];DB.set.eq=[...(DB.set.eq||[]),c.id];persist();toast(`${c.n} is yours`)};
ACT['cos-eq']=d=>{const e=(DB.set.eq||[]).slice(),i=e.indexOf(d.id);i<0?e.push(d.id):e.splice(i,1);DB.set.eq=e;persist()};
ACT['pet-kind']=d=>{pet().kind=d.k;persist()};
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.pet){pet().name=t.value;persist()}});

V.rewards=function(){
  const xp=DB.set.xp%100,own=DB.set.own||[],eq=DB.set.eq||[],rw=all('reward').sort((a,b)=>a.cost-b.cost),claims=DB.set.claims||{},earned=DB.set.badges||{};
  const quest=(g,q)=>{const v=Math.min(q.val(),q.goal),done=!!claims[claimKey(g,q)],ready=q.val()>=q.goal&&!done;
    return `<div class="barrow" style="margin-bottom:12px"><div class="top"><span class="${done?'sub':'b'}" style="font-size:13px">${q.t}</span><span class="row" style="gap:8px"><span class="xs sub num">${v}/${q.goal}</span>${done?'<span class="pill ok">Claimed</span>':ready?`<button class="btn btn-primary btn-sm" data-act="claim" data-g="${g}" data-q="${q.id}">+${q.coins}</button>`:`<span class="pill mute num">${q.coins}</span>`}</span></div><div class="bar"><i style="width:${pct(v,q.goal)}%"></i></div></div>`};
  return `<div class="stack">
  <div class="card"><div class="row" style="gap:16px"><div style="width:104px;flex:none">${companionSVG()}</div><div class="grow"><input class="input" data-pet="name" value="${esc(pet().name)}" maxlength="16" aria-label="Companion name" style="font-weight:700"><div class="xs sub" style="margin-top:6px">${petMood()}</div></div></div>
   <div class="chips" style="margin-top:12px">${PET_KINDS.map(k=>`<button class="chip ${pet().kind===k[0]?'on':''}" data-act="pet-kind" data-k="${k[0]}">${k[1]}</button>`).join('')}</div>
   <div class="row between" style="margin-top:14px"><span class="b">Level ${level()}</span><span class="xs sub num">${xp} / 100 XP · ${DB.set.coins} coins</span></div><div class="bar" style="margin-top:6px"><i style="width:${xp}%"></i></div>
   <p class="xs sub" style="margin-top:8px">Progress only goes up. Missing a day never costs you anything.</p></div>
  ${Object.keys(QUESTS).map(g=>`<div class="card"><div class="eyebrow" style="margin-bottom:12px">Quests · ${QUESTS[g].label}</div>${QUESTS[g].list.map(q=>quest(g,q)).join('')}</div>`).join('')}
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Badges · ${Object.keys(earned).length} of ${BADGES.length}</div><div class="stack-sm">${BADGES.map(b=>`<div class="item" style="opacity:${earned[b.id]?1:.5}"><div class="list-row" style="width:36px;height:36px;padding:0;justify-content:center;flex:none;border-radius:12px;background:${earned[b.id]?'var(--p-soft)':'transparent'};color:var(--p)">${ic(earned[b.id]?'award':'lock')}</div><div class="grow"><h4>${b.n}</h4><div class="meta">${b.d}</div></div></div>`).join('')}</div></div>
  <div class="card"><div class="row between" style="margin-bottom:12px"><span class="eyebrow">Your rewards</span><button class="link" data-act="new" data-kind="reward">Add</button></div>
   ${rw.length?`<div class="stack-sm">${rw.map(r=>`<div class="item"><div class="grow"><h4>${esc(r.title)}</h4><div class="meta num">${r.cost} coins</div></div><button class="icon-btn sm" data-act="edit" data-kind="reward" data-id="${r.id}" aria-label="Edit">${ic('pencil')}</button><button class="btn ${DB.set.coins>=r.cost?'btn-primary':'btn-line'} btn-sm" data-act="redeem" data-id="${r.id}">Redeem</button></div>`).join('')}</div>`:`<p class="sub sm-t">Add real-life treats you want to earn, like a long bath or a film night.</p>`}</div>
  <div class="card"><div class="eyebrow" style="margin-bottom:12px">Companion items</div><div class="stack-sm">${COSMETICS.map(c=>`<div class="item"><div class="grow"><h4>${c.n}</h4><div class="meta num">${own.includes(c.id)?'Owned':c.cost+' coins'}</div></div>${own.includes(c.id)?`<button class="btn ${eq.includes(c.id)?'btn-primary':'btn-line'} btn-sm" data-act="cos-eq" data-id="${c.id}">${eq.includes(c.id)?'Wearing':'Wear'}</button>`:`<button class="btn ${DB.set.coins>=c.cost?'btn-soft':'btn-line'} btn-sm" data-act="cos-buy" data-id="${c.id}">Buy</button>`}</div>`).join('')}</div></div></div>`;
};
